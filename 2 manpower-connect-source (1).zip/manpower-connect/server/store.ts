import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import type {
  ApplicationStatus,
  JobApplication,
  JobPost,
  JobStatus,
  PublicUser,
  SupplierApprovalStatus,
  UserRole,
} from '../src/types.ts';

export interface StoredUser extends PublicUser {
  passwordHash: string;
  salt: string;
}

interface DatabaseSchema {
  users: StoredUser[];
  jobs: JobPost[];
  applications: JobApplication[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'marketplace.json');

export function hashPassword(password: string, existingSalt?: string): { hash: string; salt: string } {
  const salt = existingSalt ?? crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, salt: string, storedHash: string): boolean {
  const { hash } = hashPassword(password, salt);
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(storedHash, 'hex'));
}

export function toPublicUser(user: StoredUser): PublicUser {
  const { passwordHash: _ph, salt: _s, ...pub } = user;
  return pub;
}

function createSeedData(): DatabaseSchema {
  const adminCreds = hashPassword('Admin@2026');
  const sup1Creds = hashPassword('Supplier@2026');
  const sup2Creds = hashPassword('Supplier@2026');
  const sup3Creds = hashPassword('Supplier@2026');
  const workerCreds = hashPassword('Worker@2026');

  const users: StoredUser[] = [
    {
      id: 'usr-admin-1',
      email: 'admin@manpowerconnect.sa',
      name: 'Faisal Al-Harbi',
      role: 'admin',
      phone: '+966 50 100 0001',
      city: 'Riyadh',
      createdAt: '2026-09-01T08:00:00.000Z',
      passwordHash: adminCreds.hash,
      salt: adminCreds.salt,
    },
    {
      id: 'usr-sup-1',
      email: 'hr@alrowad-contracting.sa',
      name: 'Khalid Al-Otaibi',
      role: 'supplier',
      phone: '+966 55 412 8890',
      city: 'Riyadh',
      companyName: 'Al-Rowad Civil & MEP Contracting Co.',
      crNumber: '1010482910',
      approvalStatus: 'approved',
      bio: 'Tier-1 civil, MEP, and structural workforce supplier serving Vision 2030 infrastructure corridors across Riyadh and Diriyah.',
      specialties: ['Civil & Construction', 'MEP & Electrical', 'Heavy Equipment'],
      nitaqatBand: 'Platinum',
      yearsActive: 14,
      createdAt: '2026-09-10T09:00:00.000Z',
      passwordHash: sup1Creds.hash,
      salt: sup1Creds.salt,
    },
    {
      id: 'usr-sup-2',
      email: 'talent@alkhaleej-industrial.sa',
      name: 'Nasser Al-Qahtani',
      role: 'supplier',
      phone: '+966 54 902 3311',
      city: 'Jubail',
      companyName: 'Al-Khaleej Industrial Services',
      crNumber: '2050391844',
      approvalStatus: 'approved',
      bio: 'Specialized technical manpower provider for Eastern Province petrochemical plants, fabrication yards, and offshore logistics.',
      specialties: ['Welding & Fabrication', 'MEP & Electrical', 'Logistics & Warehouse'],
      nitaqatBand: 'High Green',
      yearsActive: 11,
      createdAt: '2026-09-14T10:30:00.000Z',
      passwordHash: sup2Creds.hash,
      salt: sup2Creds.salt,
    },
    {
      id: 'usr-sup-3',
      email: 'ops@najd-builders.sa',
      name: 'Omar Al-Zahrani',
      role: 'supplier',
      phone: '+966 56 771 2045',
      city: 'Jeddah',
      companyName: 'Najd Modern Builders Est.',
      crNumber: '4030994122',
      approvalStatus: 'pending',
      adminNote: 'Awaiting Commercial Registration and Qiwa compliance verification.',
      bio: 'Western Region residential and hospitality finishing contractor deploying interior fit-out crews across Jeddah and Makkah.',
      specialties: ['Civil & Construction', 'Facility & Hospitality'],
      nitaqatBand: 'Medium Green',
      yearsActive: 4,
      createdAt: '2026-11-12T14:20:00.000Z',
      passwordHash: sup3Creds.hash,
      salt: sup3Creds.salt,
    },
    {
      id: 'usr-wrk-1',
      email: 'tariq.mansoor@worker.sa',
      name: 'Tariq Al-Mansoor',
      role: 'worker',
      phone: '+966 53 608 4419',
      city: 'Riyadh',
      trade: 'Senior MEP Electrician',
      yearsExperience: 7,
      iqamaTransferable: true,
      createdAt: '2026-10-05T11:15:00.000Z',
      passwordHash: workerCreds.hash,
      salt: workerCreds.salt,
    },
  ];

  const jobs: JobPost[] = [
    {
      id: 'job-101',
      supplierId: 'usr-sup-1',
      supplierName: 'Al-Rowad Civil & MEP Contracting Co.',
      supplierCity: 'Riyadh',
      supplierCrNumber: '1010482910',
      supplierApprovalStatus: 'approved',
      approvalStatus: 'approved',
      title: 'High-Voltage Industrial Electricians',
      category: 'MEP & Electrical',
      city: 'Riyadh',
      siteLocation: 'King Salman Energy & Transit District',
      headcount: 24,
      salaryMin: 4200,
      salaryMax: 5600,
      contractType: 'Project Contract',
      durationMonths: 18,
      shiftHours: '8 hrs / 6 days',
      accommodationIncluded: true,
      transportIncluded: true,
      mealsIncluded: true,
      iqamaTransferableRequired: false,
      certifications: ['SEC Safety Permit', 'OSHA 30-Hr', 'MV Cable Termination'],
      description:
        'Seeking certified industrial electricians experienced in switchgear installation, MV/LV cable pulling, and substation testing for an 18-month transit hub package in North Riyadh.',
      status: 'active',
      applicationsCount: 1,
      createdAt: '2026-11-15T06:30:00.000Z',
    },
    {
      id: 'job-102',
      supplierId: 'usr-sup-2',
      supplierName: 'Al-Khaleej Industrial Services',
      supplierCity: 'Jubail',
      supplierCrNumber: '2050391844',
      supplierApprovalStatus: 'approved',
      approvalStatus: 'approved',
      title: '6G TIG & Arc Pipe Welders',
      category: 'Welding & Fabrication',
      city: 'Jubail',
      siteLocation: 'Jubail Industrial City II',
      headcount: 18,
      salaryMin: 5200,
      salaryMax: 6800,
      contractType: 'Monthly Transfer (Iqama)',
      durationMonths: 24,
      shiftHours: '10 hrs / 6 days',
      accommodationIncluded: true,
      transportIncluded: true,
      mealsIncluded: false,
      iqamaTransferableRequired: true,
      certifications: ['Aramco 6G Welder Card', 'CSWIP / AWS D1.1', 'H2S Safety'],
      description:
        'Immediate mobilization for carbon and stainless steel process piping packages. Candidates must pass a 6G coupon weld test at our Jubail yard prior to site deployment.',
      status: 'active',
      applicationsCount: 0,
      createdAt: '2026-11-14T16:45:00.000Z',
    },
    {
      id: 'job-103',
      supplierId: 'usr-sup-1',
      supplierName: 'Al-Rowad Civil & MEP Contracting Co.',
      supplierCity: 'Riyadh',
      supplierCrNumber: '1010482910',
      supplierApprovalStatus: 'approved',
      approvalStatus: 'approved',
      title: 'Steel Fixers & Formwork Carpenters',
      category: 'Civil & Construction',
      city: 'NEOM / Tabuk',
      siteLocation: 'Oxagon Logistics Spine',
      headcount: 45,
      salaryMin: 2800,
      salaryMax: 3600,
      contractType: 'Ajeer / Temporary',
      durationMonths: 12,
      shiftHours: '8 hrs / 6 days',
      accommodationIncluded: true,
      transportIncluded: true,
      mealsIncluded: true,
      iqamaTransferableRequired: false,
      certifications: ['Valid Ajeer Eligibility', 'Site Induction Safety'],
      description:
        'Large-scale precast and reinforced concrete substructure crew required for coastal logistics infrastructure. Full camp accommodation, catering, and bi-weekly site transport provided.',
      status: 'active',
      applicationsCount: 0,
      createdAt: '2026-11-14T11:20:00.000Z',
    },
    {
      id: 'job-104',
      supplierId: 'usr-sup-2',
      supplierName: 'Al-Khaleej Industrial Services',
      supplierCity: 'Jubail',
      supplierCrNumber: '2050391844',
      supplierApprovalStatus: 'approved',
      approvalStatus: 'approved',
      title: 'Heavy Crane & Excavator Operators',
      category: 'Heavy Equipment',
      city: 'Dammam',
      siteLocation: 'King Abdulaziz Port Expansion',
      headcount: 12,
      salaryMin: 4800,
      salaryMax: 6200,
      contractType: 'Direct Sponsorship',
      durationMonths: 24,
      shiftHours: '8 hrs / 6 days',
      accommodationIncluded: true,
      transportIncluded: true,
      mealsIncluded: false,
      iqamaTransferableRequired: true,
      certifications: ['Saudi Heavy Equipment License', 'TUV Crane Operator Card'],
      description:
        'Operators for 80-ton mobile cranes and 35-ton hydraulic excavators supporting berth reinforcement and container yard grading.',
      status: 'active',
      applicationsCount: 0,
      createdAt: '2026-11-13T14:00:00.000Z',
    },
    {
      id: 'job-105',
      supplierId: 'usr-sup-1',
      supplierName: 'Al-Rowad Civil & MEP Contracting Co.',
      supplierCity: 'Riyadh',
      supplierCrNumber: '1010482910',
      supplierApprovalStatus: 'approved',
      approvalStatus: 'approved',
      title: 'HVAC Chiller & BMS Technicians',
      category: 'MEP & Electrical',
      city: 'Jeddah',
      siteLocation: 'Jeddah Central Waterfront District',
      headcount: 14,
      salaryMin: 3900,
      salaryMax: 5100,
      contractType: 'Monthly Transfer (Iqama)',
      durationMonths: 18,
      shiftHours: '8 hrs / 6 days',
      accommodationIncluded: true,
      transportIncluded: true,
      mealsIncluded: false,
      iqamaTransferableRequired: true,
      certifications: ['HVAC Diploma', 'District Cooling Maintenance'],
      description:
        'Commissioning and preventive maintenance technicians for district cooling plant rooms, variable air volume units, and chilled water risers.',
      status: 'active',
      applicationsCount: 0,
      createdAt: '2026-11-12T09:10:00.000Z',
    },
    {
      id: 'job-106',
      supplierId: 'usr-sup-2',
      supplierName: 'Al-Khaleej Industrial Services',
      supplierCity: 'Jubail',
      supplierCrNumber: '2050391844',
      supplierApprovalStatus: 'approved',
      approvalStatus: 'approved',
      title: 'Forklift & Cold-Chain Warehouse Coordinators',
      category: 'Logistics & Warehouse',
      city: 'Al Khobar',
      siteLocation: 'Dammam–Khobar Logistics Park',
      headcount: 20,
      salaryMin: 3100,
      salaryMax: 4000,
      contractType: 'Project Contract',
      durationMonths: 12,
      shiftHours: '8 hrs / 6 days',
      accommodationIncluded: false,
      transportIncluded: true,
      mealsIncluded: false,
      iqamaTransferableRequired: false,
      certifications: ['Reach Truck Operator Card', 'WMS Scanner Experience'],
      description:
        'Inbound receiving, pallet racking, and dispatch tallying across temperature-controlled medical and food distribution bays.',
      status: 'active',
      applicationsCount: 0,
      createdAt: '2026-11-11T15:35:00.000Z',
    },
    {
      id: 'job-107',
      supplierId: 'usr-sup-1',
      supplierName: 'Al-Rowad Civil & MEP Contracting Co.',
      supplierCity: 'Riyadh',
      supplierCrNumber: '1010482910',
      supplierApprovalStatus: 'approved',
      approvalStatus: 'approved',
      title: 'Hospitality Facility & Preventive Maintenance Crew',
      category: 'Facility & Hospitality',
      city: 'Madinah',
      siteLocation: 'Central Haram Hospitality Corridor',
      headcount: 30,
      salaryMin: 2900,
      salaryMax: 3800,
      contractType: 'Ajeer / Temporary',
      durationMonths: 10,
      shiftHours: '8 hrs / 6 days',
      accommodationIncluded: true,
      transportIncluded: true,
      mealsIncluded: true,
      iqamaTransferableRequired: false,
      certifications: ['General MEP Handyman', 'Safety & Fire Watch'],
      description:
        'Multi-trade facility technicians (plumbing, lighting, carpentry touch-up) supporting high-occupancy hotel towers during peak seasonal demand.',
      status: 'active',
      applicationsCount: 0,
      createdAt: '2026-11-10T08:00:00.000Z',
    },
  ];

  const applications: JobApplication[] = [
    {
      id: 'app-501',
      jobId: 'job-101',
      jobTitle: 'High-Voltage Industrial Electricians',
      jobCity: 'Riyadh',
      supplierId: 'usr-sup-1',
      supplierName: 'Al-Rowad Civil & MEP Contracting Co.',
      workerId: 'usr-wrk-1',
      workerName: 'Tariq Al-Mansoor',
      workerPhone: '+966 53 608 4419',
      workerTrade: 'Senior MEP Electrician',
      workerCity: 'Riyadh',
      iqamaTransferable: true,
      note: '7 years across Riyadh substation & commercial tower MEP packages. Hold valid SEC safety permit and ready for immediate site mobilization.',
      status: 'shortlisted',
      createdAt: '2026-11-15T08:15:00.000Z',
    },
  ];

  return { users, jobs, applications };
}

class MarketplaceStore {
  private data: DatabaseSchema;

  constructor() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(raw) as DatabaseSchema;
      } catch {
        this.data = createSeedData();
        this.persist();
      }
    } else {
      this.data = createSeedData();
      this.persist();
    }
  }

  private persist(): void {
    fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
  }

  findUserByEmail(email: string): StoredUser | undefined {
    const normalized = email.trim().toLowerCase();
    return this.data.users.find((u) => u.email.toLowerCase() === normalized);
  }

  findUserById(id: string): StoredUser | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  createUser(params: {
    email: string;
    password: string;
    name: string;
    role: UserRole;
    phone: string;
    city: string;
    trade?: string;
    yearsExperience?: number;
    iqamaTransferable?: boolean;
    companyName?: string;
    crNumber?: string;
    bio?: string;
    specialties?: string[];
  }): StoredUser {
    const { hash, salt } = hashPassword(params.password);
    const id = `usr-${crypto.randomUUID().slice(0, 8)}`;
    const user: StoredUser = {
      id,
      email: params.email.trim().toLowerCase(),
      name: params.name.trim(),
      role: params.role,
      phone: params.phone.trim(),
      city: params.city,
      trade: params.trade?.trim(),
      yearsExperience: params.yearsExperience,
      iqamaTransferable: params.iqamaTransferable,
      companyName: params.companyName?.trim(),
      crNumber: params.crNumber?.trim(),
      approvalStatus: params.role === 'supplier' ? 'pending' : undefined,
      bio: params.bio?.trim(),
      specialties: params.specialties,
      nitaqatBand: params.role === 'supplier' ? 'Pending Verification' : undefined,
      yearsActive: params.role === 'supplier' ? 1 : undefined,
      createdAt: new Date().toISOString(),
      passwordHash: hash,
      salt,
    };
    this.data.users.push(user);
    this.persist();
    return user;
  }

  updateSupplierProfile(
    supplierId: string,
    updates: Partial<
      Pick<
        StoredUser,
        'companyName' | 'phone' | 'city' | 'bio' | 'specialties' | 'crNumber' | 'officeAddress' | 'officeMapLink'
      >
    >
  ): StoredUser | undefined {
    const user = this.findUserById(supplierId);
    if (!user || user.role !== 'supplier') return undefined;
    if (updates.companyName !== undefined) user.companyName = updates.companyName.trim();
    if (updates.phone !== undefined) user.phone = updates.phone.trim();
    if (updates.city !== undefined) user.city = updates.city;
    if (updates.bio !== undefined) user.bio = updates.bio.trim();
    if (updates.specialties !== undefined) user.specialties = updates.specialties;
    if (updates.crNumber !== undefined) user.crNumber = updates.crNumber.trim();
    if (updates.officeAddress !== undefined) user.officeAddress = updates.officeAddress.trim();
    if (updates.officeMapLink !== undefined) user.officeMapLink = updates.officeMapLink.trim();

    // Propagate updated supplier name/city to their jobs
    this.data.jobs.forEach((job) => {
      if (job.supplierId === supplierId) {
        job.supplierName = user.companyName || user.name;
        job.supplierCity = user.city;
        job.supplierCrNumber = user.crNumber || '';
      }
    });

    this.persist();
    return user;
  }

  listSuppliers(): PublicUser[] {
    return this.data.users
      .filter((u) => u.role === 'supplier')
      .map(toPublicUser)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  setSupplierApprovalStatus(
    supplierId: string,
    status: SupplierApprovalStatus,
    adminNote?: string
  ): StoredUser | undefined {
    const user = this.findUserById(supplierId);
    if (!user || user.role !== 'supplier') return undefined;
    user.approvalStatus = status;
    user.adminNote = adminNote?.trim() || (status === 'approved' ? 'Verified CR & Qiwa standing.' : '');
    if (status === 'approved' && (!user.nitaqatBand || user.nitaqatBand === 'Pending Verification')) {
      user.nitaqatBand = 'Green';
    }
    this.data.jobs.forEach((job) => {
      if (job.supplierId === supplierId) {
        job.supplierApprovalStatus = status;
      }
    });
    this.persist();
    return user;
  }

  listJobs(options?: { includeUnpublished?: boolean }): JobPost[] {
    const jobs = options?.includeUnpublished
      ? [...this.data.jobs]
      : this.data.jobs.filter(
          (j) => j.status === 'active' && j.supplierApprovalStatus === 'approved'
        );
    return jobs.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  findJobById(id: string): JobPost | undefined {
    return this.data.jobs.find((j) => j.id === id);
  }

  createJob(supplier: StoredUser, input: Omit<JobPost, 'id' | 'supplierId' | 'supplierName' | 'supplierCity' | 'supplierCrNumber' | 'supplierApprovalStatus' | 'approvalStatus' | 'status' | 'applicationsCount' | 'createdAt'>): JobPost {
    const job: JobPost = {
      id: `job-${crypto.randomUUID().slice(0, 6)}`,
      supplierId: supplier.id,
      supplierName: supplier.companyName || supplier.name,
      supplierCity: supplier.city,
      supplierCrNumber: supplier.crNumber || 'N/A',
      supplierApprovalStatus: supplier.approvalStatus || 'pending',
      approvalStatus: 'approved',
      postType: input.postType || (input.circularImageUrl ? 'circular_image' : 'structured'),
      circularImageUrl: input.circularImageUrl,
      title: input.title?.trim(),
      category: input.category,
      city: input.city,
      siteLocation: input.siteLocation?.trim(),
      headcount: input.headcount !== undefined ? Number(input.headcount) : undefined,
      salaryMin: input.salaryMin !== undefined ? Number(input.salaryMin) : undefined,
      salaryMax: input.salaryMax !== undefined ? Number(input.salaryMax) : undefined,
      contractType: input.contractType,
      durationMonths: input.durationMonths !== undefined ? Number(input.durationMonths) : undefined,
      shiftHours: input.shiftHours?.trim(),
      accommodationIncluded: input.accommodationIncluded,
      transportIncluded: input.transportIncluded,
      mealsIncluded: input.mealsIncluded,
      iqamaTransferableRequired: input.iqamaTransferableRequired,
      certifications: input.certifications?.map((c) => c.trim()).filter(Boolean),
      description: input.description?.trim(),
      status: 'active',
      applicationsCount: 0,
      createdAt: new Date().toISOString(),
    };
    this.data.jobs.unshift(job);
    this.persist();
    return job;
  }

  updateJobStatus(jobId: string, status: JobStatus): JobPost | undefined {
    const job = this.findJobById(jobId);
    if (!job) return undefined;
    job.status = status;
    this.persist();
    return job;
  }

  deleteJob(jobId: string): boolean {
    const idx = this.data.jobs.findIndex((j) => j.id === jobId);
    if (idx === -1) return false;
    this.data.jobs.splice(idx, 1);
    this.data.applications = this.data.applications.filter((a) => a.jobId !== jobId);
    this.persist();
    return true;
  }

  findApplication(jobId: string, workerId: string): JobApplication | undefined {
    return this.data.applications.find((a) => a.jobId === jobId && a.workerId === workerId);
  }

  createApplication(job: JobPost, worker: StoredUser, note: string, phoneOverride?: string, iqamaOverride?: boolean): JobApplication {
    const app: JobApplication = {
      id: `app-${crypto.randomUUID().slice(0, 6)}`,
      jobId: job.id,
      jobTitle: job.title || `Job Circular · ${job.supplierName}`,
      jobCity: job.city || job.supplierCity || 'Saudi Arabia',
      supplierId: job.supplierId,
      supplierName: job.supplierName,
      workerId: worker.id,
      workerName: worker.name,
      workerPhone: phoneOverride?.trim() || worker.phone,
      workerTrade: worker.trade || 'Skilled Tradesperson',
      workerCity: worker.city,
      iqamaTransferable: iqamaOverride !== undefined ? iqamaOverride : Boolean(worker.iqamaTransferable),
      note: note.trim(),
      status: 'submitted',
      createdAt: new Date().toISOString(),
    };
    this.data.applications.unshift(app);
    job.applicationsCount = this.data.applications.filter((a) => a.jobId === job.id).length;
    this.persist();
    return app;
  }

  listApplicationsForWorker(workerId: string): JobApplication[] {
    return this.data.applications
      .filter((a) => a.workerId === workerId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  listApplicationsForSupplier(supplierId: string): JobApplication[] {
    return this.data.applications
      .filter((a) => a.supplierId === supplierId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  updateApplicationStatus(appId: string, supplierId: string, status: ApplicationStatus): JobApplication | undefined {
    const app = this.data.applications.find((a) => a.id === appId && a.supplierId === supplierId);
    if (!app) return undefined;
    app.status = status;
    this.persist();
    return app;
  }

  getAllWorkersCount(): number {
    return this.data.users.filter((u) => u.role === 'worker').length;
  }
}

export const store = new MarketplaceStore();
