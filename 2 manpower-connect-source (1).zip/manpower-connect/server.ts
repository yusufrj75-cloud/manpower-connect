import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { store, toPublicUser, verifyPassword } from './server/store.ts';
import type { StoredUser } from './server/store.ts';
import type { ApplicationStatus, JobStatus, SupplierApprovalStatus, UserRole } from './src/types.ts';

const PORT = Number(process.env.PORT) || 3000;
const TOKEN_SECRET = process.env.AUTH_SECRET || 'manpower-connect-ksa-dev-signing-key-2026';
const UPLOADS_DIR = path.resolve(process.cwd(), 'data', 'uploads');

function ensureUploadsDir(): void {
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}

function isValidImageMagicBytes(buf: Buffer, ext: 'jpg' | 'png'): boolean {
  if (buf.length < 8) return false;
  if (ext === 'png') {
    return buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
  }
  return buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
}

interface TokenPayload {
  sub: string;
  role: UserRole;
  exp: number;
}

function signToken(user: StoredUser): string {
  const payload: TokenPayload = {
    sub: user.id,
    role: user.role,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyToken(token: string): TokenPayload | null {
  try {
    const [encoded, sig] = token.split('.');
    if (!encoded || !sig) return null;
    const expected = crypto.createHmac('sha256', TOKEN_SECRET).update(encoded).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) {
      return null;
    }
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf-8')) as TokenPayload;
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

interface AuthenticatedRequest extends Request {
  user?: StoredUser;
}

function attachUser(req: AuthenticatedRequest, _res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  if (header && header.startsWith('Bearer ')) {
    const token = header.slice(7);
    const payload = verifyToken(token);
    if (payload) {
      const user = store.findUserById(payload.sub);
      if (user) req.user = user;
    }
  }
  next();
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }
  next();
}

async function startServer() {
  ensureUploadsDir();
  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use(attachUser);

  // Serve uploaded job circular images
  app.use('/uploads', express.static(UPLOADS_DIR, { maxAge: '7d' }));

  // Health
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'MANPOWER CONNECT API' });
  });

  // Upload Job Circular Image (JPG, JPEG, PNG)
  app.post('/api/uploads/circular', (req, res) => {
    const { dataUrl, mimeType, base64Data } = req.body ?? {};

    let resolvedMime = typeof mimeType === 'string' ? mimeType.toLowerCase().trim() : '';
    let rawBase64 = typeof base64Data === 'string' ? base64Data.trim() : '';

    if (typeof dataUrl === 'string' && dataUrl.startsWith('data:')) {
      const match = /^data:(image\/(?:jpeg|jpg|png));base64,([A-Za-z0-9+/=\s]+)$/i.exec(dataUrl);
      if (!match) {
        res.status(400).json({ error: 'Only JPG, JPEG, or PNG circular images are supported.' });
        return;
      }
      resolvedMime = match[1].toLowerCase();
      rawBase64 = match[2].replace(/\s+/g, '');
    }

    if (resolvedMime !== 'image/jpeg' && resolvedMime !== 'image/jpg' && resolvedMime !== 'image/png') {
      res.status(400).json({ error: 'Invalid file format. Please upload a JPG, JPEG, or PNG image.' });
      return;
    }

    if (!rawBase64) {
      res.status(400).json({ error: 'Image data is required.' });
      return;
    }

    const buffer = Buffer.from(rawBase64, 'base64');
    if (buffer.length === 0 || buffer.length > 8 * 1024 * 1024) {
      res.status(400).json({ error: 'Circular image must be between 1 byte and 8 MB.' });
      return;
    }

    const ext: 'jpg' | 'png' = resolvedMime === 'image/png' ? 'png' : 'jpg';
    if (!isValidImageMagicBytes(buffer, ext)) {
      res.status(400).json({ error: 'File content does not match a valid JPG or PNG image.' });
      return;
    }

    ensureUploadsDir();
    const safeFilename = `circular-${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${ext}`;
    const targetPath = path.join(UPLOADS_DIR, safeFilename);
    fs.writeFileSync(targetPath, buffer);

    res.status(201).json({ imageUrl: `/uploads/${safeFilename}` });
  });

  // Auth: Register
  app.post('/api/auth/register', (req, res) => {
    const {
      email,
      password,
      name,
      role,
      phone,
      city,
      trade,
      yearsExperience,
      iqamaTransferable,
      companyName,
      crNumber,
      bio,
      specialties,
    } = req.body ?? {};

    if (!email || !password || !name || !role || !city) {
      res.status(400).json({ error: 'Name, email, password, role, and city are required.' });
      return;
    }
    if (role !== 'worker' && role !== 'supplier') {
      res.status(400).json({ error: 'Registration role must be worker or supplier.' });
      return;
    }
    if (String(password).length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters.' });
      return;
    }
    if (role === 'supplier' && (!companyName || !crNumber)) {
      res.status(400).json({ error: 'Company name and Saudi Commercial Registration (CR) number are required for suppliers.' });
      return;
    }
    if (store.findUserByEmail(String(email))) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const created = store.createUser({
      email: String(email),
      password: String(password),
      name: String(name),
      role,
      phone: String(phone || '+966 50 000 0000'),
      city: String(city),
      trade: trade ? String(trade) : undefined,
      yearsExperience: yearsExperience !== undefined ? Number(yearsExperience) : undefined,
      iqamaTransferable: Boolean(iqamaTransferable),
      companyName: companyName ? String(companyName) : undefined,
      crNumber: crNumber ? String(crNumber) : undefined,
      bio: bio ? String(bio) : undefined,
      specialties: Array.isArray(specialties) ? specialties.map(String) : undefined,
    });

    const token = signToken(created);
    res.status(201).json({ token, user: toPublicUser(created) });
  });

  // Auth: Login
  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body ?? {};
    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }
    const user = store.findUserByEmail(String(email));
    if (!user || !verifyPassword(String(password), user.salt, user.passwordHash)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }
    const token = signToken(user);
    res.json({ token, user: toPublicUser(user) });
  });

  // Auth: Me
  app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
    res.json({ user: toPublicUser(req.user!) });
  });

  // Marketplace public stats for Welcome / Header context
  app.get('/api/marketplace/stats', (_req, res) => {
    const activeJobs = store.listJobs();
    const suppliers = store.listSuppliers();
    const approvedSuppliers = suppliers.filter((s) => s.approvalStatus === 'approved');
    const totalPositions = activeJobs.reduce((acc, j) => acc + (j.headcount || 1), 0);
    res.json({
      activeJobsCount: activeJobs.length,
      approvedSuppliersCount: approvedSuppliers.length,
      totalPositions,
      registeredWorkersCount: store.getAllWorkersCount(),
    });
  });

  // Jobs: List & Filter
  app.get('/api/jobs', (req: AuthenticatedRequest, res) => {
    const {
      q,
      city,
      category,
      contractType,
      minSalary,
      accommodation,
      transport,
      supplierId,
      sortBy,
    } = req.query;

    const isAdmin = req.user?.role === 'admin';
    const isOwnerFilter = supplierId && req.user?.id === String(supplierId);

    let jobs = store.listJobs({ includeUnpublished: Boolean(isAdmin || isOwnerFilter) });

    if (supplierId) {
      jobs = jobs.filter((j) => j.supplierId === String(supplierId));
    }
    if (q && String(q).trim()) {
      const term = String(q).trim().toLowerCase();
      jobs = jobs.filter(
        (j) =>
          (j.title || '').toLowerCase().includes(term) ||
          j.supplierName.toLowerCase().includes(term) ||
          (j.category || '').toLowerCase().includes(term) ||
          (j.city || j.supplierCity).toLowerCase().includes(term) ||
          (j.siteLocation || '').toLowerCase().includes(term) ||
          (j.description || '').toLowerCase().includes(term)
      );
    }
    if (city && city !== 'All') {
      jobs = jobs.filter((j) => (j.city || j.supplierCity) === String(city));
    }
    if (category && category !== 'All') {
      jobs = jobs.filter((j) => j.category === String(category));
    }
    if (contractType && contractType !== 'All') {
      jobs = jobs.filter((j) => j.contractType === String(contractType));
    }
    if (minSalary && Number(minSalary) > 0) {
      const min = Number(minSalary);
      jobs = jobs.filter((j) => (j.salaryMax || 0) >= min);
    }
    if (accommodation === 'true') {
      jobs = jobs.filter((j) => j.accommodationIncluded);
    }
    if (transport === 'true') {
      jobs = jobs.filter((j) => j.transportIncluded);
    }

    if (sortBy === 'salary_desc') {
      jobs.sort((a, b) => (b.salaryMax || 0) - (a.salaryMax || 0));
    } else if (sortBy === 'headcount_desc') {
      jobs.sort((a, b) => (b.headcount || 0) - (a.headcount || 0));
    } else {
      jobs.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    }

    res.json({ jobs });
  });

  // Jobs: Single job details
  app.get('/api/jobs/:id', (req: AuthenticatedRequest, res) => {
    const job = store.findJobById(String(req.params.id));
    if (!job) {
      res.status(404).json({ error: 'Job post not found.' });
      return;
    }
    const isVisible =
      (job.status === 'active' && job.supplierApprovalStatus === 'approved') ||
      req.user?.role === 'admin' ||
      req.user?.id === job.supplierId;

    if (!isVisible) {
      res.status(404).json({ error: 'Job post is currently unavailable.' });
      return;
    }

    const supplier = store.findUserById(job.supplierId);
    const hasApplied =
      req.user?.role === 'worker'
        ? Boolean(store.findApplication(job.id, req.user.id))
        : false;

    res.json({
      job,
      supplier: supplier ? toPublicUser(supplier) : null,
      hasApplied,
    });
  });

  // Jobs: Create (ONLY approved suppliers!)
  app.post('/api/jobs', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    if (user.role !== 'supplier') {
      res.status(403).json({ error: 'Only supplier accounts can publish job demand posts.' });
      return;
    }
    if (user.approvalStatus !== 'approved') {
      res.status(403).json({
        error:
          user.approvalStatus === 'rejected'
            ? 'Your supplier account was not approved. Please contact platform compliance.'
            : 'Your supplier account is pending admin approval. Only approved suppliers can publish jobs.',
        code: 'SUPPLIER_NOT_APPROVED',
      });
      return;
    }

    const {
      title,
      category,
      city,
      siteLocation,
      headcount,
      salaryMin,
      salaryMax,
      contractType,
      durationMonths,
      shiftHours,
      accommodationIncluded,
      transportIncluded,
      mealsIncluded,
      iqamaTransferableRequired,
      certifications,
      description,
    } = req.body ?? {};

    if (!title || !category || !city || !siteLocation || !headcount || !salaryMin || !salaryMax || !description) {
      res.status(400).json({ error: 'Please complete all required demand fields.' });
      return;
    }
    if (Number(headcount) < 1 || Number(salaryMin) < 500 || Number(salaryMax) < Number(salaryMin)) {
      res.status(400).json({ error: 'Headcount must be >= 1 and salary range must be valid.' });
      return;
    }

    const job = store.createJob(user, {
      title: String(title),
      category: String(category),
      city: String(city),
      siteLocation: String(siteLocation),
      headcount: Number(headcount),
      salaryMin: Number(salaryMin),
      salaryMax: Number(salaryMax),
      contractType: String(contractType || 'Project Contract'),
      durationMonths: Number(durationMonths || 12),
      shiftHours: String(shiftHours || '8 hrs / 6 days'),
      accommodationIncluded: Boolean(accommodationIncluded),
      transportIncluded: Boolean(transportIncluded),
      mealsIncluded: Boolean(mealsIncluded),
      iqamaTransferableRequired: Boolean(iqamaTransferableRequired),
      certifications: Array.isArray(certifications)
        ? certifications.map(String)
        : String(certifications || '')
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean),
      description: String(description),
    });

    res.status(201).json({ job });
  });

  // Jobs: Update status (owner supplier or admin)
  app.patch('/api/jobs/:id', requireAuth, (req: AuthenticatedRequest, res) => {
    const job = store.findJobById(String(req.params.id));
    if (!job) {
      res.status(404).json({ error: 'Job post not found.' });
      return;
    }
    if (req.user!.role !== 'admin' && req.user!.id !== job.supplierId) {
      res.status(403).json({ error: 'Not authorized to modify this job post.' });
      return;
    }
    const { status } = req.body ?? {};
    if (status !== 'active' && status !== 'paused' && status !== 'closed') {
      res.status(400).json({ error: 'Invalid job status.' });
      return;
    }
    const updated = store.updateJobStatus(job.id, status as JobStatus);
    res.json({ job: updated });
  });

  // Jobs: Delete
  app.delete('/api/jobs/:id', requireAuth, (req: AuthenticatedRequest, res) => {
    const job = store.findJobById(String(req.params.id));
    if (!job) {
      res.status(404).json({ error: 'Job post not found.' });
      return;
    }
    if (req.user!.role !== 'admin' && req.user!.id !== job.supplierId) {
      res.status(403).json({ error: 'Not authorized to delete this job post.' });
      return;
    }
    store.deleteJob(job.id);
    res.json({ deleted: true });
  });

  // Applications: Worker applies to a job
  app.post('/api/jobs/:id/apply', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.user!.role !== 'worker') {
      res.status(403).json({ error: 'Only worker accounts can apply to job demands.' });
      return;
    }
    const job = store.findJobById(String(req.params.id));
    if (!job || job.status !== 'active' || job.supplierApprovalStatus !== 'approved') {
      res.status(404).json({ error: 'This job demand is no longer accepting applications.' });
      return;
    }
    if (store.findApplication(job.id, req.user!.id)) {
      res.status(409).json({ error: 'You have already applied to this position.' });
      return;
    }
    const { note, phone, iqamaTransferable } = req.body ?? {};
    if (!note || !String(note).trim()) {
      res.status(400).json({ error: 'Please include a brief summary of your experience and availability.' });
      return;
    }
    const application = store.createApplication(
      job,
      req.user!,
      String(note),
      phone ? String(phone) : undefined,
      iqamaTransferable !== undefined ? Boolean(iqamaTransferable) : undefined
    );
    res.status(201).json({ application });
  });

  // Applications: List for current user
  app.get('/api/applications/me', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.user!.role === 'worker') {
      res.json({ applications: store.listApplicationsForWorker(req.user!.id) });
      return;
    }
    if (req.user!.role === 'supplier') {
      res.json({ applications: store.listApplicationsForSupplier(req.user!.id) });
      return;
    }
    res.json({ applications: [] });
  });

  // Applications: Supplier updates applicant status
  app.patch('/api/applications/:id', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.user!.role !== 'supplier') {
      res.status(403).json({ error: 'Only the hiring supplier can update application status.' });
      return;
    }
    const { status } = req.body ?? {};
    const validStatuses: ApplicationStatus[] = ['submitted', 'shortlisted', 'accepted', 'declined'];
    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid application status.' });
      return;
    }
    const updated = store.updateApplicationStatus(String(req.params.id), req.user!.id, status);
    if (!updated) {
      res.status(404).json({ error: 'Application not found.' });
      return;
    }
    res.json({ application: updated });
  });

  // Suppliers: List approved directory
  app.get('/api/suppliers', (_req, res) => {
    const suppliers = store.listSuppliers().filter((s) => s.approvalStatus === 'approved');
    res.json({ suppliers });
  });

  // Suppliers: Get single profile + jobs
  app.get('/api/suppliers/:id', (req: AuthenticatedRequest, res) => {
    const supplier = store.findUserById(String(req.params.id));
    if (!supplier || supplier.role !== 'supplier') {
      res.status(404).json({ error: 'Supplier not found.' });
      return;
    }
    const isOwnerOrAdmin = req.user?.id === supplier.id || req.user?.role === 'admin';
    const jobs = store
      .listJobs({ includeUnpublished: isOwnerOrAdmin })
      .filter((j) => j.supplierId === supplier.id);

    res.json({
      supplier: toPublicUser(supplier),
      jobs,
    });
  });

  // Suppliers: Update own profile
  app.patch('/api/suppliers/me', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.user!.role !== 'supplier') {
      res.status(403).json({ error: 'Only supplier accounts can edit a supplier profile.' });
      return;
    }
    const { companyName, phone, city, bio, specialties, crNumber, officeAddress, officeMapLink } =
      req.body ?? {};
    const updated = store.updateSupplierProfile(req.user!.id, {
      companyName,
      phone,
      city,
      bio,
      specialties: Array.isArray(specialties) ? specialties : undefined,
      crNumber,
      officeAddress,
      officeMapLink,
    });
    if (!updated) {
      res.status(404).json({ error: 'Supplier profile not found.' });
      return;
    }
    res.json({ user: toPublicUser(updated) });
  });

  // Admin: Overview
  app.get('/api/admin/overview', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.user!.role !== 'admin') {
      res.status(403).json({ error: 'Administrator privileges required.' });
      return;
    }
    const suppliers = store.listSuppliers();
    const jobs = store.listJobs({ includeUnpublished: true });
    res.json({
      suppliers,
      jobs,
      metrics: {
        pendingSuppliers: suppliers.filter((s) => s.approvalStatus === 'pending').length,
        approvedSuppliers: suppliers.filter((s) => s.approvalStatus === 'approved').length,
        rejectedSuppliers: suppliers.filter((s) => s.approvalStatus === 'rejected').length,
        activeJobs: jobs.filter((j) => j.status === 'active' && j.supplierApprovalStatus === 'approved').length,
        totalWorkersRequested: jobs
          .filter((j) => j.status === 'active' && j.supplierApprovalStatus === 'approved')
          .reduce((sum, j) => sum + (j.headcount || 1), 0),
        registeredWorkers: store.getAllWorkersCount(),
      },
    });
  });

  // Admin: Approve / Reject supplier
  app.patch('/api/admin/suppliers/:id/status', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.user!.role !== 'admin') {
      res.status(403).json({ error: 'Administrator privileges required.' });
      return;
    }
    const { approvalStatus, adminNote } = req.body ?? {};
    const valid: SupplierApprovalStatus[] = ['approved', 'pending', 'rejected'];
    if (!valid.includes(approvalStatus)) {
      res.status(400).json({ error: 'Invalid approval status.' });
      return;
    }
    const updated = store.setSupplierApprovalStatus(
      String(req.params.id),
      approvalStatus,
      adminNote ? String(adminNote) : undefined
    );
    if (!updated) {
      res.status(404).json({ error: 'Supplier not found.' });
      return;
    }
    res.json({ supplier: toPublicUser(updated) });
  });

  // Admin: Pause / Activate job
  app.patch('/api/admin/jobs/:id/status', requireAuth, (req: AuthenticatedRequest, res) => {
    if (req.user!.role !== 'admin') {
      res.status(403).json({ error: 'Administrator privileges required.' });
      return;
    }
    const { status } = req.body ?? {};
    if (status !== 'active' && status !== 'paused' && status !== 'closed') {
      res.status(400).json({ error: 'Invalid job status.' });
      return;
    }
    const updated = store.updateJobStatus(String(req.params.id), status);
    if (!updated) {
      res.status(404).json({ error: 'Job not found.' });
      return;
    }
    res.json({ job: updated });
  });

  // Vite or static serving
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MANPOWER CONNECT server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
