package com.manpowerconnect.sa;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
