import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  increment,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import type { User as FirebaseUser } from 'firebase/auth';
import { db, handleFirestoreError, OperationType } from '../firebase';
import type {
  ApplicationStatus,
  JobApplication,
  JobApprovalStatus,
  JobPost,
  JobStatus,
  PublicUser,
  SupplierApprovalStatus,
} from '../types';

export const BOOTSTRAPPED_ADMIN_EMAIL = 'yusufrj75@gmail.com';

function timestampToIso(val: unknown): string {
  if (val instanceof Timestamp) {
    return val.toDate().toISOString();
  }
  if (typeof val === 'string') return val;
  return new Date().toISOString();
}

function clampStr(val: string | undefined, max: number): string {
  return (val || '').trim().slice(0, max);
}

export async function checkIsAdmin(firebaseUser: FirebaseUser | null): Promise<boolean> {
  if (!firebaseUser || !firebaseUser.emailVerified) return false;
  if (firebaseUser.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL) return true;
  try {
    const adminSnap = await getDoc(doc(db, 'admins', firebaseUser.uid));
    return adminSnap.exists();
  } catch {
    return false;
  }
}

export async function fetchUserSessionProfile(
  firebaseUser: FirebaseUser
): Promise<PublicUser | null> {
  const userPath = `users/${firebaseUser.uid}`;
  let userSnap;
  try {
    userSnap = await getDoc(doc(db, 'users', firebaseUser.uid));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, userPath);
  }

  const isAdminUser = await checkIsAdmin(firebaseUser);

  if (!userSnap.exists()) {
    if (isAdminUser) {
      return {
        id: firebaseUser.uid,
        email: firebaseUser.email || BOOTSTRAPPED_ADMIN_EMAIL,
        name: firebaseUser.displayName || 'Platform Administrator',
        role: 'admin',
        phone: '+966 50 000 0001',
        city: 'Riyadh',
        emailVerified: firebaseUser.emailVerified,
        createdAt: new Date().toISOString(),
      };
    }
    return null;
  }

  const pubData = userSnap.data();

  // Read isolated PII subcollection (owner or admin only)
  let privData: Record<string, unknown> = {};
  if (firebaseUser.emailVerified) {
    try {
      const privSnap = await getDoc(doc(db, 'users', firebaseUser.uid, 'private', 'profile'));
      if (privSnap.exists()) {
        privData = privSnap.data();
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `users/${firebaseUser.uid}/private/profile`);
    }
  }

  const role = isAdminUser ? 'admin' : (pubData.role as PublicUser['role']);

  const baseUser: PublicUser = {
    id: firebaseUser.uid,
    email: String(privData.email || firebaseUser.email || ''),
    name: String(pubData.displayName || firebaseUser.displayName || 'User'),
    role,
    phone: String(privData.phone || '+966 50 000 0000'),
    city: String(pubData.city || 'Riyadh'),
    emailVerified: firebaseUser.emailVerified,
    trade: pubData.trade ? String(pubData.trade) : undefined,
    yearsExperience:
      typeof privData.yearsExperience === 'number' ? privData.yearsExperience : undefined,
    iqamaTransferable:
      typeof privData.iqamaTransferable === 'boolean' ? privData.iqamaTransferable : undefined,
    iqamaReference: privData.iqamaReference ? String(privData.iqamaReference) : undefined,
    createdAt: timestampToIso(pubData.createdAt),
  };

  if (role === 'supplier') {
    const supplierId = firebaseUser.uid;
    try {
      const supSnap = await getDoc(doc(db, 'suppliers', supplierId));
      if (supSnap.exists()) {
        const s = supSnap.data();
        baseUser.supplierDocId = supplierId;
        baseUser.companyName = String(s.companyName || baseUser.name);
        baseUser.businessPhone = String(s.businessPhone || baseUser.phone);
        baseUser.whatsappNumber = String(s.whatsappNumber || baseUser.phone);
        baseUser.officeAddress = s.officeAddress ? String(s.officeAddress) : undefined;
        baseUser.officeMapLink = s.officeMapLink ? String(s.officeMapLink) : undefined;
        baseUser.bio = s.bio ? String(s.bio) : undefined;
        baseUser.specialties = Array.isArray(s.specialties) ? s.specialties.map(String) : [];
        baseUser.nitaqatBand = s.nitaqatBand ? String(s.nitaqatBand) : undefined;
        baseUser.yearsActive = typeof s.yearsActive === 'number' ? s.yearsActive : 1;
        baseUser.approvalStatus = s.approvalStatus as SupplierApprovalStatus;
        baseUser.adminNote = s.adminNote ? String(s.adminNote) : undefined;
      }

      if (firebaseUser.emailVerified) {
        const docsSnap = await getDoc(doc(db, 'suppliers', supplierId, 'private', 'documents'));
        if (docsSnap.exists()) {
          const d = docsSnap.data();
          baseUser.crNumber = String(d.crNumber || '');
          baseUser.qiwaId = d.qiwaId ? String(d.qiwaId) : undefined;
          baseUser.gosiReference = d.gosiReference ? String(d.gosiReference) : undefined;
          baseUser.crDocumentLabel = d.crDocumentLabel ? String(d.crDocumentLabel) : undefined;
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `suppliers/${supplierId}`);
    }
  }

  return baseUser;
}

export async function completeUserOnboarding(
  firebaseUser: FirebaseUser,
  input: {
    role: 'worker' | 'supplier';
    name: string;
    phone: string;
    city: string;
    trade?: string;
    yearsExperience?: number;
    iqamaTransferable?: boolean;
    companyName?: string;
    officeAddress?: string;
    officeMapLink?: string;
    crNumber?: string;
    qiwaId?: string;
    gosiReference?: string;
    bio?: string;
    specialties?: string[];
  }
): Promise<PublicUser> {
  const uid = firebaseUser.uid;
  const batch = writeBatch(db);
  const now = serverTimestamp();

  const userPublicData: Record<string, unknown> = {
    uid,
    displayName: clampStr(input.name, 120) || 'Marketplace User',
    role: input.role,
    city: clampStr(input.city, 80) || 'Riyadh',
    createdAt: now,
    updatedAt: now,
  };
  if (input.role === 'worker' && input.trade) {
    userPublicData.trade = clampStr(input.trade, 100);
  }

  batch.set(doc(db, 'users', uid), userPublicData);

  const userPrivateData: Record<string, unknown> = {
    uid,
    email: clampStr(firebaseUser.email || '', 180),
    phone: clampStr(input.phone, 32) || '+966 50 000 0000',
    updatedAt: now,
  };
  if (input.role === 'worker') {
    userPrivateData.yearsExperience = Math.max(0, Math.min(60, Number(input.yearsExperience || 1)));
    userPrivateData.iqamaTransferable = Boolean(input.iqamaTransferable);
  }

  batch.set(doc(db, 'users', uid, 'private', 'profile'), userPrivateData);

  if (input.role === 'supplier') {
    const phoneClean = clampStr(input.phone, 32) || '+966 50 000 0000';
    const mapLinkClean = clampStr(input.officeMapLink, 600);
    batch.set(doc(db, 'suppliers', uid), {
      id: uid,
      ownerUid: uid,
      companyName: clampStr(input.companyName || input.name, 160),
      contactName: clampStr(input.name, 120),
      city: clampStr(input.city, 80) || 'Riyadh',
      businessPhone: phoneClean,
      whatsappNumber: phoneClean,
      officeAddress: clampStr(input.officeAddress, 300),
      officeMapLink: /^https?:\/\/.+/i.test(mapLinkClean) ? mapLinkClean : '',
      bio: clampStr(input.bio || 'Saudi Arabia manpower and contracting provider.', 1000),
      specialties: (input.specialties || []).slice(0, 10),
      nitaqatBand: 'Pending Verification',
      yearsActive: 1,
      approvalStatus: 'pending',
      adminNote: 'Awaiting CR & Qiwa verification by platform administration.',
      createdAt: now,
      updatedAt: now,
    });

    batch.set(doc(db, 'suppliers', uid, 'private', 'documents'), {
      supplierId: uid,
      ownerUid: uid,
      crNumber: clampStr(input.crNumber || 'PENDING-CR', 32),
      qiwaId: clampStr(input.qiwaId, 64),
      gosiReference: clampStr(input.gosiReference, 64),
      crDocumentLabel: `CR-${clampStr(input.crNumber, 32)}`,
      updatedAt: now,
    });
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
  }

  const loaded = await fetchUserSessionProfile(firebaseUser);
  if (!loaded) throw new Error('Unable to load user profile after registration.');
  return loaded;
}

function mapJobDoc(id: string, d: Record<string, unknown>): JobPost {
  const isCircular = d.postType === 'circular_image' || Boolean(d.circularImageUrl);
  return {
    id,
    supplierId: String(d.supplierId || ''),
    ownerUid: String(d.ownerUid || ''),
    supplierName: String(d.supplierName || ''),
    supplierCity: String(d.supplierCity || ''),
    supplierApprovalStatus: 'approved',
    approvalStatus: (d.approvalStatus as JobApprovalStatus) || 'approved',
    adminNote: d.adminNote ? String(d.adminNote) : undefined,
    postType: isCircular ? 'circular_image' : 'structured',
    circularImageUrl: d.circularImageUrl ? String(d.circularImageUrl) : undefined,
    title: d.title ? String(d.title) : undefined,
    category: d.category ? String(d.category) : undefined,
    city: d.city ? String(d.city) : undefined,
    siteLocation: d.siteLocation ? String(d.siteLocation) : undefined,
    headcount: typeof d.headcount === 'number' ? d.headcount : undefined,
    salaryMin: typeof d.salaryMin === 'number' ? d.salaryMin : undefined,
    salaryMax: typeof d.salaryMax === 'number' ? d.salaryMax : undefined,
    contractType: d.contractType ? String(d.contractType) : undefined,
    durationMonths: typeof d.durationMonths === 'number' ? d.durationMonths : undefined,
    shiftHours: d.shiftHours ? String(d.shiftHours) : undefined,
    accommodationIncluded:
      typeof d.accommodationIncluded === 'boolean' ? d.accommodationIncluded : undefined,
    transportIncluded:
      typeof d.transportIncluded === 'boolean' ? d.transportIncluded : undefined,
    mealsIncluded: typeof d.mealsIncluded === 'boolean' ? d.mealsIncluded : undefined,
    iqamaTransferableRequired:
      typeof d.iqamaTransferableRequired === 'boolean' ? d.iqamaTransferableRequired : undefined,
    certifications: Array.isArray(d.certifications) ? d.certifications.map(String) : undefined,
    description: d.description ? String(d.description) : undefined,
    status: (d.status as JobStatus) || 'active',
    applicationsCount: Number(d.applicationsCount || 0),
    createdAt: timestampToIso(d.createdAt),
    updatedAt: timestampToIso(d.updatedAt),
    isDemo: false,
  };
}

function mapSupplierDoc(id: string, s: Record<string, unknown>): PublicUser {
  return {
    id,
    supplierDocId: id,
    email: '',
    name: String(s.contactName || s.companyName || ''),
    role: 'supplier',
    phone: String(s.businessPhone || ''),
    businessPhone: String(s.businessPhone || ''),
    whatsappNumber: String(s.whatsappNumber || s.businessPhone || ''),
    officeAddress: s.officeAddress ? String(s.officeAddress) : undefined,
    officeMapLink: s.officeMapLink ? String(s.officeMapLink) : undefined,
    city: String(s.city || 'Riyadh'),
    companyName: String(s.companyName || ''),
    bio: s.bio ? String(s.bio) : undefined,
    specialties: Array.isArray(s.specialties) ? s.specialties.map(String) : [],
    nitaqatBand: s.nitaqatBand ? String(s.nitaqatBand) : undefined,
    yearsActive: typeof s.yearsActive === 'number' ? s.yearsActive : 1,
    approvalStatus: (s.approvalStatus as SupplierApprovalStatus) || 'pending',
    adminNote: s.adminNote ? String(s.adminNote) : undefined,
    createdAt: timestampToIso(s.createdAt),
    isDemo: false,
  };
}

export async function listApprovedLiveJobs(): Promise<JobPost[]> {
  try {
    const q = query(
      collection(db, 'jobs'),
      where('approvalStatus', '==', 'approved'),
      where('status', '==', 'active')
    );
    const snap = await getDocs(q);
    return snap.docs
      .map((docSnap) => mapJobDoc(docSnap.id, docSnap.data()))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'jobs');
  }
}

export async function listMySupplierJobs(ownerUid: string): Promise<JobPost[]> {
  try {
    const q = query(collection(db, 'jobs'), where('ownerUid', '==', ownerUid));
    const snap = await getDocs(q);
    return snap.docs
      .map((docSnap) => mapJobDoc(docSnap.id, docSnap.data()))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'jobs');
  }
}

export async function getLiveJobDetails(
  jobId: string,
  viewer: PublicUser | null
): Promise<{ job: JobPost; supplier: PublicUser | null; hasApplied: boolean }> {
  let jobSnap;
  try {
    jobSnap = await getDoc(doc(db, 'jobs', jobId));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `jobs/${jobId}`);
  }

  if (!jobSnap.exists()) {
    throw new Error('Job post not found.');
  }
  const job = mapJobDoc(jobSnap.id, jobSnap.data());

  let supplier: PublicUser | null = null;
  if (job.supplierId) {
    try {
      const supSnap = await getDoc(doc(db, 'suppliers', job.supplierId));
      if (supSnap.exists()) {
        supplier = mapSupplierDoc(supSnap.id, supSnap.data());
        job.businessPhone = supplier.businessPhone;
        job.whatsappNumber = supplier.whatsappNumber;
      }
    } catch {
      // Non-fatal if supplier is pending and viewer is guest
    }
  }

  let hasApplied = false;
  if (viewer?.role === 'worker') {
    try {
      const appQ = query(
        collection(db, 'applications'),
        where('workerId', '==', viewer.id),
        where('jobId', '==', jobId)
      );
      const appSnap = await getDocs(appQ);
      hasApplied = !appSnap.empty;
    } catch {
      hasApplied = false;
    }
  }

  return { job, supplier, hasApplied };
}

export interface JobMutationInput {
  title: string;
  category: string;
  city: string;
  siteLocation: string;
  headcount: number;
  salaryMin: number;
  salaryMax: number;
  contractType: string;
  durationMonths: number;
  shiftHours: string;
  accommodationIncluded: boolean;
  transportIncluded: boolean;
  mealsIncluded: boolean;
  iqamaTransferableRequired: boolean;
  certifications: string[];
  description: string;
}

async function fileToOptimizedDataUrl(file: File): Promise<string> {
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
  const lowerName = file.name.toLowerCase();
  const hasAllowedExt =
    lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg') || lowerName.endsWith('.png');

  if (!allowedTypes.includes(file.type.toLowerCase()) && !hasAllowedExt) {
    throw new Error('Only JPG, JPEG, or PNG images are accepted.');
  }

  const rawDataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Could not read the selected image file.'));
    reader.readAsDataURL(file);
  });

  // Resize only very large photos (> 1600px wide or > 2200px tall) so circular text stays sharp
  return new Promise<string>((resolve) => {
    const img = new Image();
    img.onload = () => {
      const maxW = 1600;
      const maxH = 2200;
      let { width, height } = img;

      if (width <= maxW && height <= maxH && file.size <= 3.5 * 1024 * 1024) {
        resolve(rawDataUrl);
        return;
      }

      const scale = Math.min(maxW / width, maxH / height, 1);
      width = Math.round(width * scale);
      height = Math.round(height * scale);

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(rawDataUrl);
        return;
      }
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      const outType = file.type.toLowerCase() === 'image/png' && file.size <= 2 * 1024 * 1024
        ? 'image/png'
        : 'image/jpeg';
      resolve(canvas.toDataURL(outType, 0.9));
    };
    img.onerror = () => resolve(rawDataUrl);
    img.src = rawDataUrl;
  });
}

export async function uploadCircularImage(file: File): Promise<string> {
  const dataUrl = await fileToOptimizedDataUrl(file);
  const res = await fetch('/api/uploads/circular', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ dataUrl, fileName: file.name }),
  });

  const json = (await res.json().catch(() => ({}))) as { imageUrl?: string; error?: string };
  if (!res.ok || !json.imageUrl) {
    throw new Error(json.error || 'Failed to upload job circular image.');
  }
  return json.imageUrl;
}

export async function createCircularImageJob(
  supplierUser: PublicUser,
  circularImageUrl: string
): Promise<JobPost> {
  if (supplierUser.role !== 'supplier' || supplierUser.approvalStatus !== 'approved') {
    throw new Error('Only approved suppliers can publish job circulars.');
  }

  const cleanImageUrl = clampStr(circularImageUrl, 500);
  if (!cleanImageUrl || cleanImageUrl.length < 5) {
    throw new Error('Circular image URL is missing.');
  }

  const jobRef = doc(collection(db, 'jobs'));
  const now = serverTimestamp();

  const payload = {
    id: jobRef.id,
    supplierId: supplierUser.supplierDocId || supplierUser.id,
    ownerUid: supplierUser.id,
    supplierName: clampStr(supplierUser.companyName || supplierUser.name, 160),
    supplierCity: clampStr(supplierUser.city, 80),
    postType: 'circular_image' as const,
    circularImageUrl: cleanImageUrl,
    approvalStatus: 'approved' as const,
    status: 'active' as const,
    applicationsCount: 0,
    createdAt: now,
    updatedAt: now,
  };

  try {
    await setDoc(jobRef, payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `jobs/${jobRef.id}`);
  }

  return {
    ...payload,
    supplierApprovalStatus: 'approved',
    approvalStatus: 'approved',
    status: 'active',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isDemo: false,
  };
}

export async function createLiveJob(
  supplierUser: PublicUser,
  input: JobMutationInput
): Promise<JobPost> {
  if (supplierUser.role !== 'supplier' || supplierUser.approvalStatus !== 'approved') {
    throw new Error('Only approved suppliers can create job posts.');
  }
  const jobRef = doc(collection(db, 'jobs'));
  const now = serverTimestamp();

  const payload = {
    id: jobRef.id,
    supplierId: supplierUser.supplierDocId || supplierUser.id,
    ownerUid: supplierUser.id,
    supplierName: clampStr(supplierUser.companyName || supplierUser.name, 160),
    supplierCity: clampStr(supplierUser.city, 80),
    title: clampStr(input.title, 160),
    category: clampStr(input.category, 80),
    city: clampStr(input.city, 80),
    siteLocation: clampStr(input.siteLocation, 160),
    headcount: Math.max(1, Math.min(5000, Number(input.headcount))),
    salaryMin: Math.max(500, Math.min(100000, Number(input.salaryMin))),
    salaryMax: Math.max(Number(input.salaryMin), Math.min(100000, Number(input.salaryMax))),
    contractType: clampStr(input.contractType, 80),
    durationMonths: Math.max(1, Math.min(120, Number(input.durationMonths))),
    shiftHours: clampStr(input.shiftHours, 60),
    accommodationIncluded: Boolean(input.accommodationIncluded),
    transportIncluded: Boolean(input.transportIncluded),
    mealsIncluded: Boolean(input.mealsIncluded),
    iqamaTransferableRequired: Boolean(input.iqamaTransferableRequired),
    certifications: input.certifications.map((c) => clampStr(c, 80)).filter(Boolean).slice(0, 15),
    description: clampStr(input.description, 3000),
    approvalStatus: 'approved',
    status: 'active',
    applicationsCount: 0,
    createdAt: now,
    updatedAt: now,
  };

  try {
    await setDoc(jobRef, payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `jobs/${jobRef.id}`);
  }

  return {
    ...payload,
    supplierApprovalStatus: 'approved',
    approvalStatus: 'approved',
    status: 'active',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isDemo: false,
  };
}

export async function updateLiveJob(
  jobId: string,
  updates: Partial<JobMutationInput> & { status?: JobStatus }
): Promise<void> {
  const clean: Record<string, unknown> = {
    updatedAt: serverTimestamp(),
  };
  if (updates.title !== undefined) clean.title = clampStr(updates.title, 160);
  if (updates.category !== undefined) clean.category = clampStr(updates.category, 80);
  if (updates.city !== undefined) clean.city = clampStr(updates.city, 80);
  if (updates.siteLocation !== undefined) clean.siteLocation = clampStr(updates.siteLocation, 160);
  if (updates.headcount !== undefined) clean.headcount = Math.max(1, Math.min(5000, Number(updates.headcount)));
  if (updates.salaryMin !== undefined) clean.salaryMin = Math.max(500, Math.min(100000, Number(updates.salaryMin)));
  if (updates.salaryMax !== undefined) clean.salaryMax = Math.max(500, Math.min(100000, Number(updates.salaryMax)));
  if (updates.contractType !== undefined) clean.contractType = clampStr(updates.contractType, 80);
  if (updates.durationMonths !== undefined) clean.durationMonths = Math.max(1, Math.min(120, Number(updates.durationMonths)));
  if (updates.shiftHours !== undefined) clean.shiftHours = clampStr(updates.shiftHours, 60);
  if (updates.accommodationIncluded !== undefined) clean.accommodationIncluded = Boolean(updates.accommodationIncluded);
  if (updates.transportIncluded !== undefined) clean.transportIncluded = Boolean(updates.transportIncluded);
  if (updates.mealsIncluded !== undefined) clean.mealsIncluded = Boolean(updates.mealsIncluded);
  if (updates.iqamaTransferableRequired !== undefined) clean.iqamaTransferableRequired = Boolean(updates.iqamaTransferableRequired);
  if (updates.certifications !== undefined) {
    clean.certifications = updates.certifications.map((c) => clampStr(c, 80)).filter(Boolean).slice(0, 15);
  }
  if (updates.description !== undefined) clean.description = clampStr(updates.description, 3000);
  if (updates.status !== undefined) clean.status = updates.status;

  try {
    await updateDoc(doc(db, 'jobs', jobId), clean);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `jobs/${jobId}`);
  }
}

export async function deleteLiveJob(jobId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'jobs', jobId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `jobs/${jobId}`);
  }
}

export async function applyToLiveJob(
  job: JobPost,
  worker: PublicUser,
  note: string,
  phone: string,
  iqamaTransferable: boolean
): Promise<JobApplication> {
  const appRef = doc(collection(db, 'applications'));
  const now = serverTimestamp();
  const batch = writeBatch(db);

  const payload = {
    id: appRef.id,
    jobId: job.id,
    jobTitle: clampStr(job.title || `Job Circular · ${job.supplierName}`, 160),
    jobCity: clampStr(job.city || job.supplierCity || 'Saudi Arabia', 80),
    supplierId: job.supplierId,
    supplierOwnerUid: job.ownerUid || job.supplierId,
    supplierName: clampStr(job.supplierName, 160),
    workerId: worker.id,
    workerName: clampStr(worker.name, 120),
    workerPhone: clampStr(phone || worker.phone, 32),
    workerTrade: clampStr(worker.trade || 'Skilled Tradesperson', 100),
    workerCity: clampStr(worker.city, 80),
    iqamaTransferable: Boolean(iqamaTransferable),
    note: clampStr(note, 1500),
    status: 'submitted' as ApplicationStatus,
    createdAt: now,
    updatedAt: now,
  };

  batch.set(appRef, payload);
  batch.update(doc(db, 'jobs', job.id), {
    applicationsCount: increment(1),
    updatedAt: now,
  });

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `applications/${appRef.id}`);
  }

  return {
    ...payload,
    createdAt: new Date().toISOString(),
    isDemo: false,
  };
}

export async function listLiveApplications(user: PublicUser): Promise<JobApplication[]> {
  try {
    const field = user.role === 'worker' ? 'workerId' : 'supplierOwnerUid';
    const q = query(collection(db, 'applications'), where(field, '==', user.id));
    const snap = await getDocs(q);
    return snap.docs
      .map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          jobId: String(d.jobId || ''),
          jobTitle: String(d.jobTitle || ''),
          jobCity: String(d.jobCity || ''),
          supplierId: String(d.supplierId || ''),
          supplierOwnerUid: String(d.supplierOwnerUid || ''),
          supplierName: String(d.supplierName || ''),
          workerId: String(d.workerId || ''),
          workerName: String(d.workerName || ''),
          workerPhone: String(d.workerPhone || ''),
          workerTrade: String(d.workerTrade || ''),
          workerCity: String(d.workerCity || ''),
          iqamaTransferable: Boolean(d.iqamaTransferable),
          note: String(d.note || ''),
          status: (d.status as ApplicationStatus) || 'submitted',
          createdAt: timestampToIso(d.createdAt),
          isDemo: false,
        };
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'applications');
  }
}

export async function updateLiveApplicationStatus(
  appId: string,
  status: ApplicationStatus
): Promise<void> {
  try {
    await updateDoc(doc(db, 'applications', appId), {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `applications/${appId}`);
  }
}

export async function listApprovedLiveSuppliers(): Promise<PublicUser[]> {
  try {
    const q = query(collection(db, 'suppliers'), where('approvalStatus', '==', 'approved'));
    const snap = await getDocs(q);
    return snap.docs
      .map((docSnap) => mapSupplierDoc(docSnap.id, docSnap.data()))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'suppliers');
  }
}

export async function getLiveSupplierProfile(
  supplierId: string,
  viewer: PublicUser | null
): Promise<{ supplier: PublicUser; jobs: JobPost[] }> {
  let supSnap;
  try {
    supSnap = await getDoc(doc(db, 'suppliers', supplierId));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `suppliers/${supplierId}`);
  }
  if (!supSnap.exists()) {
    throw new Error('Supplier profile not found.');
  }

  const supplier = mapSupplierDoc(supSnap.id, supSnap.data());
  const isOwnerOrAdmin =
    viewer?.role === 'admin' || (viewer !== null && viewer.id === supSnap.data().ownerUid);

  // Only owner or admin can read private company documents (CR, Qiwa, GOSI)
  if (isOwnerOrAdmin) {
    try {
      const privDocs = await getDoc(doc(db, 'suppliers', supplierId, 'private', 'documents'));
      if (privDocs.exists()) {
        const d = privDocs.data();
        supplier.crNumber = String(d.crNumber || '');
        supplier.qiwaId = d.qiwaId ? String(d.qiwaId) : undefined;
        supplier.gosiReference = d.gosiReference ? String(d.gosiReference) : undefined;
        supplier.crDocumentLabel = d.crDocumentLabel ? String(d.crDocumentLabel) : undefined;
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `suppliers/${supplierId}/private/documents`);
    }
  }

  let jobs: JobPost[] = [];
  try {
    if (isOwnerOrAdmin) {
      const q = query(collection(db, 'jobs'), where('ownerUid', '==', String(supSnap.data().ownerUid)));
      const snap = await getDocs(q);
      jobs = snap.docs.map((j) => mapJobDoc(j.id, j.data()));
    } else {
      const q = query(
        collection(db, 'jobs'),
        where('approvalStatus', '==', 'approved'),
        where('status', '==', 'active'),
        where('supplierId', '==', supplierId)
      );
      const snap = await getDocs(q);
      jobs = snap.docs.map((j) => mapJobDoc(j.id, j.data()));
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'jobs');
  }

  jobs.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return { supplier, jobs };
}

export async function updateLiveSupplierProfileAndDocs(
  supplierId: string,
  updates: {
    companyName: string;
    contactName: string;
    city: string;
    businessPhone: string;
    whatsappNumber: string;
    officeAddress?: string;
    officeMapLink?: string;
    bio: string;
    specialties: string[];
    crNumber: string;
    qiwaId?: string;
    gosiReference?: string;
  }
): Promise<void> {
  const batch = writeBatch(db);
  const now = serverTimestamp();

  const cleanMapLink = clampStr(updates.officeMapLink, 600);
  if (cleanMapLink && !/^https?:\/\/.+/i.test(cleanMapLink)) {
    throw new Error('Office Google Maps Share Link must start with https:// or http://');
  }

  batch.update(doc(db, 'suppliers', supplierId), {
    companyName: clampStr(updates.companyName, 160),
    contactName: clampStr(updates.contactName, 120),
    city: clampStr(updates.city, 80),
    businessPhone: clampStr(updates.businessPhone, 32),
    whatsappNumber: clampStr(updates.whatsappNumber, 32),
    officeAddress: clampStr(updates.officeAddress, 300),
    officeMapLink: cleanMapLink,
    bio: clampStr(updates.bio, 1000),
    specialties: updates.specialties.slice(0, 10),
    updatedAt: now,
  });

  batch.update(doc(db, 'suppliers', supplierId, 'private', 'documents'), {
    crNumber: clampStr(updates.crNumber, 32),
    qiwaId: clampStr(updates.qiwaId, 64),
    gosiReference: clampStr(updates.gosiReference, 64),
    crDocumentLabel: `CR-${clampStr(updates.crNumber, 32)}`,
    updatedAt: now,
  });

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `suppliers/${supplierId}`);
  }
}

export async function fetchAdminFirestoreOverview(): Promise<{
  suppliers: PublicUser[];
  jobs: JobPost[];
}> {
  let supSnap;
  let jobSnap;
  try {
    supSnap = await getDocs(collection(db, 'suppliers'));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'suppliers');
  }
  try {
    jobSnap = await getDocs(collection(db, 'jobs'));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'jobs');
  }

  const suppliers = await Promise.all(
    supSnap.docs.map(async (sDoc) => {
      const mapped = mapSupplierDoc(sDoc.id, sDoc.data());
      try {
        const privSnap = await getDoc(doc(db, 'suppliers', sDoc.id, 'private', 'documents'));
        if (privSnap.exists()) {
          const pd = privSnap.data();
          mapped.crNumber = String(pd.crNumber || '');
          mapped.qiwaId = pd.qiwaId ? String(pd.qiwaId) : undefined;
          mapped.gosiReference = pd.gosiReference ? String(pd.gosiReference) : undefined;
        }
      } catch {
        // ignore if private doc absent
      }
      return mapped;
    })
  );

  const jobs = jobSnap.docs
    .map((jDoc) => mapJobDoc(jDoc.id, jDoc.data()))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  suppliers.sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  return { suppliers, jobs };
}

export async function adminUpdateSupplierApproval(
  supplierId: string,
  approvalStatus: SupplierApprovalStatus,
  adminNote: string
): Promise<void> {
  try {
    await updateDoc(doc(db, 'suppliers', supplierId), {
      approvalStatus,
      adminNote: clampStr(adminNote, 400),
      nitaqatBand: approvalStatus === 'approved' ? 'Verified Green' : 'Under Review',
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `suppliers/${supplierId}`);
  }
}

export async function adminUpdateJobApproval(
  jobId: string,
  approvalStatus: JobApprovalStatus,
  status: JobStatus,
  adminNote?: string
): Promise<void> {
  try {
    await updateDoc(doc(db, 'jobs', jobId), {
      approvalStatus,
      status,
      adminNote: clampStr(adminNote || '', 400),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `jobs/${jobId}`);
  }
}
