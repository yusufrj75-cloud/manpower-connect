export const SAUDI_CITIES = [
  'Riyadh',
  'Jeddah',
  'Dammam',
  'Al Khobar',
  'Jubail',
  'NEOM / Tabuk',
  'Makkah',
  'Madinah',
  'Yanbu',
] as const;

export const TRADE_CATEGORIES = [
  'Civil & Construction',
  'MEP & Electrical',
  'Welding & Fabrication',
  'Heavy Equipment',
  'Facility & Hospitality',
  'Logistics & Warehouse',
] as const;

export const CONTRACT_TYPES = [
  'Project Contract',
  'Monthly Transfer (Iqama)',
  'Ajeer / Temporary',
  'Direct Sponsorship',
] as const;

export const DEFAULT_FILTERS = {
  q: '',
  city: 'All',
  category: 'All',
  contractType: 'All',
  minSalary: 0,
  accommodationOnly: false,
  transportOnly: false,
  sortBy: 'newest' as const,
};
