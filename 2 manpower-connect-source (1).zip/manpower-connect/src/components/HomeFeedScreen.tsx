import { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Edit3,
  PauseCircle,
  PlayCircle,
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
} from 'lucide-react';
import { TRADE_CATEGORIES } from '../constants';
import { DEMO_JOBS } from '../demoData';
import { useI18n } from '../i18n';
import { deleteLiveJob, updateLiveJob } from '../services/firestoreMarketplace';
import type { JobApplication, JobPost, PublicUser, ScreenName } from '../types';
import { formatRelativeDate, formatSarRange } from '../utils';
import { JobCard } from './JobCard';

interface HomeFeedScreenProps {
  user: PublicUser | null;
  liveJobs: JobPost[];
  mySupplierJobs: JobPost[];
  applications: JobApplication[];
  loading: boolean;
  onSelectJob: (jobId: string) => void;
  onViewCircular?: (job: JobPost) => void;
  onEditJob: (job: JobPost) => void;
  onSelectSupplier: (supplierId: string) => void;
  onNavigate: (screen: ScreenName) => void;
  onOpenSearchWithCategory: (category: string) => void;
  onDataChanged: () => void;
}

export function HomeFeedScreen({
  user,
  liveJobs,
  mySupplierJobs,
  applications,
  loading,
  onSelectJob,
  onViewCircular,
  onEditJob,
  onSelectSupplier,
  onNavigate,
  onOpenSearchWithCategory,
  onDataChanged,
}: HomeFeedScreenProps) {
  const { t } = useI18n();
  const [dataSource, setDataSource] = useState<'verified' | 'demo'>('verified');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'feed' | 'my_jobs' | 'applications'>('feed');
  const [busyId, setBusyId] = useState<string | null>(null);

  const appliedJobIds = new Set(applications.map((a) => a.jobId));

  const sourceJobs = dataSource === 'verified' ? liveJobs : DEMO_JOBS;
  const filteredJobs =
    selectedCategory === 'All'
      ? sourceJobs
      : sourceJobs.filter((j) => j.category === selectedCategory);

  async function handleToggleJobStatus(job: JobPost) {
    setBusyId(job.id);
    try {
      await updateLiveJob(job.id, { status: job.status === 'active' ? 'paused' : 'active' });
      onDataChanged();
    } finally {
      setBusyId(null);
    }
  }

  async function handleDeleteJob(jobId: string) {
    setBusyId(jobId);
    try {
      await deleteLiveJob(jobId);
      onDataChanged();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-24 md:pb-12">
      {/* Top Feed Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#E2E8E4]">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0D1F16]">
            {t('feedTitle')}
          </h1>
          <p className="text-sm text-[#5E7166] mt-1">
            {dataSource === 'verified' ? t('sourceVerifiedDesc') : t('sourceDemoDesc')}
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('search')}
            className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] rounded-xl border border-[#C5D4CB] bg-white hover:border-[#0B4F32] text-sm font-medium text-[#0D1F16] transition-colors whitespace-nowrap"
          >
            <SlidersHorizontal className="w-4 h-4 text-[#0B4F32]" />
            <span>{t('navSearch')}</span>
          </button>

          {user?.role === 'supplier' ? (
            <button
              type="button"
              onClick={() => onNavigate('create-job')}
              className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-sm font-semibold transition-colors whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>{t('navPost')}</span>
            </button>
          ) : null}
        </div>
      </div>

      {/* Supplier Verification Notice (when pending or rejected) */}
      {user?.role === 'supplier' && user.approvalStatus !== 'approved' ? (
        <div className="mt-5 p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-amber-950">
                {user.approvalStatus === 'rejected'
                  ? t('rejectedApprovalBannerTitle')
                  : t('pendingApprovalBannerTitle')}
              </p>
              <p className="text-xs text-amber-900/80 mt-0.5">
                {user.adminNote || t('pendingApprovalBannerDesc')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onSelectSupplier(user.supplierDocId || user.id)}
            className="px-4 py-2 min-h-[40px] rounded-lg bg-white border border-amber-300 text-xs font-semibold text-amber-950 hover:bg-amber-100 whitespace-nowrap shrink-0"
          >
            {t('reviewCompanyBtn')}
          </button>
        </div>
      ) : null}

      {/* Primary Workspace Tabs + Explicit Verified vs Demo Data Separation */}
      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#EAEFEA] rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab('feed')}
            className={`px-4 py-2 min-h-[40px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'feed' ? 'bg-white text-[#0B4F32] shadow-sm' : 'text-[#475B50]'
            }`}
          >
            {t('sourceVerifiedTab')} ({liveJobs.length})
          </button>

          {user?.role === 'supplier' ? (
            <button
              type="button"
              onClick={() => setActiveTab('my_jobs')}
              className={`px-4 py-2 min-h-[40px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'my_jobs' ? 'bg-white text-[#0B4F32] shadow-sm' : 'text-[#475B50]'
              }`}
            >
              {t('myPostsTab')} ({mySupplierJobs.length})
            </button>
          ) : null}

          {user && (user.role === 'worker' || user.role === 'supplier') ? (
            <button
              type="button"
              onClick={() => setActiveTab('applications')}
              className={`px-4 py-2 min-h-[40px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'applications' ? 'bg-white text-[#0B4F32] shadow-sm' : 'text-[#475B50]'
              }`}
            >
              {user.role === 'worker'
                ? `${t('myAppsTab')} (${applications.length})`
                : `${t('receivedAppsTab')} (${applications.length})`}
            </button>
          ) : null}
        </div>

        {/* Dedicated Toggle between Real Verified Firestore Data and Demo Sample Data */}
        {activeTab === 'feed' ? (
          <div className="flex items-center gap-1 p-1 bg-white border border-[#E2E8E4] rounded-xl">
            <button
              type="button"
              onClick={() => setDataSource('verified')}
              className={`px-3.5 py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                dataSource === 'verified'
                  ? 'bg-[#0B4F32] text-white'
                  : 'text-[#475B50] hover:text-[#0D1F16]'
              }`}
            >
              {t('sourceVerifiedTab')} ({liveJobs.length})
            </button>
            <button
              type="button"
              onClick={() => setDataSource('demo')}
              className={`px-3.5 py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                dataSource === 'demo'
                  ? 'bg-[#0D1F16] text-white'
                  : 'text-[#475B50] hover:text-[#0D1F16]'
              }`}
            >
              {t('sourceDemoTab')} ({DEMO_JOBS.length})
            </button>
          </div>
        ) : null}
      </div>

      {/* Tab 1: My Supplier Jobs (Create / Edit / Pause / Delete) */}
      {activeTab === 'my_jobs' && user?.role === 'supplier' ? (
        <section className="mt-6">
          {mySupplierJobs.length === 0 ? (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 text-center">
              <p className="font-display text-base font-semibold text-[#0D1F16]">
                No job posts created yet
              </p>
              <button
                type="button"
                onClick={() => onNavigate('create-job')}
                className="mt-4 px-5 py-2.5 min-h-[44px] rounded-xl bg-[#0B4F32] text-white text-sm font-semibold"
              >
                {t('navPost')}
              </button>
            </div>
          ) : (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl divide-y divide-[#EEF2EF]">
              {mySupplierJobs.map((job) => {
                const isCircular = job.postType === 'circular_image' || Boolean(job.circularImageUrl);
                return (
                <div
                  key={job.id}
                  className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3.5 min-w-0">
                    {isCircular && job.circularImageUrl ? (
                      <button
                        type="button"
                        onClick={() => (onViewCircular ? onViewCircular(job) : onSelectJob(job.id))}
                        className="w-16 h-20 rounded-xl border border-[#E2E8E4] overflow-hidden bg-[#F6F8F7] shrink-0"
                        aria-label={t('tapFullSizeHint')}
                      >
                        <img
                          src={job.circularImageUrl}
                          alt={`${job.supplierName} circular`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ) : null}

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-[#5E7166]">
                        <span className="capitalize font-semibold text-[#0B4F32]">
                          {isCircular ? t('circularBadgeLabel') : `Status: ${job.status}`}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="capitalize">Listing: {job.status}</span>
                        <span aria-hidden="true">·</span>
                        <span>{job.city || job.supplierCity}</span>
                        {job.salaryMin && job.salaryMax ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono-tabular">
                              {formatSarRange(job.salaryMin, job.salaryMax)}
                            </span>
                          </>
                        ) : null}
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{formatRelativeDate(job.createdAt)}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          isCircular && onViewCircular ? onViewCircular(job) : onSelectJob(job.id)
                        }
                        className="mt-1 font-display text-base font-bold text-[#0D1F16] hover:text-[#0B4F32] text-left"
                      >
                        {job.title || `${job.supplierName} · ${t('circularBadgeLabel')}`}
                      </button>
                      {job.adminNote ? (
                        <p className="text-xs text-[#5E7166] mt-1">Admin note: {job.adminNote}</p>
                      ) : null}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {isCircular && onViewCircular ? (
                      <button
                        type="button"
                        onClick={() => onViewCircular(job)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-xl bg-[#F0F4F1] hover:bg-[#0B4F32] text-[#0B4F32] hover:text-white text-xs font-semibold transition-colors"
                      >
                        <span>{t('viewDemand')}</span>
                      </button>
                    ) : null}
                    {!isCircular ? (
                      <button
                        type="button"
                        disabled={busyId === job.id || user.approvalStatus !== 'approved'}
                        onClick={() => onEditJob(job)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-xl border border-[#C5D4CB] hover:border-[#0B4F32] text-xs font-semibold text-[#0D1F16]"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>{t('editJobBtn')}</span>
                      </button>
                    ) : null}
                    <button
                      type="button"
                      disabled={busyId === job.id}
                      onClick={() => handleToggleJobStatus(job)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-xl border border-[#C5D4CB] text-xs font-semibold text-[#0D1F16]"
                    >
                      {job.status === 'active' ? (
                        <>
                          <PauseCircle className="w-3.5 h-3.5 text-amber-700" />
                          <span>{t('pauseBtn')}</span>
                        </>
                      ) : (
                        <>
                          <PlayCircle className="w-3.5 h-3.5 text-[#0B4F32]" />
                          <span>{t('activateBtn')}</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      disabled={busyId === job.id}
                      onClick={() => handleDeleteJob(job.id)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-xl border border-red-200 hover:bg-red-50 text-xs font-semibold text-red-700"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{t('deleteBtn')}</span>
                    </button>
                  </div>
                </div>
                );
              })}
            </div>
          )}
        </section>
      ) : activeTab === 'applications' && user ? (
        <section className="mt-6">
          {applications.length === 0 ? (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 text-center">
              <p className="font-display text-base font-semibold text-[#0D1F16]">
                {user.role === 'worker' ? 'No applications submitted yet' : 'No applications received yet'}
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('feed')}
                className="mt-4 px-5 py-2.5 min-h-[44px] rounded-xl bg-[#0B4F32] text-white text-sm font-semibold"
              >
                {t('ctaBrowse')}
              </button>
            </div>
          ) : (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl divide-y divide-[#EEF2EF]">
              {applications.map((app) => (
                <div
                  key={app.id}
                  className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs text-[#5E7166]">
                      <span>{app.jobCity}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{formatRelativeDate(app.createdAt)}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-[#0B4F32] capitalize">{app.status}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => onSelectJob(app.jobId)}
                      className="mt-1 font-display text-base font-semibold text-[#0D1F16] hover:text-[#0B4F32] text-left"
                    >
                      {app.jobTitle}
                    </button>
                    <p className="text-xs text-[#475B50] mt-1">
                      {user.role === 'worker'
                        ? `${app.supplierName}`
                        : `${app.workerName} (${app.workerTrade}) · ${app.workerPhone}`}
                    </p>
                    <p className="text-sm text-[#475B50] mt-2">{app.note}</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectJob(app.jobId)}
                    className="px-4 py-2 min-h-[40px] rounded-lg bg-[#F0F4F1] text-xs font-semibold text-[#0B4F32] hover:bg-[#E2ECE6] whitespace-nowrap shrink-0 self-start sm:self-center"
                  >
                    {t('viewDemand')}
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>
      ) : (
        <>
          {/* Quick Trade Category Tabs */}
          <div className="mt-5 flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            <button
              type="button"
              onClick={() => setSelectedCategory('All')}
              className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === 'All'
                  ? 'bg-[#0B4F32] text-white'
                  : 'bg-white border border-[#E2E8E4] text-[#475B50] hover:border-[#0B4F32]'
              }`}
            >
              {t('allTrades')}
            </button>
            {TRADE_CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-[#0B4F32] text-white'
                    : 'bg-white border border-[#E2E8E4] text-[#475B50] hover:border-[#0B4F32]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {loading && dataSource === 'verified' ? (
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {[1, 2, 3].map((n) => (
                <div
                  key={n}
                  className="bg-white border border-[#E2E8E4] rounded-2xl p-5 h-60 animate-pulse"
                />
              ))}
            </div>
          ) : filteredJobs.length === 0 ? (
            <div className="mt-6 bg-white border border-[#E2E8E4] rounded-2xl p-10 text-center">
              <Search className="w-8 h-8 text-[#5E7166] mx-auto mb-3" />
              <h2 className="font-display text-lg font-semibold text-[#0D1F16]">
                {t('noVerifiedJobsTitle')}
              </h2>
              <p className="text-sm text-[#5E7166] mt-1 max-w-lg mx-auto">
                {t('noVerifiedJobsDesc')}
              </p>
              <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setDataSource('demo')}
                  className="px-4 py-2.5 min-h-[44px] rounded-xl bg-[#0B4F32] text-white text-sm font-semibold"
                >
                  {t('switchToDemoBtn')}
                </button>
                <button
                  type="button"
                  onClick={() => onOpenSearchWithCategory(selectedCategory)}
                  className="px-4 py-2.5 min-h-[44px] rounded-xl border border-[#C5D4CB] text-sm font-medium text-[#0D1F16]"
                >
                  {t('navSearch')}
                </button>
              </div>
            </div>
          ) : (
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredJobs.map((job) => (
                <JobCard
                  key={job.id}
                  job={job}
                  hasApplied={appliedJobIds.has(job.id)}
                  onSelectJob={onSelectJob}
                  onSelectSupplier={onSelectSupplier}
                  onViewCircular={onViewCircular}
                />
              ))}
            </div>
          )}

          {user?.role === 'worker' ? (
            <div className="mt-8 p-4 rounded-2xl bg-white border border-[#E2E8E4] flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#0B4F32] shrink-0" />
                <p className="text-sm text-[#475B50]">
                  <strong className="text-[#0D1F16]">{user.name}</strong> · {user.trade || 'Worker'} ·{' '}
                  {user.city}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('applications')}
                className="text-xs font-semibold text-[#0B4F32] hover:underline whitespace-nowrap shrink-0 min-h-[40px] flex items-center"
              >
                {t('myAppsTab')} ({applications.length})
              </button>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
