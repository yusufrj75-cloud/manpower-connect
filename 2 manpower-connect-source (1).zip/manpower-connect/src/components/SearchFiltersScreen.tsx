import { useMemo, useState } from 'react';
import { RotateCcw, Search } from 'lucide-react';
import { CONTRACT_TYPES, DEFAULT_FILTERS, SAUDI_CITIES, TRADE_CATEGORIES } from '../constants';
import { DEMO_JOBS } from '../demoData';
import { useI18n } from '../i18n';
import type { JobPost, SearchFilters } from '../types';
import { JobCard } from './JobCard';

interface SearchFiltersScreenProps {
  initialFilters?: Partial<SearchFilters>;
  liveJobs: JobPost[];
  loadingLive: boolean;
  appliedJobIds: Set<string>;
  onSelectJob: (jobId: string) => void;
  onSelectSupplier: (supplierId: string) => void;
  onViewCircular?: (job: JobPost) => void;
}

export function SearchFiltersScreen({
  initialFilters,
  liveJobs,
  loadingLive,
  appliedJobIds,
  onSelectJob,
  onSelectSupplier,
  onViewCircular,
}: SearchFiltersScreenProps) {
  const { t } = useI18n();
  const [dataSource, setDataSource] = useState<'verified' | 'demo'>('verified');
  const [filters, setFilters] = useState<SearchFilters>({
    ...DEFAULT_FILTERS,
    ...initialFilters,
  });

  const filteredJobs = useMemo(() => {
    const base = dataSource === 'verified' ? liveJobs : DEMO_JOBS;
    const term = filters.q.trim().toLowerCase();

    const matched = base.filter((j) => {
      if (j.approvalStatus !== 'approved' || j.status !== 'active') return false;
      const effectiveCity = j.city || j.supplierCity;
      if (term) {
        const haystack =
          `${j.title || ''} ${j.supplierName} ${j.supplierCity} ${j.category || ''} ${effectiveCity} ${j.siteLocation || ''} ${j.description || ''}`.toLowerCase();
        if (!haystack.includes(term)) return false;
      }
      if (filters.city !== 'All' && effectiveCity !== filters.city) return false;
      if (filters.category !== 'All' && j.category !== filters.category) return false;
      if (filters.contractType !== 'All' && j.contractType !== filters.contractType) return false;
      if (filters.minSalary > 0 && (j.salaryMax || 0) < filters.minSalary) return false;
      if (filters.accommodationOnly && !j.accommodationIncluded) return false;
      if (filters.transportOnly && !j.transportIncluded) return false;
      return true;
    });

    if (filters.sortBy === 'salary_desc') {
      matched.sort((a, b) => (b.salaryMax || 0) - (a.salaryMax || 0));
    } else if (filters.sortBy === 'headcount_desc') {
      matched.sort((a, b) => (b.headcount || 0) - (a.headcount || 0));
    } else {
      matched.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    }

    return matched;
  }, [dataSource, liveJobs, filters]);

  function resetFilters() {
    setFilters(DEFAULT_FILTERS);
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-24 md:pb-12">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#E2E8E4]">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0D1F16]">
            {t('searchTitle')}
          </h1>
          <p className="text-sm text-[#5E7166] mt-1">{t('searchSubtitle')}</p>
        </div>

        {/* Source Switcher: Verified Live Approved Posts vs Sample Demo Data */}
        <div className="flex items-center gap-1 p-1 bg-white border border-[#E2E8E4] rounded-xl shrink-0 w-fit">
          <button
            type="button"
            onClick={() => setDataSource('verified')}
            className={`px-3.5 py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              dataSource === 'verified' ? 'bg-[#0B4F32] text-white' : 'text-[#475B50]'
            }`}
          >
            {t('sourceVerifiedTab')} ({liveJobs.length})
          </button>
          <button
            type="button"
            onClick={() => setDataSource('demo')}
            className={`px-3.5 py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              dataSource === 'demo' ? 'bg-[#0D1F16] text-white' : 'text-[#475B50]'
            }`}
          >
            {t('sourceDemoTab')} ({DEMO_JOBS.length})
          </button>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <aside className="lg:col-span-4 bg-white border border-[#E2E8E4] rounded-2xl p-5 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-[#0D1F16]">{t('filterCriteria')}</h2>
            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0B4F32] hover:underline min-h-[36px]"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t('resetAll')}</span>
            </button>
          </div>

          <div>
            <label htmlFor="search-keyword" className="block text-xs font-semibold text-[#0D1F16] mb-1.5">
              {t('keywordLabel')}
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-[#5E7166] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="search-keyword"
                type="search"
                value={filters.q}
                onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))}
                placeholder={t('keywordPlaceholder')}
                className="w-full h-11 pl-10 pr-3.5 rounded-xl border border-[#C5D4CB] text-sm focus:outline-none focus:border-[#0B4F32]"
              />
            </div>
          </div>

          <div>
            <label htmlFor="search-city" className="block text-xs font-semibold text-[#0D1F16] mb-1.5">
              {t('cityLabel')}
            </label>
            <select
              id="search-city"
              value={filters.city}
              onChange={(e) => setFilters((f) => ({ ...f, city: e.target.value }))}
              className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] bg-white text-sm focus:outline-none focus:border-[#0B4F32]"
            >
              <option value="All">{t('allCities')}</option>
              {SAUDI_CITIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="search-category" className="block text-xs font-semibold text-[#0D1F16] mb-1.5">
              {t('tradeLabel')}
            </label>
            <select
              id="search-category"
              value={filters.category}
              onChange={(e) => setFilters((f) => ({ ...f, category: e.target.value }))}
              className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] bg-white text-sm focus:outline-none focus:border-[#0B4F32]"
            >
              <option value="All">{t('allTrades')}</option>
              {TRADE_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="search-contract" className="block text-xs font-semibold text-[#0D1F16] mb-1.5">
              {t('contractLabel')}
            </label>
            <select
              id="search-contract"
              value={filters.contractType}
              onChange={(e) => setFilters((f) => ({ ...f, contractType: e.target.value }))}
              className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] bg-white text-sm focus:outline-none focus:border-[#0B4F32]"
            >
              <option value="All">{t('anyContract')}</option>
              {CONTRACT_TYPES.map((ct) => (
                <option key={ct} value={ct}>
                  {ct}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <label htmlFor="search-salary" className="font-semibold text-[#0D1F16]">
                {t('minSalaryLabel')}
              </label>
              <span className="font-mono-tabular font-semibold text-[#0B4F32]">
                {filters.minSalary === 0 ? 'Any' : `SAR ${filters.minSalary.toLocaleString()}+`}
              </span>
            </div>
            <input
              id="search-salary"
              type="range"
              min={0}
              max={6000}
              step={500}
              value={filters.minSalary}
              onChange={(e) => setFilters((f) => ({ ...f, minSalary: Number(e.target.value) }))}
              className="w-full accent-[#0B4F32] h-2 bg-[#E2E8E4] rounded-lg cursor-pointer"
            />
          </div>

          <div className="pt-2 border-t border-[#EEF2EF] space-y-1">
            <label className="flex items-center gap-2.5 text-sm text-[#0D1F16] min-h-[44px] cursor-pointer">
              <input
                type="checkbox"
                checked={filters.accommodationOnly}
                onChange={(e) => setFilters((f) => ({ ...f, accommodationOnly: e.target.checked }))}
                className="w-4 h-4 accent-[#0B4F32]"
              />
              <span>{t('housingOnly')}</span>
            </label>
            <label className="flex items-center gap-2.5 text-sm text-[#0D1F16] min-h-[44px] cursor-pointer">
              <input
                type="checkbox"
                checked={filters.transportOnly}
                onChange={(e) => setFilters((f) => ({ ...f, transportOnly: e.target.checked }))}
                className="w-4 h-4 accent-[#0B4F32]"
              />
              <span>{t('transportOnly')}</span>
            </label>
          </div>
        </aside>

        <div className="lg:col-span-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <p className="text-sm text-[#475B50] tabular-nums">
              {filteredJobs.length} {dataSource === 'verified' ? t('sourceVerifiedTab') : t('sourceDemoTab')}
            </p>
            <div className="flex items-center gap-2">
              <label htmlFor="sort-order" className="text-xs text-[#5E7166] whitespace-nowrap">
                {t('sortBy')}
              </label>
              <select
                id="sort-order"
                value={filters.sortBy}
                onChange={(e) =>
                  setFilters((f) => ({
                    ...f,
                    sortBy: e.target.value as SearchFilters['sortBy'],
                  }))
                }
                className="h-10 px-3 rounded-lg border border-[#C5D4CB] bg-white text-xs font-medium text-[#0D1F16] focus:outline-none focus:border-[#0B4F32]"
              >
                <option value="newest">{t('sortNewest')}</option>
                <option value="salary_desc">{t('sortSalary')}</option>
                <option value="headcount_desc">{t('sortHeadcount')}</option>
              </select>
            </div>
          </div>

          {loadingLive && dataSource === 'verified' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((n) => (
                <div key={n} className="bg-white border border-[#E2E8E4] rounded-2xl p-5 h-56 animate-pulse" />
              ))}
            </div>
          ) : filteredJobs.length === 0 ? (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl p-10 text-center">
              <h3 className="font-display text-lg font-semibold text-[#0D1F16]">
                {t('noVerifiedJobsTitle')}
              </h3>
              <p className="text-sm text-[#5E7166] mt-1">{t('noVerifiedJobsDesc')}</p>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={resetFilters}
                  className="px-5 py-2.5 min-h-[44px] rounded-xl bg-[#0B4F32] text-white text-sm font-semibold"
                >
                  {t('resetAll')}
                </button>
                {dataSource === 'verified' ? (
                  <button
                    type="button"
                    onClick={() => setDataSource('demo')}
                    className="px-5 py-2.5 min-h-[44px] rounded-xl border border-[#C5D4CB] text-sm font-medium text-[#0D1F16]"
                  >
                    {t('switchToDemoBtn')}
                  </button>
                ) : null}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredJobs.map((job) => (
                <JobCard
                  key={job.id}
                  job={job}
                  hasApplied={appliedJobIds.has(job.id)}
                  onSelectJob={onSelectJob}
                  onSelectSupplier={onSelectSupplier}
                  onViewCircular={onViewCircular}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
