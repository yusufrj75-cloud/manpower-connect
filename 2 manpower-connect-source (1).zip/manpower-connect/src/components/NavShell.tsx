import {
  ArrowLeft,
  Briefcase,
  Building2,
  Home,
  Languages,
  LogIn,
  LogOut,
  PlusSquare,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { useI18n } from '../i18n';
import type { PublicUser, ScreenName } from '../types';

interface NavShellProps {
  currentScreen: ScreenName;
  user: PublicUser | null;
  onNavigate: (screen: ScreenName) => void;
  onOpenMyProfile: () => void;
  onBack?: () => void;
  onLogout: () => void;
}

export function NavShell({
  currentScreen,
  user,
  onNavigate,
  onOpenMyProfile,
  onBack,
  onLogout,
}: NavShellProps) {
  const { lang, setLang, t } = useI18n();

  const screenTitles: Record<ScreenName, string> = {
    welcome: t('screenWelcome'),
    login: t('screenLogin'),
    feed: t('screenFeed'),
    search: t('screenSearch'),
    'job-details': t('screenJobDetails'),
    'supplier-profile': t('screenSupplierProfile'),
    'create-job': t('screenCreateJob'),
    admin: t('screenAdmin'),
  };

  const showBackOnMobile =
    currentScreen === 'job-details' ||
    currentScreen === 'supplier-profile' ||
    currentScreen === 'create-job' ||
    currentScreen === 'login';

  function toggleLang() {
    setLang(lang === 'en' ? 'bn' : 'en');
  }

  return (
    <>
      {/* Desktop Top Bar — 3-Zone Contract */}
      <header className="hidden md:block sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E2E8E4]">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => onNavigate('welcome')}
            className="font-display text-lg font-bold tracking-tight text-[#0B4F32] hover:text-[#073823] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B4F32] rounded"
          >
            {t('brand')}
          </button>

          {/* Zone 2: 5 concise single-line nav links */}
          <nav aria-label="Primary Navigation" className="flex items-center gap-6 text-sm font-medium text-[#475B50]">
            <button
              type="button"
              onClick={() => onNavigate('feed')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                currentScreen === 'feed'
                  ? 'text-[#0B4F32] border-[#0B4F32] font-semibold'
                  : 'border-transparent hover:text-[#0D1F16] hover:border-[#C5D4CB]'
              }`}
            >
              {t('navFeed')}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('search')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                currentScreen === 'search'
                  ? 'text-[#0B4F32] border-[#0B4F32] font-semibold'
                  : 'border-transparent hover:text-[#0D1F16] hover:border-[#C5D4CB]'
              }`}
            >
              {t('navSearch')}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('create-job')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                currentScreen === 'create-job'
                  ? 'text-[#0B4F32] border-[#0B4F32] font-semibold'
                  : 'border-transparent hover:text-[#0D1F16] hover:border-[#C5D4CB]'
              }`}
            >
              {t('navPost')}
            </button>
            <button
              type="button"
              onClick={onOpenMyProfile}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                currentScreen === 'supplier-profile'
                  ? 'text-[#0B4F32] border-[#0B4F32] font-semibold'
                  : 'border-transparent hover:text-[#0D1F16] hover:border-[#C5D4CB]'
              }`}
            >
              {user?.role === 'supplier' ? t('navMyCompany') : t('navSuppliers')}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                currentScreen === 'admin'
                  ? 'text-[#0B4F32] border-[#0B4F32] font-semibold'
                  : 'border-transparent hover:text-[#0D1F16] hover:border-[#C5D4CB]'
              }`}
            >
              {t('navAdmin')}
            </button>
          </nav>

          {/* Zone 3: Language Switcher + Primary Account Action */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={toggleLang}
              aria-label="Switch Language English or Bengali"
              className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] rounded-lg border border-[#C5D4CB] hover:border-[#0B4F32] text-xs font-semibold text-[#0D1F16] transition-colors whitespace-nowrap shrink-0"
            >
              <Languages className="w-3.5 h-3.5 text-[#0B4F32]" />
              <span>{lang === 'en' ? 'বাংলা' : 'EN'}</span>
            </button>

            {user ? (
              <button
                type="button"
                onClick={onLogout}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#0B4F32] bg-[#F0F4F1] hover:bg-[#E2ECE6] rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
                title={`${user.name} (${user.role})`}
              >
                <span className="max-w-[130px] truncate">{user.name}</span>
                <span aria-hidden="true">·</span>
                <span>{t('navSignOut')}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onNavigate('login')}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#0B4F32] hover:bg-[#073823] rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
              >
                {t('navSignIn')}
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Compact Top App Bar (52px) */}
      <header className="md:hidden sticky top-0 z-40 h-[52px] bg-white/95 backdrop-blur-md border-b border-[#E2E8E4] px-2 flex items-center justify-between gap-2">
        <div className="min-w-[44px] flex items-center">
          {showBackOnMobile && onBack ? (
            <button
              type="button"
              onClick={onBack}
              aria-label="Go back"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#0D1F16] hover:bg-[#F0F4F1] rounded-lg"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onNavigate('welcome')}
              aria-label="MANPOWER CONNECT Home"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#0B4F32]"
            >
              <Briefcase className="w-5 h-5" />
            </button>
          )}
        </div>

        <span className="font-display text-sm font-bold text-[#0D1F16] truncate text-center flex-1">
          {screenTitles[currentScreen]}
        </span>

        <div className="flex items-center gap-0.5 shrink-0">
          <button
            type="button"
            onClick={toggleLang}
            aria-label="Switch Language"
            className="min-w-[44px] min-h-[44px] px-2 flex items-center justify-center text-xs font-bold text-[#0B4F32] hover:bg-[#F0F4F1] rounded-lg whitespace-nowrap"
          >
            {lang === 'en' ? 'বাংলা' : 'EN'}
          </button>

          {user ? (
            <button
              type="button"
              onClick={onLogout}
              aria-label={t('navSignOut')}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#475B50] hover:text-[#0B4F32] rounded-lg"
            >
              <LogOut className="w-5 h-5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onNavigate('login')}
              aria-label={t('navSignIn')}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#0B4F32] rounded-lg"
            >
              <LogIn className="w-5 h-5" />
            </button>
          )}
        </div>
      </header>

      {/* Mobile Fixed Bottom Thumb-Zone Tab Bar (60px) */}
      <nav
        aria-label="Mobile Bottom Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-[60px] bg-white/95 backdrop-blur-md border-t border-[#E2E8E4] grid grid-cols-5 items-center"
      >
        <button
          type="button"
          onClick={() => onNavigate('feed')}
          className={`min-h-[44px] h-full flex flex-col items-center justify-center gap-0.5 transition-colors ${
            currentScreen === 'feed' || currentScreen === 'welcome'
              ? 'text-[#0B4F32] font-semibold'
              : 'text-[#5E7166]'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] tracking-tight whitespace-nowrap">{t('mobileFeed')}</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('search')}
          className={`min-h-[44px] h-full flex flex-col items-center justify-center gap-0.5 transition-colors ${
            currentScreen === 'search' ? 'text-[#0B4F32] font-semibold' : 'text-[#5E7166]'
          }`}
        >
          <Search className="w-5 h-5" />
          <span className="text-[10px] tracking-tight whitespace-nowrap">{t('mobileSearch')}</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('create-job')}
          className={`min-h-[44px] h-full flex flex-col items-center justify-center gap-0.5 transition-colors ${
            currentScreen === 'create-job' ? 'text-[#0B4F32] font-semibold' : 'text-[#5E7166]'
          }`}
        >
          <PlusSquare className="w-5 h-5" />
          <span className="text-[10px] tracking-tight whitespace-nowrap">{t('mobilePost')}</span>
        </button>

        <button
          type="button"
          onClick={onOpenMyProfile}
          className={`min-h-[44px] h-full flex flex-col items-center justify-center gap-0.5 transition-colors ${
            currentScreen === 'supplier-profile' ? 'text-[#0B4F32] font-semibold' : 'text-[#5E7166]'
          }`}
        >
          <Building2 className="w-5 h-5" />
          <span className="text-[10px] tracking-tight whitespace-nowrap">{t('mobileSupplier')}</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('admin')}
          className={`min-h-[44px] h-full flex flex-col items-center justify-center gap-0.5 transition-colors ${
            currentScreen === 'admin' ? 'text-[#0B4F32] font-semibold' : 'text-[#5E7166]'
          }`}
        >
          <ShieldCheck className="w-5 h-5" />
          <span className="text-[10px] tracking-tight whitespace-nowrap">{t('mobileAdmin')}</span>
        </button>
      </nav>
    </>
  );
}
