import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Building2,
  Check,
  CheckCircle2,
  Clock,
  Edit3,
  MapPin,
  Maximize2,
  MessageCircle,
  PauseCircle,
  Phone,
  PlayCircle,
  ShieldCheck,
  Trash2,
} from 'lucide-react';
import { ASSETS } from '../assetsMap';
import { DEMO_JOBS, DEMO_SUPPLIERS } from '../demoData';
import { useI18n } from '../i18n';
import {
  applyToLiveJob,
  deleteLiveJob,
  getLiveJobDetails,
  updateLiveJob,
} from '../services/firestoreMarketplace';
import type { JobPost, PublicUser, ScreenName } from '../types';
import { buildTelHref, buildWhatsAppHref, formatRelativeDate, formatSarRange } from '../utils';
import { ResilientImage } from './ResilientImage';

interface JobDetailsScreenProps {
  jobId: string;
  user: PublicUser | null;
  onBack: () => void;
  onEditJob: (job: JobPost) => void;
  onViewCircular?: (job: JobPost) => void;
  onSelectSupplier: (supplierId: string) => void;
  onNavigate: (screen: ScreenName) => void;
  onApplicationSubmitted: () => void;
  onJobChanged: () => void;
}

export function JobDetailsScreen({
  jobId,
  user,
  onBack,
  onEditJob,
  onViewCircular,
  onSelectSupplier,
  onNavigate,
  onApplicationSubmitted,
  onJobChanged,
}: JobDetailsScreenProps) {
  const { t } = useI18n();
  const [job, setJob] = useState<JobPost | null>(null);
  const [supplier, setSupplier] = useState<PublicUser | null>(null);
  const [hasApplied, setHasApplied] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [note, setNote] = useState('');
  const [phone, setPhone] = useState(user?.phone || '+966 5');
  const [iqamaReady, setIqamaReady] = useState(user?.iqamaTransferable ?? true);
  const [submitting, setSubmitting] = useState(false);
  const [applyError, setApplyError] = useState<string | null>(null);
  const [applySuccess, setApplySuccess] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);

    const demoMatch = DEMO_JOBS.find((d) => d.id === jobId);
    if (demoMatch) {
      const demoSup = DEMO_SUPPLIERS.find((s) => s.id === demoMatch.supplierId) || null;
      setJob(demoMatch);
      setSupplier(demoSup);
      setHasApplied(false);
      setLoading(false);
      return;
    }

    getLiveJobDetails(jobId, user)
      .then((res) => {
        if (!active) return;
        setJob(res.job);
        setSupplier(res.supplier);
        setHasApplied(res.hasApplied);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Unable to load job details.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [jobId, user]);

  async function handleApply(e: React.FormEvent) {
    e.preventDefault();
    if (!job || !user || job.isDemo) return;
    setApplyError(null);
    setSubmitting(true);
    try {
      await applyToLiveJob(job, user, note, phone, iqamaReady);
      setHasApplied(true);
      setApplySuccess(true);
      setJob((prev) => (prev ? { ...prev, applicationsCount: prev.applicationsCount + 1 } : prev));
      onApplicationSubmitted();
    } catch (err) {
      setApplyError(err instanceof Error ? err.message : 'Application failed.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggleStatus() {
    if (!job || job.isDemo) return;
    const nextStatus = job.status === 'active' ? 'paused' : 'active';
    await updateLiveJob(job.id, { status: nextStatus });
    setJob({ ...job, status: nextStatus });
    onJobChanged();
  }

  async function handleDelete() {
    if (!job || job.isDemo) return;
    await deleteLiveJob(job.id);
    onJobChanged();
    onBack();
  }

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 h-96 animate-pulse" />
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 text-center">
          <p className="font-display text-lg font-semibold text-[#0D1F16]">
            {error || 'Job demand not found'}
          </p>
          <button
            type="button"
            onClick={onBack}
            className="mt-4 px-5 py-2.5 min-h-[44px] rounded-xl bg-[#0B4F32] text-white text-sm font-semibold"
          >
            {t('backToDemands')}
          </button>
        </div>
      </div>
    );
  }

  const isCircularImage = job.postType === 'circular_image' || Boolean(job.circularImageUrl);
  const displayTitle = job.title || `${job.supplierName} · ${t('circularBadgeLabel')}`;
  const displayCity = job.city || job.supplierCity;
  const isOwner = Boolean(user && !job.isDemo && (user.id === job.ownerUid || user.id === job.supplierId));
  const isOwnerOrAdmin = !job.isDemo && (user?.role === 'admin' || isOwner);
  const telHref = buildTelHref(supplier?.businessPhone || job.businessPhone);
  const waHref = buildWhatsAppHref(
    supplier?.whatsappNumber || supplier?.businessPhone || job.whatsappNumber,
    `Hello ${job.supplierName}, I am inquiring about "${displayTitle}" (${displayCity}) on MANPOWER CONNECT.`
  );

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-24 md:pb-12">
      <button
        type="button"
        onClick={onBack}
        className="hidden md:inline-flex items-center gap-2 text-sm font-medium text-[#475B50] hover:text-[#0B4F32] mb-5 min-h-[40px]"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>{t('backToDemands')}</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Main Spec Column */}
        <div className="lg:col-span-8 space-y-6">
          {isCircularImage && job.circularImageUrl ? (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl overflow-hidden">
              <div className="p-4 sm:p-5 border-b border-[#EEF2EF] flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold text-[#0B4F32]">
                    {job.isDemo ? t('demoBadge') : t('verifiedBadge')} ·{' '}
                    {formatRelativeDate(job.createdAt)}
                  </p>
                  <h1 className="font-display text-lg sm:text-xl font-bold text-[#0D1F16] mt-0.5">
                    {displayTitle}
                  </h1>
                </div>
                {onViewCircular ? (
                  <button
                    type="button"
                    onClick={() => onViewCircular(job)}
                    className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-[#F0F4F1] hover:bg-[#0B4F32] text-[#0B4F32] hover:text-white text-xs font-semibold transition-colors shrink-0"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>{t('tapFullSizeHint')}</span>
                  </button>
                ) : null}
              </div>

              <button
                type="button"
                onClick={() => (onViewCircular ? onViewCircular(job) : undefined)}
                className="w-full bg-[#F6F8F7] p-3 sm:p-5 flex items-center justify-center cursor-zoom-in"
              >
                <ResilientImage
                  src={job.circularImageUrl}
                  alt={`${job.supplierName} job circular`}
                  className="max-h-[680px] w-auto object-contain rounded-xl shadow-sm"
                  fallbackTitle={displayTitle}
                />
              </button>
            </div>
          ) : (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl overflow-hidden">
              <div className="h-44 sm:h-52 relative">
                <ResilientImage
                  src={ASSETS.industrialSite}
                  alt={`${displayTitle} site operations in ${displayCity}`}
                  className="w-full h-full object-cover"
                  fallbackTitle={`${job.category || t('circularBadgeLabel')} · ${displayCity}`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#073823]/75 via-[#073823]/20 to-transparent" />
                <div className="absolute bottom-4 left-5 right-5 text-white">
                  <p className="text-xs text-white/85">
                    {job.isDemo ? t('demoBadge') : t('verifiedBadge')} · {displayCity} ·{' '}
                    {formatRelativeDate(job.createdAt)}
                  </p>
                  <h1 className="font-display text-xl sm:text-2xl font-bold mt-1">{displayTitle}</h1>
                </div>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-6 border-b border-[#EEF2EF]">
                  <div>
                    <span className="text-xs text-[#5E7166]">{t('monthlyComp')}</span>
                    <p className="font-mono-tabular text-base font-bold text-[#0D1F16] mt-0.5">
                      {formatSarRange(job.salaryMin || 0, job.salaryMax || 0)}
                    </p>
                  </div>
                  <div>
                    <span className="text-xs text-[#5E7166]">{t('demandLabel')}</span>
                    <p className="font-mono-tabular text-base font-bold text-[#0B4F32] mt-0.5">
                      {job.headcount || 1} {t('workersUnit')}
                    </p>
                  </div>
                  <div>
                    <span className="text-xs text-[#5E7166]">{t('contractLabel')}</span>
                    <p className="text-sm font-semibold text-[#0D1F16] mt-0.5">
                      {job.contractType || 'Project Contract'}
                    </p>
                  </div>
                  <div>
                    <span className="text-xs text-[#5E7166]">Duration</span>
                    <p className="font-mono-tabular text-sm font-semibold text-[#0D1F16] mt-0.5">
                      {job.durationMonths || 12} Months
                    </p>
                  </div>
                </div>

                <div className="py-5 border-b border-[#EEF2EF] grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-[#0B4F32] shrink-0 mt-0.5" />
                    <div>
                      <span className="text-xs text-[#5E7166] block">Project Site</span>
                      <span className="font-medium text-[#0D1F16]">
                        {job.siteLocation || displayCity}, {displayCity}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Clock className="w-4 h-4 text-[#0B4F32] shrink-0 mt-0.5" />
                    <div>
                      <span className="text-xs text-[#5E7166] block">Shift Schedule</span>
                      <span className="font-medium text-[#0D1F16] font-mono-tabular">
                        {job.shiftHours || '8 hrs / 6 days'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="py-5 border-b border-[#EEF2EF]">
                  <h2 className="font-display text-base font-bold text-[#0D1F16] mb-2">
                    Scope of Work & Mobilization Details
                  </h2>
                  <p className="text-sm text-[#475B50] leading-relaxed whitespace-pre-line">
                    {job.description}
                  </p>
                </div>

                <div className="py-5 border-b border-[#EEF2EF]">
                  <h2 className="font-display text-base font-bold text-[#0D1F16] mb-3">
                    Mobilization Benefits & Visa Terms
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-sm">
                    <div className="flex items-center gap-2 text-[#0D1F16]">
                      <Check
                        className={`w-4 h-4 ${job.accommodationIncluded ? 'text-[#0B4F32]' : 'text-[#A3B5AA]'}`}
                      />
                      <span>
                        Accommodation: {job.accommodationIncluded ? 'Provided by Supplier' : 'Not Included'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[#0D1F16]">
                      <Check
                        className={`w-4 h-4 ${job.transportIncluded ? 'text-[#0B4F32]' : 'text-[#A3B5AA]'}`}
                      />
                      <span>
                        Site Transport: {job.transportIncluded ? 'Provided by Supplier' : 'Not Included'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[#0D1F16]">
                      <Check className={`w-4 h-4 ${job.mealsIncluded ? 'text-[#0B4F32]' : 'text-[#A3B5AA]'}`} />
                      <span>Catering / Meals: {job.mealsIncluded ? 'Included' : 'Allowance / Self'}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#0D1F16]">
                      <Check className="w-4 h-4 text-[#0B4F32]" />
                      <span>
                        Iqama Transfer:{' '}
                        {job.iqamaTransferableRequired ? 'Transferable Iqama Required' : 'Ajeer / Transfer Eligible'}
                      </span>
                    </div>
                  </div>
                </div>

                {job.certifications && job.certifications.length > 0 ? (
                  <div className="pt-5">
                    <h2 className="font-display text-base font-bold text-[#0D1F16] mb-2">
                      Required Certifications & Permits
                    </h2>
                    <ul className="space-y-1.5 text-sm text-[#475B50]">
                      {job.certifications.map((cert) => (
                        <li key={cert} className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-[#0B4F32] shrink-0" />
                          <span>{cert}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}
              </div>
            </div>
          )}
        </div>

        {/* Right Action & Supplier Column */}
        <div className="lg:col-span-4 space-y-5">
          <div className="bg-white border border-[#E2E8E4] rounded-2xl p-5">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#0B4F32] mb-2">
              <ShieldCheck className="w-4 h-4" />
              <span>{job.isDemo ? t('demoBadge') : t('approvedSupplier')}</span>
            </div>
            <h2 className="font-display text-lg font-bold text-[#0D1F16]">{job.supplierName}</h2>
            <p className="text-xs text-[#5E7166] mt-1">{job.supplierCity}, Saudi Arabia</p>

            {/* Working Call & WhatsApp Buttons */}
            {telHref || waHref ? (
              <div className="mt-4 grid grid-cols-2 gap-2">
                {telHref ? (
                  <a
                    href={telHref}
                    className="h-11 rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{t('callSupplier')}</span>
                  </a>
                ) : null}
                {waHref ? (
                  <a
                    href={waHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="h-11 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>{t('whatsappSupplier')}</span>
                  </a>
                ) : null}
              </div>
            ) : null}

            <button
              type="button"
              onClick={() => onSelectSupplier(job.supplierId)}
              className="mt-2.5 w-full h-11 rounded-xl border border-[#C5D4CB] hover:border-[#0B4F32] text-sm font-semibold text-[#0D1F16] flex items-center justify-center gap-2 transition-colors"
            >
              <Building2 className="w-4 h-4 text-[#0B4F32]" />
              <span>{t('screenSupplierProfile')}</span>
            </button>
          </div>

          <div className="bg-white border border-[#E2E8E4] rounded-2xl p-5">
            {job.isDemo ? (
              <div className="space-y-3">
                <h3 className="font-display text-base font-bold text-[#0D1F16]">{t('demoBadge')}</h3>
                <p className="text-xs text-[#5E7166] leading-relaxed">{t('demoApplyNote')}</p>
                <button
                  type="button"
                  onClick={() => onNavigate('feed')}
                  className="w-full h-11 rounded-xl bg-[#0B4F32] text-white text-xs font-semibold"
                >
                  {t('sourceVerifiedTab')}
                </button>
              </div>
            ) : isOwnerOrAdmin ? (
              <div className="space-y-3">
                <h3 className="font-display text-base font-bold text-[#0D1F16]">Manage Demand Post</h3>
                <p className="text-xs text-[#5E7166] tabular-nums">
                  Admin: <strong className="capitalize text-[#0D1F16]">{job.approvalStatus}</strong> ·{' '}
                  Status: <strong className="capitalize text-[#0D1F16]">{job.status}</strong> ·{' '}
                  {job.applicationsCount} apps
                </p>
                <div className="flex flex-col gap-2 pt-2">
                  {isOwner && user?.approvalStatus === 'approved' && !isCircularImage ? (
                    <button
                      type="button"
                      onClick={() => onEditJob(job)}
                      className="w-full h-11 rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-sm font-semibold flex items-center justify-center gap-2"
                    >
                      <Edit3 className="w-4 h-4" />
                      <span>{t('editJobBtn')}</span>
                    </button>
                  ) : null}
                  <button
                    type="button"
                    onClick={handleToggleStatus}
                    className="w-full h-11 rounded-xl border border-[#C5D4CB] hover:border-[#0B4F32] text-sm font-semibold text-[#0D1F16] flex items-center justify-center gap-2"
                  >
                    {job.status === 'active' ? (
                      <>
                        <PauseCircle className="w-4 h-4 text-amber-700" />
                        <span>{t('pauseJobBtn')}</span>
                      </>
                    ) : (
                      <>
                        <PlayCircle className="w-4 h-4 text-[#0B4F32]" />
                        <span>{t('activateJobBtn')}</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={handleDelete}
                    className="w-full h-11 rounded-xl border border-red-200 hover:bg-red-50 text-sm font-semibold text-red-700 flex items-center justify-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>{t('deleteJobBtn')}</span>
                  </button>
                </div>
              </div>
            ) : user?.role === 'worker' ? (
              hasApplied ? (
                <div className="text-center py-2">
                  <CheckCircle2 className="w-8 h-8 text-[#0B4F32] mx-auto mb-2" />
                  <h3 className="font-display text-base font-bold text-[#0D1F16]">
                    {applySuccess ? t('alreadyApplied') : t('alreadyApplied')}
                  </h3>
                  <p className="text-xs text-[#5E7166] mt-1">
                    {job.supplierName} has received your application.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleApply} className="space-y-3.5">
                  <h3 className="font-display text-base font-bold text-[#0D1F16]">{t('applyTitle')}</h3>
                  {applyError ? (
                    <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800">
                      {applyError}
                    </div>
                  ) : null}
                  <div>
                    <label htmlFor="apply-phone" className="block text-xs font-semibold text-[#0D1F16] mb-1">
                      {t('phoneLabel')}
                    </label>
                    <input
                      id="apply-phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular focus:outline-none focus:border-[#0B4F32]"
                    />
                  </div>
                  <div>
                    <label htmlFor="apply-note" className="block text-xs font-semibold text-[#0D1F16] mb-1">
                      Experience & Availability
                    </label>
                    <textarea
                      id="apply-note"
                      rows={3}
                      required
                      minLength={5}
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="Summarize your trade certificates, years in KSA, and earliest start date..."
                      className="w-full p-3 rounded-xl border border-[#C5D4CB] text-sm focus:outline-none focus:border-[#0B4F32]"
                    />
                  </div>
                  <label className="flex items-center gap-2 text-xs text-[#0D1F16] min-h-[40px] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={iqamaReady}
                      onChange={(e) => setIqamaReady(e.target.checked)}
                      className="w-4 h-4 accent-[#0B4F32]"
                    />
                    <span>{t('iqamaLabel')}</span>
                  </label>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full h-12 rounded-xl bg-[#0B4F32] hover:bg-[#073823] disabled:opacity-60 text-white text-sm font-semibold transition-colors"
                  >
                    {submitting ? '...' : t('submitAppBtn')}
                  </button>
                </form>
              )
            ) : (
              <div className="space-y-3">
                <h3 className="font-display text-base font-bold text-[#0D1F16]">{t('applyTitle')}</h3>
                <p className="text-xs text-[#5E7166] leading-relaxed">
                  {user
                    ? 'Sign in with a Worker account to submit applications.'
                    : 'Sign in with a Worker account to apply directly to this verified demand.'}
                </p>
                {!user ? (
                  <button
                    type="button"
                    onClick={() => onNavigate('login')}
                    className="w-full h-12 rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-sm font-semibold transition-colors"
                  >
                    {t('navSignIn')}
                  </button>
                ) : null}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
