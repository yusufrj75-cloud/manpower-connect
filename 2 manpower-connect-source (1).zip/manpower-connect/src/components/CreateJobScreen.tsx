import { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ImagePlus,
  Lock,
  RefreshCw,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';
import { useI18n } from '../i18n';
import {
  createCircularImageJob,
  uploadCircularImage,
} from '../services/firestoreMarketplace';
import type { JobPost, PublicUser, ScreenName } from '../types';

interface CreateJobScreenProps {
  user: PublicUser | null;
  editingJob: JobPost | null;
  onJobSaved: (jobId: string) => void;
  onCancelEdit: () => void;
  onNavigate: (screen: ScreenName) => void;
  onOpenSupplierProfile: (supplierId: string) => void;
}

function isAllowedCircularFile(file: File): boolean {
  const mime = file.type.toLowerCase();
  const name = file.name.toLowerCase();
  return (
    mime === 'image/jpeg' ||
    mime === 'image/jpg' ||
    mime === 'image/png' ||
    name.endsWith('.jpg') ||
    name.endsWith('.jpeg') ||
    name.endsWith('.png')
  );
}

export function CreateJobScreen({
  user,
  editingJob: _editingJob,
  onJobSaved,
  onNavigate,
  onOpenSupplierProfile,
}: CreateJobScreenProps) {
  const { t } = useI18n();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  if (!user || user.role !== 'supplier') {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-10 pb-24">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 text-center">
          <div className="w-12 h-12 rounded-2xl bg-[#F0F4F1] text-[#0B4F32] flex items-center justify-center mx-auto mb-4">
            <Lock className="w-6 h-6" />
          </div>
          <h1 className="font-display text-2xl font-bold text-[#0D1F16]">
            Supplier Account Required
          </h1>
          <p className="text-sm text-[#475B50] mt-2 leading-relaxed">
            {user
              ? `Signed in as ${user.role}. Only admin-approved Manpower Suppliers can publish job circular posts.`
              : 'Sign in or register as a Manpower Supplier to upload job circulars.'}
          </p>
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('login')}
              className="w-full sm:w-auto px-6 h-12 rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-sm font-semibold"
            >
              {t('navSignIn')}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('feed')}
              className="w-full sm:w-auto px-6 h-12 rounded-xl border border-[#C5D4CB] text-sm font-medium text-[#0D1F16]"
            >
              {t('ctaBrowse')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (user.approvalStatus !== 'approved') {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-10 pb-24">
        <div className="bg-white border border-amber-200 rounded-2xl p-8">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-800 flex items-center justify-center shrink-0">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-display text-xl sm:text-2xl font-bold text-[#0D1F16]">
                {user.approvalStatus === 'rejected'
                  ? t('rejectedApprovalBannerTitle')
                  : t('pendingApprovalBannerTitle')}
              </h1>
              <p className="text-sm text-[#475B50] mt-2 leading-relaxed">
                {t('pendingApprovalBannerDesc')}
              </p>
              {user.adminNote ? (
                <p className="mt-3 p-3 rounded-xl bg-[#F6F8F7] border border-[#E2E8E4] text-xs text-[#475B50]">
                  {user.adminNote}
                </p>
              ) : null}

              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={() => onOpenSupplierProfile(user.supplierDocId || user.id)}
                  className="px-5 h-11 rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-sm font-semibold"
                >
                  {t('reviewCompanyBtn')}
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('admin')}
                  className="px-5 h-11 rounded-xl border border-[#C5D4CB] text-sm font-medium text-[#0D1F16]"
                >
                  {t('navAdmin')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  function handleFilePicked(file: File | null | undefined) {
    setError(null);
    if (!file) return;

    if (!isAllowedCircularFile(file)) {
      setError('Unsupported file format. Please select a JPG, JPEG, or PNG image.');
      return;
    }

    if (file.size > 12 * 1024 * 1024) {
      setError('Image is too large (max 12 MB). Please choose a smaller JPG or PNG file.');
      return;
    }

    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }

    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  }

  function handleClearFile() {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setError(null);

    if (!selectedFile) {
      setError(t('circularRequiredError'));
      return;
    }

    setSubmitting(true);
    try {
      const imageUrl = await uploadCircularImage(selectedFile);
      const created = await createCircularImageJob(user, imageUrl);
      handleClearFile();
      onJobSaved(created.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to publish job circular.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-24 md:pb-12">
      <div className="pb-5 border-b border-[#E2E8E4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0D1F16]">
            {t('createJobTitle')}
          </h1>
          <p className="text-sm text-[#5E7166] mt-1">
            <strong className="text-[#0D1F16]">{user.companyName || user.name}</strong>
          </p>
        </div>
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0B4F32]">
          <ShieldCheck className="w-4 h-4" />
          <span>{t('approvedSupplier')}</span>
        </div>
      </div>

      <div className="mt-4 p-4 rounded-xl bg-[#F0F4F1] border border-[#C5D4CB] text-xs sm:text-sm text-[#0B4F32] leading-relaxed">
        {t('approvalReviewHint')}
      </div>

      {error ? (
        <div
          role="alert"
          className="mt-5 p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800"
        >
          {error}
        </div>
      ) : null}

      <form
        onSubmit={handleSubmit}
        className="mt-6 bg-white border border-[#E2E8E4] rounded-2xl p-5 sm:p-7 space-y-5"
      >
        <div>
          <label
            htmlFor="circular-file-input"
            className="block text-sm font-semibold text-[#0D1F16] mb-2"
          >
            {t('circularUploadLabel')}
          </label>

          <input
            ref={fileInputRef}
            id="circular-file-input"
            type="file"
            accept="image/jpeg,image/jpg,image/png,.jpg,.jpeg,.png"
            onChange={(e) => handleFilePicked(e.target.files?.[0])}
            className="sr-only"
          />

          {!previewUrl ? (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full min-h-[240px] sm:min-h-[280px] rounded-2xl border-2 border-dashed border-[#0B4F32]/40 bg-[#F6F8F7] hover:bg-[#F0F4F1] hover:border-[#0B4F32] transition-colors p-6 flex flex-col items-center justify-center text-center gap-3 cursor-pointer"
            >
              <div className="w-14 h-14 rounded-2xl bg-[#0B4F32] text-white flex items-center justify-center">
                <ImagePlus className="w-7 h-7" />
              </div>
              <div>
                <p className="font-display text-base sm:text-lg font-bold text-[#0D1F16]">
                  {t('circularUploadTap')}
                </p>
                <p className="text-xs sm:text-sm text-[#5E7166] mt-1">
                  {t('circularUploadHint')}
                </p>
              </div>
              <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white border border-[#C5D4CB] text-xs font-semibold text-[#0B4F32]">
                <Upload className="w-3.5 h-3.5" />
                <span>JPG · JPEG · PNG</span>
              </span>
            </button>
          ) : (
            <div className="space-y-3">
              <div className="rounded-2xl border border-[#E2E8E4] bg-[#F6F8F7] p-3 flex items-center justify-center">
                <img
                  src={previewUrl}
                  alt="Selected job circular preview"
                  className="max-h-[420px] w-auto object-contain rounded-xl"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#5E7166]">
                <span className="truncate font-mono-tabular">
                  {selectedFile?.name}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={submitting}
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl border border-[#C5D4CB] hover:border-[#0B4F32] text-xs font-semibold text-[#0D1F16]"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{t('circularChangeBtn')}</span>
                  </button>
                  <button
                    type="button"
                    disabled={submitting}
                    onClick={handleClearFile}
                    className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl border border-red-200 hover:bg-red-50 text-xs font-semibold text-red-700"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{t('circularRemoveBtn')}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <button
            type="submit"
            disabled={submitting || !selectedFile}
            className="flex-1 h-12 px-7 rounded-xl bg-[#0B4F32] hover:bg-[#073823] disabled:opacity-50 text-white text-sm font-semibold inline-flex items-center justify-center gap-2 transition-colors"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{submitting ? 'Publishing...' : t('publishJobBtn')}</span>
          </button>
          <button
            type="button"
            disabled={submitting}
            onClick={() => onNavigate('feed')}
            className="h-12 px-5 rounded-xl border border-[#C5D4CB] text-sm font-medium text-[#475B50] hover:text-[#0D1F16]"
          >
            {t('cancelEdit')}
          </button>
        </div>
      </form>
    </div>
  );
}
