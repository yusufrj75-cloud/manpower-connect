import { ArrowUpRight, Maximize2, ShieldCheck } from 'lucide-react';
import { useI18n } from '../i18n';
import type { JobPost } from '../types';
import { formatRelativeDate, formatSarRange } from '../utils';
import { ResilientImage } from './ResilientImage';

interface JobCardProps {
  job: JobPost;
  onSelectJob: (jobId: string) => void;
  onSelectSupplier: (supplierId: string) => void;
  onViewCircular?: (job: JobPost) => void;
  hasApplied?: boolean;
}

export function JobCard({
  job,
  onSelectJob,
  onSelectSupplier,
  onViewCircular,
  hasApplied,
}: JobCardProps) {
  const { t } = useI18n();
  const isCircularImage = job.postType === 'circular_image' || Boolean(job.circularImageUrl);

  if (isCircularImage && job.circularImageUrl) {
    return (
      <article className="group bg-white border border-[#E2E8E4] hover:border-[#0B4F32]/40 rounded-2xl overflow-hidden flex flex-col justify-between transition-colors duration-150">
        <div className="p-4 pb-3">
          <div className="flex items-center justify-between gap-2 text-xs mb-2">
            <span className="font-semibold truncate text-[#0B4F32]">
              {job.isDemo ? t('demoBadge') : t('verifiedBadge')}
            </span>
            <span className="shrink-0 text-[#5E7166] tabular-nums">
              {formatRelativeDate(job.createdAt)}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-sm text-[#0D1F16]">
            <ShieldCheck className="w-4 h-4 shrink-0 text-[#0B4F32]" aria-hidden="true" />
            <button
              type="button"
              onClick={() => onSelectSupplier(job.supplierId)}
              className="truncate hover:text-[#0B4F32] hover:underline font-semibold text-left"
            >
              {job.supplierName}
            </button>
          </div>
          <p className="text-xs text-[#5E7166] mt-0.5 truncate">{job.supplierCity}, KSA</p>
        </div>

        {/* Tappable Finished Job Circular Image */}
        <button
          type="button"
          onClick={() => (onViewCircular ? onViewCircular(job) : onSelectJob(job.id))}
          className="relative w-full bg-[#F6F8F7] border-y border-[#EEF2EF] overflow-hidden text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B4F32]"
        >
          <div className="aspect-[4/5] w-full overflow-hidden">
            <ResilientImage
              src={job.circularImageUrl}
              alt={`${job.supplierName} job circular`}
              className="w-full h-full object-cover object-top group-hover:scale-[1.01] transition-transform duration-200"
              fallbackTitle={`${job.supplierName} ${t('circularBadgeLabel')}`}
            />
          </div>
          <span className="absolute bottom-2.5 right-2.5 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/75 text-white text-xs font-semibold">
            <Maximize2 className="w-3.5 h-3.5" />
            <span>{t('tapFullSizeHint')}</span>
          </span>
        </button>

        <div className="p-4 pt-3 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => onSelectSupplier(job.supplierId)}
            className="text-xs font-semibold text-[#0B4F32] hover:underline min-h-[40px] inline-flex items-center"
          >
            {t('screenSupplierProfile')}
          </button>

          <button
            type="button"
            onClick={() => (onViewCircular ? onViewCircular(job) : onSelectJob(job.id))}
            className="inline-flex items-center gap-1 px-3 py-2 min-h-[40px] text-xs font-semibold text-[#0B4F32] bg-[#F0F4F1] hover:bg-[#0B4F32] hover:text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <span>{hasApplied ? t('appliedView') : t('viewDemand')}</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </article>
    );
  }

  const perks: string[] = [];
  if (job.accommodationIncluded) perks.push('Housing');
  if (job.transportIncluded) perks.push('Transport');
  if (job.mealsIncluded) perks.push('Meals');

  return (
    <article className="group bg-white border border-[#E2E8E4] hover:border-[#0B4F32]/40 rounded-2xl p-5 flex flex-col justify-between gap-4 transition-colors duration-150">
      <div>
        {/* Clear separation between Real Verified Firestore jobs vs Sample Demo data */}
        <div className="flex items-center justify-between gap-2 text-xs mb-2">
          <span
            className={`font-semibold truncate ${
              job.isDemo ? 'text-[#5E7166]' : 'text-[#0B4F32]'
            }`}
          >
            {job.isDemo ? t('demoBadge') : t('verifiedBadge')}
          </span>
          <span className="shrink-0 text-[#5E7166] tabular-nums">
            {formatRelativeDate(job.createdAt)}
          </span>
        </div>

        {/* Unboxed quiet metadata line */}
        <div className="text-xs text-[#5E7166] truncate mb-1.5">
          {job.city || job.supplierCity} <span aria-hidden="true">·</span> {job.category || t('circularBadgeLabel')}
        </div>

        {/* Job Title */}
        <button
          type="button"
          onClick={() => onSelectJob(job.id)}
          className="text-left w-full group/title focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B4F32] rounded"
        >
          <h3 className="font-display text-lg font-semibold text-[#0D1F16] group-hover/title:text-[#0B4F32] transition-colors leading-snug">
            {job.title || `${job.supplierName} · ${t('circularBadgeLabel')}`}
          </h3>
        </button>

        {/* Supplier link */}
        <div className="mt-1.5 flex items-center gap-1.5 text-sm text-[#475B50]">
          <ShieldCheck
            className={`w-4 h-4 shrink-0 ${job.isDemo ? 'text-[#5E7166]' : 'text-[#0B4F32]'}`}
            aria-hidden="true"
          />
          <button
            type="button"
            onClick={() => onSelectSupplier(job.supplierId)}
            className="truncate hover:text-[#0B4F32] hover:underline font-medium text-left"
          >
            {job.supplierName}
          </button>
        </div>

        {job.description ? (
          <p className="mt-3 text-sm text-[#475B50] line-clamp-2 leading-relaxed">
            {job.description}
          </p>
        ) : null}
      </div>

      <div className="pt-4 border-t border-[#EEF2EF] flex flex-col gap-3">
        <div className="flex items-baseline justify-between gap-3">
          <div>
            <span className="block text-xs text-[#5E7166]">{t('monthlyComp')}</span>
            <span className="font-mono-tabular text-sm font-semibold text-[#0D1F16]">
              {formatSarRange(job.salaryMin || 0, job.salaryMax || 0)}
            </span>
          </div>
          <div className="text-right">
            <span className="block text-xs text-[#5E7166]">{t('demandLabel')}</span>
            <span className="font-mono-tabular text-sm font-semibold text-[#0B4F32]">
              {job.headcount || 1}{' '}
              {(job.headcount || 1) === 1 ? t('workerUnit') : t('workersUnit')}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between gap-2 pt-1">
          <span className="text-xs text-[#5E7166] truncate">
            {job.contractType || 'Project Contract'}
            {perks.length > 0 ? ` · ${perks.join(', ')}` : ''}
          </span>

          <button
            type="button"
            onClick={() => onSelectJob(job.id)}
            className="inline-flex items-center gap-1 px-3 py-2 min-h-[40px] text-xs font-semibold text-[#0B4F32] bg-[#F0F4F1] hover:bg-[#0B4F32] hover:text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <span>{hasApplied ? t('appliedView') : t('viewDemand')}</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </article>
  );
}
