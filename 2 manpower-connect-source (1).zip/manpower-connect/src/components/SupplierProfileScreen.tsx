import { useEffect, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  Building2,
  Edit3,
  ExternalLink,
  Lock,
  MapPin,
  MessageCircle,
  Phone,
  Plus,
  ShieldCheck,
  Trash2,
  XCircle,
} from 'lucide-react';
import { ASSETS } from '../assetsMap';
import { SAUDI_CITIES, TRADE_CATEGORIES } from '../constants';
import { DEMO_JOBS, DEMO_SUPPLIERS } from '../demoData';
import { useI18n } from '../i18n';
import {
  deleteLiveJob,
  getLiveSupplierProfile,
  listApprovedLiveSuppliers,
  updateLiveApplicationStatus,
  updateLiveSupplierProfileAndDocs,
} from '../services/firestoreMarketplace';
import type { ApplicationStatus, JobApplication, JobPost, PublicUser, ScreenName } from '../types';
import { buildTelHref, buildWhatsAppHref, formatRelativeDate, sanitizeHttpUrl } from '../utils';
import { JobCard } from './JobCard';
import { ResilientImage } from './ResilientImage';

interface SupplierProfileScreenProps {
  supplierId: string | null;
  user: PublicUser | null;
  applications: JobApplication[];
  onSelectSupplier: (id: string) => void;
  onSelectJob: (jobId: string) => void;
  onViewCircular?: (job: JobPost) => void;
  onEditJob: (job: JobPost) => void;
  onNavigate: (screen: ScreenName) => void;
  onProfileUpdated: () => void;
  onApplicationUpdated: () => void;
  onBack: () => void;
}

export function SupplierProfileScreen({
  supplierId,
  user,
  applications,
  onSelectSupplier,
  onSelectJob,
  onViewCircular,
  onEditJob,
  onNavigate,
  onProfileUpdated,
  onApplicationUpdated,
  onBack,
}: SupplierProfileScreenProps) {
  const { t } = useI18n();
  const [directory, setDirectory] = useState<PublicUser[]>([]);
  const [supplier, setSupplier] = useState<PublicUser | null>(null);
  const [jobs, setJobs] = useState<JobPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Edit state for owning supplier
  const [editing, setEditing] = useState(false);
  const [companyName, setCompanyName] = useState('');
  const [contactName, setContactName] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [city, setCity] = useState('Riyadh');
  const [officeAddress, setOfficeAddress] = useState('');
  const [officeMapLink, setOfficeMapLink] = useState('');
  const [bio, setBio] = useState('');
  const [specialties, setSpecialties] = useState<string[]>([]);
  // Protected private docs
  const [crNumber, setCrNumber] = useState('');
  const [qiwaId, setQiwaId] = useState('');
  const [gosiReference, setGosiReference] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const effectiveSupplierId =
    supplierId || (user?.role === 'supplier' ? user.supplierDocId || user.id : null);

  async function loadAll() {
    setLoading(true);
    setError(null);
    try {
      const liveDirectory = await listApprovedLiveSuppliers();
      setDirectory(liveDirectory.length > 0 ? liveDirectory : DEMO_SUPPLIERS);

      const targetId = effectiveSupplierId || liveDirectory[0]?.id || DEMO_SUPPLIERS[0].id;

      // Demo supplier check
      const demoSup = DEMO_SUPPLIERS.find((s) => s.id === targetId);
      if (demoSup) {
        setSupplier(demoSup);
        setJobs(DEMO_JOBS.filter((j) => j.supplierId === demoSup.id));
        setLoading(false);
        return;
      }

      const res = await getLiveSupplierProfile(targetId, user);
      setSupplier(res.supplier);
      setJobs(res.jobs);
      setCompanyName(res.supplier.companyName || res.supplier.name);
      setContactName(res.supplier.name || '');
      setBusinessPhone(res.supplier.businessPhone || res.supplier.phone || '');
      setWhatsappNumber(res.supplier.whatsappNumber || res.supplier.businessPhone || '');
      setCity(res.supplier.city || 'Riyadh');
      setOfficeAddress(res.supplier.officeAddress || '');
      setOfficeMapLink(res.supplier.officeMapLink || '');
      setBio(res.supplier.bio || '');
      setSpecialties(res.supplier.specialties || []);
      setCrNumber(res.supplier.crNumber || '');
      setQiwaId(res.supplier.qiwaId || '');
      setGosiReference(res.supplier.gosiReference || '');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load supplier profile.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
  }, [effectiveSupplierId, user?.id]);

  const isOwner = Boolean(
    user && supplier && !supplier.isDemo && (user.id === supplier.id || user.supplierDocId === supplier.id)
  );
  const canViewProtectedDocs = Boolean(!supplier?.isDemo && (isOwner || user?.role === 'admin'));

  async function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!supplier || supplier.isDemo) return;
    setSaveError(null);
    setSaving(true);
    try {
      await updateLiveSupplierProfileAndDocs(supplier.id, {
        companyName,
        contactName,
        city,
        businessPhone,
        whatsappNumber,
        officeAddress,
        officeMapLink,
        bio,
        specialties,
        crNumber,
        qiwaId,
        gosiReference,
      });
      setEditing(false);
      await loadAll();
      onProfileUpdated();
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  }

  function toggleSpecialty(cat: string) {
    setSpecialties((prev) =>
      prev.includes(cat) ? prev.filter((item) => item !== cat) : [...prev, cat]
    );
  }

  async function handleAppStatus(appId: string, status: ApplicationStatus) {
    await updateLiveApplicationStatus(appId, status);
    onApplicationUpdated();
  }

  async function handleDeleteOwnJob(jobId: string) {
    await deleteLiveJob(jobId);
    await loadAll();
    onProfileUpdated();
  }

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 h-80 animate-pulse" />
      </div>
    );
  }

  if (error || !supplier) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 text-center">
          <p className="font-display text-lg font-semibold text-[#0D1F16]">
            {error || 'No supplier selected'}
          </p>
          <button
            type="button"
            onClick={onBack}
            className="mt-4 px-5 py-2.5 min-h-[44px] rounded-xl bg-[#0B4F32] text-white text-sm font-semibold"
          >
            {t('backToDemands')}
          </button>
        </div>
      </div>
    );
  }

  const approvalBadge =
    supplier.approvalStatus === 'approved'
      ? {
          icon: ShieldCheck,
          label: supplier.isDemo ? t('demoBadge') : t('approvedSupplier'),
          classes: 'text-[#0B4F32] bg-[#F0F4F1] border-[#C5D4CB]',
        }
      : supplier.approvalStatus === 'rejected'
      ? {
          icon: XCircle,
          label: t('rejectedSupplier'),
          classes: 'text-red-800 bg-red-50 border-red-200',
        }
      : {
          icon: AlertCircle,
          label: t('pendingSupplier'),
          classes: 'text-amber-900 bg-amber-50 border-amber-200',
        };

  const StatusIcon = approvalBadge.icon;
  const telHref = buildTelHref(supplier.businessPhone || supplier.phone);
  const waHref = buildWhatsAppHref(
    supplier.whatsappNumber || supplier.businessPhone || supplier.phone,
    `Hello ${supplier.companyName || supplier.name}, I found your supplier profile on MANPOWER CONNECT.`
  );
  const safeOfficeMapLink = sanitizeHttpUrl(supplier.officeMapLink);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-24 md:pb-12">
      {/* Directory Switcher */}
      {directory.length > 0 ? (
        <div className="mb-5 flex items-center justify-between gap-4 overflow-x-auto pb-1">
          <button
            type="button"
            onClick={onBack}
            className="hidden md:inline-flex items-center gap-1.5 text-sm font-medium text-[#475B50] hover:text-[#0B4F32] whitespace-nowrap shrink-0"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          <div className="flex items-center gap-2 overflow-x-auto">
            {directory.map((sup) => (
              <button
                key={sup.id}
                type="button"
                onClick={() => onSelectSupplier(sup.id)}
                className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  sup.id === supplier.id
                    ? 'bg-[#0B4F32] text-white'
                    : 'bg-white border border-[#E2E8E4] text-[#475B50] hover:border-[#0B4F32]'
                }`}
              >
                {sup.companyName || sup.name}
              </button>
            ))}
          </div>
        </div>
      ) : null}

      {/* Main Company Profile Card */}
      <section className="bg-white border border-[#E2E8E4] rounded-2xl overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-12 items-stretch">
          <div className="md:col-span-4 h-48 md:h-auto min-h-[220px] relative">
            <ResilientImage
              src={ASSETS.corporateHq}
              alt={`${supplier.companyName || supplier.name} headquarters`}
              className="w-full h-full object-cover"
              fallbackTitle={supplier.companyName || supplier.name}
            />
          </div>

          <div className="md:col-span-8 p-6 sm:p-7 flex flex-col justify-between gap-5">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg border text-xs font-semibold ${approvalBadge.classes}`}
                >
                  <StatusIcon className="w-3.5 h-3.5" />
                  <span>{approvalBadge.label}</span>
                </div>

                {isOwner ? (
                  <button
                    type="button"
                    onClick={() => setEditing((v) => !v)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-lg border border-[#C5D4CB] text-xs font-semibold text-[#0D1F16] hover:border-[#0B4F32]"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{editing ? t('cancelEdit') : t('editProfile')}</span>
                  </button>
                ) : null}
              </div>

              <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0D1F16] mt-3">
                {supplier.companyName || supplier.name}
              </h1>

              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[#5E7166]">
                <span className="inline-flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#0B4F32]" />
                  {supplier.city}, KSA
                </span>
                <span>Nitaqat: {supplier.nitaqatBand || 'Standard'}</span>
                <span className="inline-flex items-center gap-1 font-mono-tabular">
                  <Phone className="w-3.5 h-3.5 text-[#0B4F32]" />
                  {supplier.businessPhone || supplier.phone}
                </span>
              </div>

              <p className="mt-4 text-sm text-[#475B50] leading-relaxed">
                {supplier.bio || 'Verified Saudi Arabia workforce and contracting supplier.'}
              </p>

              {supplier.specialties && supplier.specialties.length > 0 ? (
                <p className="mt-3 text-xs text-[#5E7166]">
                  <strong className="text-[#0D1F16]">Core Trades:</strong>{' '}
                  {supplier.specialties.join(' · ')}
                </p>
              ) : null}

              {/* Direct Phone Call & WhatsApp Contact Buttons */}
              <div className="mt-5 pt-4 border-t border-[#EEF2EF]">
                <span className="block text-xs font-semibold text-[#5E7166] mb-2">
                  {t('publicContactTitle')}
                </span>
                <div className="flex flex-wrap items-center gap-2.5">
                  {telHref ? (
                    <a
                      href={telHref}
                      className="inline-flex items-center justify-center gap-2 px-5 h-11 min-w-[140px] rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-xs font-semibold transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      <span>{t('callSupplier')}</span>
                    </a>
                  ) : null}

                  {waHref ? (
                    <a
                      href={waHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-5 h-11 min-w-[140px] rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-xs font-semibold transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>{t('whatsappSupplier')}</span>
                    </a>
                  ) : null}

                  {isOwner ? (
                    <button
                      type="button"
                      onClick={() => onNavigate('create-job')}
                      className="inline-flex items-center justify-center gap-2 px-5 h-11 rounded-xl border border-[#C5D4CB] hover:border-[#0B4F32] text-xs font-semibold text-[#0D1F16] transition-colors"
                    >
                      <Plus className="w-4 h-4 text-[#0B4F32]" />
                      <span>{t('navPost')}</span>
                    </button>
                  ) : null}
                </div>
              </div>

              {/* Company Office Location (Supplier Profile ONLY) */}
              {supplier.officeAddress || safeOfficeMapLink || isOwner ? (
                <div className="mt-5 pt-4 border-t border-[#EEF2EF]">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#5E7166] mb-2">
                    <MapPin className="w-3.5 h-3.5 text-[#0B4F32]" />
                    <span>{t('officeLocationTitle')}</span>
                  </div>

                  {supplier.officeAddress ? (
                    <p className="text-sm font-medium text-[#0D1F16] leading-relaxed">
                      {supplier.officeAddress}
                    </p>
                  ) : !safeOfficeMapLink && isOwner ? (
                    <p className="text-xs text-[#5E7166]">{t('noOfficeLocationNote')}</p>
                  ) : null}

                  {safeOfficeMapLink ? (
                    <div className="mt-3">
                      <a
                        href={safeOfficeMapLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center justify-center gap-2 px-5 h-11 rounded-xl border border-[#0B4F32] bg-[#F0F4F1] hover:bg-[#0B4F32] text-[#0B4F32] hover:text-white text-xs font-semibold transition-colors"
                      >
                        <MapPin className="w-4 h-4 shrink-0" />
                        <span>{t('openOfficeMapBtn')}</span>
                        <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                      </a>
                    </div>
                  ) : null}
                </div>
              ) : null}
            </div>
          </div>
        </div>

        {/* Protected Company Documents (Visible ONLY to Owning Supplier & Platform Admin) */}
        {canViewProtectedDocs ? (
          <div className="p-6 border-t border-[#E2E8E4] bg-[#F6F8F7]">
            <div className="flex items-center gap-2 text-sm font-bold text-[#0D1F16]">
              <Lock className="w-4 h-4 text-[#0B4F32]" />
              <h2>{t('protectedDocsTitle')}</h2>
            </div>
            <p className="text-xs text-[#5E7166] mt-0.5">{t('protectedDocsDesc')}</p>
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white border border-[#E2E8E4] rounded-xl p-3.5">
                <span className="text-xs text-[#5E7166]">CR Number</span>
                <p className="font-mono-tabular text-sm font-bold text-[#0D1F16] mt-0.5">
                  {supplier.crNumber || '—'}
                </p>
              </div>
              <div className="bg-white border border-[#E2E8E4] rounded-xl p-3.5">
                <span className="text-xs text-[#5E7166]">Qiwa Establishment ID</span>
                <p className="font-mono-tabular text-sm font-bold text-[#0D1F16] mt-0.5">
                  {supplier.qiwaId || 'Not provided'}
                </p>
              </div>
              <div className="bg-white border border-[#E2E8E4] rounded-xl p-3.5">
                <span className="text-xs text-[#5E7166]">GOSI Certificate Ref</span>
                <p className="font-mono-tabular text-sm font-bold text-[#0D1F16] mt-0.5">
                  {supplier.gosiReference || 'Not provided'}
                </p>
              </div>
            </div>
          </div>
        ) : null}

        {/* Inline Edit Form for Owning Supplier */}
        {isOwner && editing ? (
          <form onSubmit={handleSaveProfile} className="p-6 border-t border-[#E2E8E4] bg-white space-y-4">
            <h2 className="font-display text-base font-bold text-[#0D1F16]">
              {t('editProfile')}
            </h2>
            {saveError ? (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800">
                {saveError}
              </div>
            ) : null}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                  {t('companyNameLabel')}
                </label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                  {t('contactNameLabel')}
                </label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                  Business Phone
                </label>
                <input
                  type="tel"
                  required
                  value={businessPhone}
                  onChange={(e) => setBusinessPhone(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                  WhatsApp Number
                </label>
                <input
                  type="tel"
                  required
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                  {t('cityLabel')}
                </label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] bg-white text-sm"
                >
                  {SAUDI_CITIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                  {t('crNumberLabel')} (Private)
                </label>
                <input
                  type="text"
                  required
                  value={crNumber}
                  onChange={(e) => setCrNumber(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                  {t('qiwaIdLabel')}
                </label>
                <input
                  type="text"
                  value={qiwaId}
                  onChange={(e) => setQiwaId(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                  {t('gosiRefLabel')}
                </label>
                <input
                  type="text"
                  value={gosiReference}
                  onChange={(e) => setGosiReference(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                {t('officeAddressLabel')}
              </label>
              <input
                type="text"
                maxLength={300}
                value={officeAddress}
                onChange={(e) => setOfficeAddress(e.target.value)}
                placeholder={t('officeAddressPlaceholder')}
                className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0D1F16] mb-1">
                {t('officeMapLinkLabel')}
              </label>
              <input
                type="url"
                maxLength={600}
                value={officeMapLink}
                onChange={(e) => setOfficeMapLink(e.target.value)}
                placeholder={t('officeMapLinkPlaceholder')}
                className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular"
              />
              <p className="text-[11px] text-[#5E7166] mt-1">{t('officeMapLinkHint')}</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0D1F16] mb-1">{t('bioLabel')}</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full p-3 rounded-xl border border-[#C5D4CB] text-sm"
              />
            </div>

            <div>
              <span className="block text-xs font-semibold text-[#0D1F16] mb-2">Trade Specialties</span>
              <div className="flex flex-wrap gap-2">
                {TRADE_CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => toggleSpecialty(cat)}
                    className={`px-3 py-1.5 min-h-[36px] rounded-lg text-xs font-medium border ${
                      specialties.includes(cat)
                        ? 'bg-[#0B4F32] text-white border-[#0B4F32]'
                        : 'bg-white text-[#475B50] border-[#C5D4CB]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="px-6 h-11 rounded-xl bg-[#0B4F32] text-white text-sm font-semibold"
            >
              {saving ? '...' : t('saveChanges')}
            </button>
          </form>
        ) : null}
      </section>

      {/* Received Applications (for Owning Supplier) */}
      {isOwner ? (
        <section className="mt-8">
          <h2 className="font-display text-xl font-bold text-[#0D1F16] mb-3">
            {t('receivedAppsTab')} ({applications.length})
          </h2>
          {applications.length === 0 ? (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl p-6 text-sm text-[#5E7166]">
              No worker applications received yet.
            </div>
          ) : (
            <div className="bg-white border border-[#E2E8E4] rounded-2xl divide-y divide-[#EEF2EF]">
              {applications.map((app) => (
                <div
                  key={app.id}
                  className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2 text-xs text-[#5E7166]">
                      <span>{app.jobTitle}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{formatRelativeDate(app.createdAt)}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-[#0B4F32] capitalize">{app.status}</span>
                    </div>
                    <p className="font-display text-base font-bold text-[#0D1F16] mt-1">
                      {app.workerName} · {app.workerTrade}
                    </p>
                    <p className="text-xs text-[#5E7166] font-mono-tabular mt-0.5">
                      {app.workerPhone} · {app.workerCity} ·{' '}
                      {app.iqamaTransferable ? 'Transferable Iqama Ready' : 'Standard Transfer'}
                    </p>
                    <p className="text-sm text-[#475B50] mt-2">{app.note}</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleAppStatus(app.id, 'shortlisted')}
                      className={`px-3 py-2 min-h-[40px] rounded-lg text-xs font-semibold border ${
                        app.status === 'shortlisted'
                          ? 'bg-[#0B4F32] text-white border-[#0B4F32]'
                          : 'bg-white text-[#0D1F16] border-[#C5D4CB]'
                      }`}
                    >
                      Shortlist
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAppStatus(app.id, 'accepted')}
                      className={`px-3 py-2 min-h-[40px] rounded-lg text-xs font-semibold border ${
                        app.status === 'accepted'
                          ? 'bg-emerald-700 text-white border-emerald-700'
                          : 'bg-white text-[#0B4F32] border-[#C5D4CB]'
                      }`}
                    >
                      Accept
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAppStatus(app.id, 'declined')}
                      className="px-3 py-2 min-h-[40px] rounded-lg text-xs font-semibold border border-[#E2E8E4] text-[#5E7166] hover:text-red-700"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      ) : null}

      {/* Supplier's Jobs */}
      <section className="mt-8">
        <h2 className="font-display text-xl font-bold text-[#0D1F16] mb-4">
          {t('myPostsTab')} ({jobs.length})
        </h2>

        {jobs.length === 0 ? (
          <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 text-center">
            <Building2 className="w-7 h-7 text-[#5E7166] mx-auto mb-2" />
            <p className="font-display text-base font-semibold text-[#0D1F16]">
              No job posts published yet
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {jobs.map((job) => (
              <div key={job.id} className="flex flex-col gap-2">
                <JobCard
                  job={job}
                  onSelectJob={onSelectJob}
                  onSelectSupplier={onSelectSupplier}
                  onViewCircular={onViewCircular}
                />
                {isOwner && !job.isDemo ? (
                  <div className="flex items-center justify-between gap-2 px-2 text-xs">
                    <span className="text-[#5E7166] capitalize">
                      Status: <strong>{job.status}</strong>
                    </span>
                    <div className="flex items-center gap-2">
                      {user?.approvalStatus === 'approved' && job.postType !== 'circular_image' ? (
                        <button
                          type="button"
                          onClick={() => onEditJob(job)}
                          className="inline-flex items-center gap-1 font-semibold text-[#0B4F32] hover:underline min-h-[36px]"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>{t('editJobBtn')}</span>
                        </button>
                      ) : null}
                      <button
                        type="button"
                        onClick={() => handleDeleteOwnJob(job.id)}
                        className="inline-flex items-center gap-1 font-semibold text-red-700 hover:underline min-h-[36px]"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{t('deleteBtn')}</span>
                      </button>
                    </div>
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
