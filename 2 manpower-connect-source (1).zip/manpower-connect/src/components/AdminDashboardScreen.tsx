import { useEffect, useState } from 'react';
import { signInWithPopup } from 'firebase/auth';
import {
  AlertCircle,
  CheckCircle2,
  PauseCircle,
  PlayCircle,
  ShieldCheck,
  Trash2,
  XCircle,
} from 'lucide-react';
import { auth, googleProvider } from '../firebase';
import { useI18n } from '../i18n';
import {
  adminUpdateJobApproval,
  adminUpdateSupplierApproval,
  BOOTSTRAPPED_ADMIN_EMAIL,
  deleteLiveJob,
  fetchAdminFirestoreOverview,
} from '../services/firestoreMarketplace';
import type {
  JobApprovalStatus,
  JobPost,
  JobStatus,
  PublicUser,
  ScreenName,
  SupplierApprovalStatus,
} from '../types';
import { formatNumber, formatRelativeDate, formatSarRange } from '../utils';

interface AdminDashboardScreenProps {
  user: PublicUser | null;
  onSelectJob: (jobId: string) => void;
  onSelectSupplier: (supplierId: string) => void;
  onDataUpdated: () => void;
  onNavigate: (screen: ScreenName) => void;
}

export function AdminDashboardScreen({
  user,
  onSelectJob,
  onSelectSupplier,
  onDataUpdated,
  onNavigate,
}: AdminDashboardScreenProps) {
  const { t } = useI18n();
  const [tab, setTab] = useState<'suppliers' | 'jobs'>('suppliers');
  const [supplierFilter, setSupplierFilter] = useState<'all' | SupplierApprovalStatus>('all');
  const [jobFilter, setJobFilter] = useState<'all' | JobApprovalStatus>('all');
  const [suppliers, setSuppliers] = useState<PublicUser[]>([]);
  const [jobs, setJobs] = useState<JobPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function fetchOverview() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchAdminFirestoreOverview();
      setSuppliers(res.suppliers);
      setJobs(res.jobs);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load admin overview.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (user?.role === 'admin') {
      fetchOverview();
    } else {
      setLoading(false);
    }
  }, [user?.id, user?.role]);

  async function handleAdminGoogleSignIn() {
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Google sign-in failed.');
    }
  }

  async function handleSupplierDecision(supplierId: string, status: SupplierApprovalStatus) {
    setBusyId(supplierId);
    try {
      const note =
        status === 'approved'
          ? 'CR & Qiwa standing verified by Platform Admin.'
          : status === 'rejected'
          ? 'Commercial Registration could not be verified.'
          : 'Re-opened for compliance verification.';
      await adminUpdateSupplierApproval(supplierId, status, note);
      await fetchOverview();
      onDataUpdated();
    } finally {
      setBusyId(null);
    }
  }

  async function handleJobDecision(
    jobId: string,
    approvalStatus: JobApprovalStatus,
    status: JobStatus
  ) {
    setBusyId(jobId);
    try {
      const note =
        approvalStatus === 'approved'
          ? 'Approved for live worker feed.'
          : approvalStatus === 'rejected'
          ? 'Job post declined by compliance review.'
          : 'Pending review.';
      await adminUpdateJobApproval(jobId, approvalStatus, status, note);
      await fetchOverview();
      onDataUpdated();
    } finally {
      setBusyId(null);
    }
  }

  async function handleDeleteJob(jobId: string) {
    setBusyId(jobId);
    try {
      await deleteLiveJob(jobId);
      await fetchOverview();
      onDataUpdated();
    } finally {
      setBusyId(null);
    }
  }

  if (user?.role !== 'admin') {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-10 pb-24">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-8 text-center">
          <div className="w-12 h-12 rounded-2xl bg-[#F0F4F1] text-[#0B4F32] flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h1 className="font-display text-2xl font-bold text-[#0D1F16]">{t('adminTitle')}</h1>
          <p className="text-sm text-[#475B50] mt-2 leading-relaxed">
            Sign in with the authorized administrator Google account (
            <span className="font-mono-tabular font-semibold">{BOOTSTRAPPED_ADMIN_EMAIL}</span>) to
            approve supplier CR accounts and review job posts in Cloud Firestore.
          </p>

          {error ? (
            <div className="mt-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800">
              {error}
            </div>
          ) : null}

          <div className="mt-6 flex flex-col sm:flex-row justify-center gap-3">
            <button
              type="button"
              onClick={handleAdminGoogleSignIn}
              className="px-6 h-12 rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-sm font-semibold transition-colors"
            >
              {t('googleSignInBtn')}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('feed')}
              className="px-5 h-12 rounded-xl border border-[#C5D4CB] text-sm font-medium text-[#0D1F16]"
            >
              {t('navFeed')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  const pendingSuppliersCount = suppliers.filter((s) => s.approvalStatus === 'pending').length;
  const approvedSuppliersCount = suppliers.filter((s) => s.approvalStatus === 'approved').length;
  const pendingJobsCount = jobs.filter((j) => j.approvalStatus === 'pending').length;
  const approvedActiveJobs = jobs.filter(
    (j) => j.approvalStatus === 'approved' && j.status === 'active'
  );
  const totalWorkersRequested = approvedActiveJobs.reduce((acc, j) => acc + (j.headcount || 0), 0);

  const visibleSuppliers =
    supplierFilter === 'all'
      ? suppliers
      : suppliers.filter((s) => s.approvalStatus === supplierFilter);

  const visibleJobs =
    jobFilter === 'all' ? jobs : jobs.filter((j) => j.approvalStatus === jobFilter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-24 md:pb-12">
      <div className="pb-6 border-b border-[#E2E8E4]">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0D1F16]">
          {t('adminTitle')}
        </h1>
        <p className="text-sm text-[#5E7166] mt-1">{t('adminSubtitle')}</p>
      </div>

      {/* 4-Column Metric Strip */}
      <div className="mt-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-4">
          <span className="text-xs text-[#5E7166]">Pending Suppliers</span>
          <p className="font-mono-tabular text-2xl font-bold text-amber-700 mt-1">
            {formatNumber(pendingSuppliersCount)}
          </p>
        </div>
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-4">
          <span className="text-xs text-[#5E7166]">Pending Job Reviews</span>
          <p className="font-mono-tabular text-2xl font-bold text-amber-700 mt-1">
            {formatNumber(pendingJobsCount)}
          </p>
        </div>
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-4">
          <span className="text-xs text-[#5E7166]">{t('statApprovedSuppliers')}</span>
          <p className="font-mono-tabular text-2xl font-bold text-[#0B4F32] mt-1">
            {formatNumber(approvedSuppliersCount)}
          </p>
        </div>
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-4">
          <span className="text-xs text-[#5E7166]">{t('statOpenPositions')}</span>
          <p className="font-mono-tabular text-2xl font-bold text-[#0D1F16] mt-1">
            {formatNumber(totalWorkersRequested)}
          </p>
        </div>
      </div>

      {/* Primary Section Tabs */}
      <div className="mt-6 flex items-center gap-1 p-1 bg-[#EAEFEA] rounded-xl w-fit">
        <button
          type="button"
          onClick={() => setTab('suppliers')}
          className={`px-4 py-2 min-h-[40px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            tab === 'suppliers' ? 'bg-white text-[#0B4F32] shadow-sm' : 'text-[#475B50]'
          }`}
        >
          {t('tabSupplierApprovals')} ({suppliers.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('jobs')}
          className={`px-4 py-2 min-h-[40px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            tab === 'jobs' ? 'bg-white text-[#0B4F32] shadow-sm' : 'text-[#475B50]'
          }`}
        >
          {t('tabJobApprovals')} ({jobs.length})
        </button>
      </div>

      {error ? (
        <div className="mt-5 p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">
          {error}
        </div>
      ) : null}

      {tab === 'suppliers' ? (
        <section className="mt-5">
          <div className="flex items-center gap-2 overflow-x-auto pb-3">
            {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => setSupplierFilter(status)}
                className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs font-semibold capitalize whitespace-nowrap ${
                  supplierFilter === status
                    ? 'bg-[#0B4F32] text-white'
                    : 'bg-white border border-[#E2E8E4] text-[#475B50] hover:border-[#0B4F32]'
                }`}
              >
                {status === 'all' ? 'All Suppliers' : status}
              </button>
            ))}
          </div>

          <div className="bg-white border border-[#E2E8E4] rounded-2xl divide-y divide-[#EEF2EF]">
            {loading ? (
              <div className="p-8 text-sm text-[#5E7166]">Loading Firestore suppliers...</div>
            ) : visibleSuppliers.length === 0 ? (
              <div className="p-8 text-center text-sm text-[#5E7166]">
                No suppliers in this verification state yet.
              </div>
            ) : (
              visibleSuppliers.map((sup) => {
                const isBusy = busyId === sup.id;
                return (
                  <div
                    key={sup.id}
                    className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        {sup.approvalStatus === 'approved' ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-[#0B4F32]">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Approved
                          </span>
                        ) : sup.approvalStatus === 'rejected' ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-red-700">
                            <XCircle className="w-3.5 h-3.5" />
                            Declined
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
                            <AlertCircle className="w-3.5 h-3.5" />
                            Pending Review
                          </span>
                        )}
                        <span aria-hidden="true" className="text-[#A3B5AA]">·</span>
                        <span className="font-mono-tabular text-[#5E7166]">
                          CR {sup.crNumber || 'Pending'}
                        </span>
                        {sup.qiwaId ? (
                          <>
                            <span aria-hidden="true" className="text-[#A3B5AA]">·</span>
                            <span className="font-mono-tabular text-[#5E7166]">Qiwa {sup.qiwaId}</span>
                          </>
                        ) : null}
                        <span aria-hidden="true" className="text-[#A3B5AA]">·</span>
                        <span className="text-[#5E7166]">{sup.city}</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => onSelectSupplier(sup.id)}
                        className="mt-1 font-display text-base font-bold text-[#0D1F16] hover:text-[#0B4F32] text-left"
                      >
                        {sup.companyName || sup.name}
                      </button>

                      <p className="text-xs text-[#475B50] mt-1 font-mono-tabular">
                        {sup.name} · {sup.businessPhone || sup.phone}
                      </p>
                      {sup.adminNote ? (
                        <p className="text-xs text-[#5E7166] mt-1">Note: {sup.adminNote}</p>
                      ) : null}
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      {sup.approvalStatus !== 'approved' ? (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleSupplierDecision(sup.id, 'approved')}
                          className="px-4 py-2 min-h-[40px] rounded-xl bg-[#0B4F32] hover:bg-[#073823] disabled:opacity-50 text-white text-xs font-semibold transition-colors"
                        >
                          {t('approveBtn')}
                        </button>
                      ) : null}
                      {sup.approvalStatus !== 'rejected' ? (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleSupplierDecision(sup.id, 'rejected')}
                          className="px-4 py-2 min-h-[40px] rounded-xl border border-red-200 hover:bg-red-50 disabled:opacity-50 text-red-700 text-xs font-semibold transition-colors"
                        >
                          {t('rejectBtn')}
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleSupplierDecision(sup.id, 'pending')}
                          className="px-4 py-2 min-h-[40px] rounded-xl border border-[#C5D4CB] text-xs font-semibold text-[#475B50]"
                        >
                          Re-open
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>
      ) : (
        <section className="mt-5">
          <div className="flex items-center gap-2 overflow-x-auto pb-3">
            {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => setJobFilter(status)}
                className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs font-semibold capitalize whitespace-nowrap ${
                  jobFilter === status
                    ? 'bg-[#0B4F32] text-white'
                    : 'bg-white border border-[#E2E8E4] text-[#475B50] hover:border-[#0B4F32]'
                }`}
              >
                {status === 'all' ? 'All Job Posts' : status}
              </button>
            ))}
          </div>

          <div className="bg-white border border-[#E2E8E4] rounded-2xl divide-y divide-[#EEF2EF]">
            {visibleJobs.length === 0 ? (
              <div className="p-8 text-center text-sm text-[#5E7166]">
                No job posts in this review state yet.
              </div>
            ) : (
              visibleJobs.map((job) => {
                const isBusy = busyId === job.id;
                return (
                  <div
                    key={job.id}
                    className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-[#5E7166]">
                        <span
                          className={`font-semibold capitalize ${
                            job.approvalStatus === 'approved'
                              ? 'text-[#0B4F32]'
                              : job.approvalStatus === 'rejected'
                              ? 'text-red-700'
                              : 'text-amber-700'
                          }`}
                        >
                          Approval: {job.approvalStatus}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="capitalize">Listing: {job.status}</span>
                        <span aria-hidden="true">·</span>
                        <span>{job.city || job.supplierCity}</span>
                        {job.salaryMin && job.salaryMax ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono-tabular">
                              {formatSarRange(job.salaryMin, job.salaryMax)}
                            </span>
                          </>
                        ) : null}
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{formatRelativeDate(job.createdAt)}</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => onSelectJob(job.id)}
                        className="mt-1 font-display text-base font-bold text-[#0D1F16] hover:text-[#0B4F32] text-left"
                      >
                        {job.title || `${job.supplierName} · ${t('circularBadgeLabel')}`}
                      </button>
                      <p className="text-xs text-[#475B50] mt-0.5">{job.supplierName}</p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      {job.approvalStatus !== 'approved' ? (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleJobDecision(job.id, 'approved', 'active')}
                          className="px-4 py-2 min-h-[40px] rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-xs font-semibold"
                        >
                          {t('approveBtn')}
                        </button>
                      ) : null}

                      {job.approvalStatus !== 'rejected' ? (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleJobDecision(job.id, 'rejected', 'paused')}
                          className="px-3.5 py-2 min-h-[40px] rounded-xl border border-red-200 hover:bg-red-50 text-red-700 text-xs font-semibold"
                        >
                          {t('rejectBtn')}
                        </button>
                      ) : null}

                      {job.approvalStatus === 'approved' ? (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() =>
                            handleJobDecision(
                              job.id,
                              'approved',
                              job.status === 'active' ? 'paused' : 'active'
                            )
                          }
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-xl border border-[#C5D4CB] text-xs font-semibold text-[#0D1F16]"
                        >
                          {job.status === 'active' ? (
                            <>
                              <PauseCircle className="w-3.5 h-3.5 text-amber-700" />
                              <span>{t('pauseBtn')}</span>
                            </>
                          ) : (
                            <>
                              <PlayCircle className="w-3.5 h-3.5 text-[#0B4F32]" />
                              <span>{t('activateBtn')}</span>
                            </>
                          )}
                        </button>
                      ) : null}

                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => handleDeleteJob(job.id)}
                        className="inline-flex items-center gap-1 px-3 py-2 min-h-[40px] rounded-xl border border-red-200 text-red-700 text-xs font-semibold"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{t('deleteBtn')}</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>
      )}
    </div>
  );
}
