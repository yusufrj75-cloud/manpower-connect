import { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  reload,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import type { User as FirebaseUser } from 'firebase/auth';
import { Building2, CheckCircle2, Lock, MailCheck, ShieldCheck, UserCheck } from 'lucide-react';
import { SAUDI_CITIES, TRADE_CATEGORIES } from '../constants';
import { auth, googleProvider } from '../firebase';
import { useI18n } from '../i18n';
import {
  completeUserOnboarding,
  fetchUserSessionProfile,
} from '../services/firestoreMarketplace';
import type { PublicUser } from '../types';

interface LoginScreenProps {
  pendingFirebaseUser: FirebaseUser | null;
  onSuccess: (user: PublicUser) => void;
  onCancel: () => void;
}

const PENDING_PROFILE_KEY = 'manpower_connect_pending_onboarding';

function savePendingOnboarding(uid: string, data: Record<string, unknown>) {
  try {
    localStorage.setItem(`${PENDING_PROFILE_KEY}_${uid}`, JSON.stringify(data));
  } catch {
    // ignore
  }
}

function readPendingOnboarding(uid: string): Record<string, unknown> | null {
  try {
    const raw = localStorage.getItem(`${PENDING_PROFILE_KEY}_${uid}`);
    return raw ? (JSON.parse(raw) as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

function clearPendingOnboarding(uid: string) {
  try {
    localStorage.removeItem(`${PENDING_PROFILE_KEY}_${uid}`);
  } catch {
    // ignore
  }
}

export function LoginScreen({ pendingFirebaseUser, onSuccess, onCancel }: LoginScreenProps) {
  const { t } = useI18n();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [role, setRole] = useState<'worker' | 'supplier'>('worker');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState(pendingFirebaseUser?.displayName || '');
  const [phone, setPhone] = useState('+966 5');
  const [city, setCity] = useState<string>('Riyadh');

  // Worker specific
  const [trade, setTrade] = useState<string>(TRADE_CATEGORIES[0]);
  const [yearsExperience, setYearsExperience] = useState('5');
  const [iqamaTransferable, setIqamaTransferable] = useState(true);

  // Supplier specific + protected private documents
  const [companyName, setCompanyName] = useState('');
  const [officeAddress, setOfficeAddress] = useState('');
  const [officeMapLink, setOfficeMapLink] = useState('');
  const [crNumber, setCrNumber] = useState('');
  const [qiwaId, setQiwaId] = useState('');
  const [gosiReference, setGosiReference] = useState('');
  const [bio, setBio] = useState('');

  // Onboarding / Verification state
  const [onboardingUser, setOnboardingUser] = useState<FirebaseUser | null>(
    pendingFirebaseUser && pendingFirebaseUser.emailVerified ? pendingFirebaseUser : null
  );
  const [awaitingEmailVerification, setAwaitingEmailVerification] = useState<FirebaseUser | null>(
    pendingFirebaseUser && !pendingFirebaseUser.emailVerified ? pendingFirebaseUser : null
  );

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  function mapAuthError(err: unknown): string {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('auth/operation-not-allowed')) {
      return 'Email/Password sign-in is not yet enabled in Firebase Console -> Authentication -> Sign-in method. Please use Google Sign-In below or enable Email/Password in Firebase Console.';
    }
    if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password')) {
      return 'Invalid email or password.';
    }
    if (msg.includes('auth/email-already-in-use')) {
      return 'An account with this email already exists. Please sign in instead.';
    }
    if (msg.includes('auth/popup-closed-by-user')) {
      return 'Google Sign-In popup was closed before completion.';
    }
    return msg;
  }

  async function finalizeAfterAuth(fbUser: FirebaseUser) {
    if (!fbUser.emailVerified) {
      setAwaitingEmailVerification(fbUser);
      return;
    }

    const existing = await fetchUserSessionProfile(fbUser);
    if (existing) {
      clearPendingOnboarding(fbUser.uid);
      onSuccess(existing);
      return;
    }

    // Check if they registered via email/password and have saved pending onboarding payload
    const pending = readPendingOnboarding(fbUser.uid);
    if (pending) {
      const created = await completeUserOnboarding(fbUser, {
        role: pending.role as 'worker' | 'supplier',
        name: String(pending.name || fbUser.displayName || 'User'),
        phone: String(pending.phone || '+966 50 000 0000'),
        city: String(pending.city || 'Riyadh'),
        trade: pending.trade ? String(pending.trade) : undefined,
        yearsExperience: Number(pending.yearsExperience || 1),
        iqamaTransferable: Boolean(pending.iqamaTransferable),
        companyName: pending.companyName ? String(pending.companyName) : undefined,
        officeAddress: pending.officeAddress ? String(pending.officeAddress) : undefined,
        officeMapLink: pending.officeMapLink ? String(pending.officeMapLink) : undefined,
        crNumber: pending.crNumber ? String(pending.crNumber) : undefined,
        qiwaId: pending.qiwaId ? String(pending.qiwaId) : undefined,
        gosiReference: pending.gosiReference ? String(pending.gosiReference) : undefined,
        bio: pending.bio ? String(pending.bio) : undefined,
        specialties: Array.isArray(pending.specialties) ? pending.specialties.map(String) : undefined,
      });
      clearPendingOnboarding(fbUser.uid);
      onSuccess(created);
      return;
    }

    // Google user signing in for the first time -> show Role Onboarding form
    setName(fbUser.displayName || '');
    setOnboardingUser(fbUser);
  }

  async function handleGoogleSignIn() {
    setError(null);
    setInfoMsg(null);
    setLoading(true);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      await finalizeAfterAuth(cred.user);
    } catch (err) {
      setError(mapAuthError(err));
    } finally {
      setLoading(false);
    }
  }

  async function handleEmailLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfoMsg(null);
    setLoading(true);
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      await finalizeAfterAuth(cred.user);
    } catch (err) {
      setError(mapAuthError(err));
    } finally {
      setLoading(false);
    }
  }

  async function handleEmailRegister(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfoMsg(null);
    setLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
      await updateProfile(cred.user, { displayName: name.trim() });

      savePendingOnboarding(cred.user.uid, {
        role,
        name: name.trim(),
        phone: phone.trim(),
        city,
        trade: role === 'worker' ? trade : undefined,
        yearsExperience: role === 'worker' ? Number(yearsExperience) : undefined,
        iqamaTransferable: role === 'worker' ? iqamaTransferable : undefined,
        companyName: role === 'supplier' ? companyName.trim() : undefined,
        officeAddress: role === 'supplier' ? officeAddress.trim() : undefined,
        officeMapLink: role === 'supplier' ? officeMapLink.trim() : undefined,
        crNumber: role === 'supplier' ? crNumber.trim() : undefined,
        qiwaId: role === 'supplier' ? qiwaId.trim() : undefined,
        gosiReference: role === 'supplier' ? gosiReference.trim() : undefined,
        bio: role === 'supplier' ? bio.trim() : undefined,
        specialties: role === 'supplier' ? [trade] : undefined,
      });

      await sendEmailVerification(cred.user);
      setAwaitingEmailVerification(cred.user);
      setInfoMsg('Verification email sent. Please check your inbox and verify before continuing.');
    } catch (err) {
      setError(mapAuthError(err));
    } finally {
      setLoading(false);
    }
  }

  async function handleOnboardingSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!onboardingUser) return;
    setError(null);
    setLoading(true);
    try {
      const profile = await completeUserOnboarding(onboardingUser, {
        role,
        name,
        phone,
        city,
        trade: role === 'worker' ? trade : undefined,
        yearsExperience: role === 'worker' ? Number(yearsExperience) : undefined,
        iqamaTransferable: role === 'worker' ? iqamaTransferable : undefined,
        companyName: role === 'supplier' ? companyName : undefined,
        officeAddress: role === 'supplier' ? officeAddress : undefined,
        officeMapLink: role === 'supplier' ? officeMapLink : undefined,
        crNumber: role === 'supplier' ? crNumber : undefined,
        qiwaId: role === 'supplier' ? qiwaId : undefined,
        gosiReference: role === 'supplier' ? gosiReference : undefined,
        bio: role === 'supplier' ? bio : undefined,
        specialties: role === 'supplier' ? [trade] : undefined,
      });
      onSuccess(profile);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save profile.');
    } finally {
      setLoading(false);
    }
  }

  async function handleRefreshVerification() {
    if (!awaitingEmailVerification) return;
    setError(null);
    setLoading(true);
    try {
      await reload(awaitingEmailVerification);
      const refreshed = auth.currentUser;
      if (refreshed && refreshed.emailVerified) {
        setAwaitingEmailVerification(null);
        await finalizeAfterAuth(refreshed);
      } else {
        setError('Email is not verified yet. Please click the verification link in your email.');
      }
    } catch (err) {
      setError(mapAuthError(err));
    } finally {
      setLoading(false);
    }
  }

  async function handleResendVerification() {
    if (!awaitingEmailVerification) return;
    setError(null);
    setInfoMsg(null);
    try {
      await sendEmailVerification(awaitingEmailVerification);
      setInfoMsg('Verification link re-sent to your email.');
    } catch (err) {
      setError(mapAuthError(err));
    }
  }

  // Screen State A: Awaiting Email Verification
  if (awaitingEmailVerification) {
    return (
      <div className="max-w-xl mx-auto px-4 sm:px-6 py-10 pb-24">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-6 sm:p-8 text-center">
          <div className="w-12 h-12 rounded-2xl bg-[#F0F4F1] text-[#0B4F32] flex items-center justify-center mx-auto mb-4">
            <MailCheck className="w-6 h-6" />
          </div>
          <h1 className="font-display text-2xl font-bold text-[#0D1F16]">{t('verifyEmailTitle')}</h1>
          <p className="text-sm text-[#475B50] mt-2 leading-relaxed">{t('verifyEmailDesc')}</p>
          <p className="text-xs font-mono-tabular text-[#0B4F32] mt-2">
            {awaitingEmailVerification.email}
          </p>

          {error ? (
            <div className="mt-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800">
              {error}
            </div>
          ) : null}
          {infoMsg ? (
            <div className="mt-4 p-3 rounded-xl bg-[#F0F4F1] border border-[#C5D4CB] text-xs text-[#0B4F32]">
              {infoMsg}
            </div>
          ) : null}

          <div className="mt-6 flex flex-col gap-3">
            <button
              type="button"
              disabled={loading}
              onClick={handleRefreshVerification}
              className="w-full h-12 rounded-xl bg-[#0B4F32] hover:bg-[#073823] text-white text-sm font-semibold"
            >
              {loading ? '...' : t('refreshVerifyBtn')}
            </button>
            <button
              type="button"
              onClick={handleResendVerification}
              className="w-full h-11 rounded-xl border border-[#C5D4CB] text-sm font-medium text-[#0D1F16]"
            >
              {t('resendVerifyBtn')}
            </button>
            <button
              type="button"
              onClick={handleGoogleSignIn}
              className="w-full h-11 rounded-xl bg-[#F0F4F1] text-xs font-semibold text-[#0B4F32]"
            >
              {t('googleSignInBtn')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Screen State B: First-time Google Sign-In Role Onboarding
  if (onboardingUser) {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8 pb-24">
        <div className="bg-white border border-[#E2E8E4] rounded-2xl p-6 sm:p-8">
          <h1 className="font-display text-2xl font-bold text-[#0D1F16]">
            {t('completeOnboardingTitle')}
          </h1>
          <p className="text-sm text-[#5E7166] mt-1">{t('completeOnboardingDesc')}</p>

          {error ? (
            <div className="mt-4 p-3.5 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">
              {error}
            </div>
          ) : null}

          <form onSubmit={handleOnboardingSubmit} className="mt-6 space-y-4">
            <RoleFieldsForm
              role={role}
              setRole={setRole}
              name={name}
              setName={setName}
              phone={phone}
              setPhone={setPhone}
              city={city}
              setCity={setCity}
              trade={trade}
              setTrade={setTrade}
              yearsExperience={yearsExperience}
              setYearsExperience={setYearsExperience}
              iqamaTransferable={iqamaTransferable}
              setIqamaTransferable={setIqamaTransferable}
              companyName={companyName}
              setCompanyName={setCompanyName}
              officeAddress={officeAddress}
              setOfficeAddress={setOfficeAddress}
              officeMapLink={officeMapLink}
              setOfficeMapLink={setOfficeMapLink}
              crNumber={crNumber}
              setCrNumber={setCrNumber}
              qiwaId={qiwaId}
              setQiwaId={setQiwaId}
              gosiReference={gosiReference}
              setGosiReference={setGosiReference}
              bio={bio}
              setBio={setBio}
            />

            <button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-xl bg-[#0B4F32] hover:bg-[#073823] disabled:opacity-60 text-white text-sm font-semibold"
            >
              {loading ? '...' : 'Save & Continue'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Screen State C: Standard Sign In / Registration
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 pb-24 md:pb-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-7 bg-white border border-[#E2E8E4] rounded-2xl p-6 sm:p-8">
          <h1 className="font-display text-2xl font-bold text-[#0D1F16]">
            {mode === 'login' ? t('authTitleSignIn') : t('authTitleRegister')}
          </h1>
          <p className="text-sm text-[#5E7166] mt-1">
            {mode === 'login' ? t('authSubSignIn') : t('authSubRegister')}
          </p>

          {/* Primary Google Sign-In (Works Immediately with Provisioned Firebase) */}
          <button
            type="button"
            disabled={loading}
            onClick={handleGoogleSignIn}
            className="mt-5 w-full h-12 rounded-xl border border-[#0B4F32] bg-[#F0F4F1] hover:bg-[#E2ECE6] text-[#0B4F32] text-sm font-semibold flex items-center justify-center gap-2.5 transition-colors"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{t('googleSignInBtn')}</span>
          </button>

          <div className="my-5 flex items-center gap-3 text-xs text-[#5E7166]">
            <span className="h-px flex-1 bg-[#E2E8E4]" />
            <span>{t('orDivider')}</span>
            <span className="h-px flex-1 bg-[#E2E8E4]" />
          </div>

          {/* Mode Toggle */}
          <div className="grid grid-cols-2 p-1 bg-[#F0F4F1] rounded-xl mb-5">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
              }}
              className={`min-h-[44px] text-sm font-semibold rounded-lg transition-colors ${
                mode === 'login'
                  ? 'bg-white text-[#0B4F32] shadow-sm'
                  : 'text-[#475B50] hover:text-[#0D1F16]'
              }`}
            >
              {t('tabSignIn')}
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError(null);
              }}
              className={`min-h-[44px] text-sm font-semibold rounded-lg transition-colors ${
                mode === 'register'
                  ? 'bg-white text-[#0B4F32] shadow-sm'
                  : 'text-[#475B50] hover:text-[#0D1F16]'
              }`}
            >
              {t('tabRegister')}
            </button>
          </div>

          {error ? (
            <div
              role="alert"
              className="mb-5 p-3.5 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800"
            >
              {error}
            </div>
          ) : null}

          {mode === 'login' ? (
            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div>
                <label htmlFor="login-email" className="block text-sm font-medium text-[#0D1F16] mb-1.5">
                  {t('emailLabel')}
                </label>
                <input
                  id="login-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.sa"
                  className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] bg-white text-sm focus:outline-none focus:border-[#0B4F32]"
                />
              </div>

              <div>
                <label htmlFor="login-password" className="block text-sm font-medium text-[#0D1F16] mb-1.5">
                  {t('passwordLabel')}
                </label>
                <input
                  id="login-password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] bg-white text-sm focus:outline-none focus:border-[#0B4F32]"
                />
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 h-12 rounded-xl bg-[#0B4F32] hover:bg-[#073823] disabled:opacity-60 text-white text-sm font-semibold transition-colors"
                >
                  {loading ? '...' : t('tabSignIn')}
                </button>
                <button
                  type="button"
                  onClick={onCancel}
                  className="px-5 h-12 rounded-xl border border-[#C5D4CB] text-sm font-medium text-[#475B50] hover:text-[#0D1F16]"
                >
                  Back
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleEmailRegister} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="reg-email" className="block text-sm font-medium text-[#0D1F16] mb-1.5">
                    {t('emailLabel')}
                  </label>
                  <input
                    id="reg-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@domain.sa"
                    className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm focus:outline-none focus:border-[#0B4F32]"
                  />
                </div>
                <div>
                  <label htmlFor="reg-password" className="block text-sm font-medium text-[#0D1F16] mb-1.5">
                    {t('passwordLabel')} (6+)
                  </label>
                  <input
                    id="reg-password"
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm focus:outline-none focus:border-[#0B4F32]"
                  />
                </div>
              </div>

              <RoleFieldsForm
                role={role}
                setRole={setRole}
                name={name}
                setName={setName}
                phone={phone}
                setPhone={setPhone}
                city={city}
                setCity={setCity}
                trade={trade}
                setTrade={setTrade}
                yearsExperience={yearsExperience}
                setYearsExperience={setYearsExperience}
                iqamaTransferable={iqamaTransferable}
                setIqamaTransferable={setIqamaTransferable}
                companyName={companyName}
                setCompanyName={setCompanyName}
                officeAddress={officeAddress}
                setOfficeAddress={setOfficeAddress}
                officeMapLink={officeMapLink}
                setOfficeMapLink={setOfficeMapLink}
                crNumber={crNumber}
                setCrNumber={setCrNumber}
                qiwaId={qiwaId}
                setQiwaId={setQiwaId}
                gosiReference={gosiReference}
                setGosiReference={setGosiReference}
                bio={bio}
                setBio={setBio}
              />

              <button
                type="submit"
                disabled={loading}
                className="w-full h-12 rounded-xl bg-[#0B4F32] hover:bg-[#073823] disabled:opacity-60 text-white text-sm font-semibold transition-colors"
              >
                {loading ? '...' : t('tabRegister')}
              </button>
            </form>
          )}
        </div>

        {/* Security & Data Protection Info Panel */}
        <aside className="lg:col-span-5 bg-white border border-[#E2E8E4] rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 text-[#0B4F32] font-display font-bold text-base">
            <Lock className="w-4 h-4" />
            <h2>Firebase Auth & Protected Data</h2>
          </div>

          <div className="space-y-3 text-xs text-[#475B50] leading-relaxed">
            <div className="p-3.5 rounded-xl bg-[#F6F8F7] border border-[#E2E8E4]">
              <p className="font-semibold text-[#0D1F16] mb-1">1. Instant Google Authentication</p>
              <p>
                Click <strong>{t('googleSignInBtn')}</strong> to authenticate immediately with verified
                Firebase identity, choose Worker or Supplier, and persist real data in Cloud Firestore.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#F6F8F7] border border-[#E2E8E4]">
              <p className="font-semibold text-[#0D1F16] mb-1">2. Protected PII & Company Docs</p>
              <p>
                Worker personal info and Supplier CR / Qiwa / GOSI numbers are stored in isolated private
                Firestore subcollections accessible strictly to the account owner and Platform Admin.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#F6F8F7] border border-[#E2E8E4] flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#0B4F32] shrink-0 mt-0.5" />
              <p>
                <strong>Admin Access:</strong> Signing in with the project administrator Google account (
                <span className="font-mono-tabular">yusufrj75@gmail.com</span>) unlocks the Admin Dashboard
                to approve suppliers and job posts.
              </p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

interface RoleFieldsFormProps {
  role: 'worker' | 'supplier';
  setRole: (r: 'worker' | 'supplier') => void;
  name: string;
  setName: (v: string) => void;
  phone: string;
  setPhone: (v: string) => void;
  city: string;
  setCity: (v: string) => void;
  trade: string;
  setTrade: (v: string) => void;
  yearsExperience: string;
  setYearsExperience: (v: string) => void;
  iqamaTransferable: boolean;
  setIqamaTransferable: (v: boolean) => void;
  companyName: string;
  setCompanyName: (v: string) => void;
  officeAddress: string;
  setOfficeAddress: (v: string) => void;
  officeMapLink: string;
  setOfficeMapLink: (v: string) => void;
  crNumber: string;
  setCrNumber: (v: string) => void;
  qiwaId: string;
  setQiwaId: (v: string) => void;
  gosiReference: string;
  setGosiReference: (v: string) => void;
  bio: string;
  setBio: (v: string) => void;
}

function RoleFieldsForm(props: RoleFieldsFormProps) {
  const { t } = useI18n();
  return (
    <>
      <div>
        <span className="block text-sm font-medium text-[#0D1F16] mb-2">{t('roleLabel')}</span>
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => props.setRole('worker')}
            className={`p-3.5 rounded-xl border text-left transition-colors min-h-[64px] ${
              props.role === 'worker'
                ? 'border-[#0B4F32] bg-[#F0F4F1] text-[#0D1F16]'
                : 'border-[#E2E8E4] bg-white text-[#475B50]'
            }`}
          >
            <div className="flex items-center gap-2 font-semibold text-sm">
              <UserCheck className="w-4 h-4 text-[#0B4F32]" />
              <span>{t('roleWorker')}</span>
            </div>
            <p className="text-xs text-[#5E7166] mt-1">{t('roleWorkerDesc')}</p>
          </button>

          <button
            type="button"
            onClick={() => props.setRole('supplier')}
            className={`p-3.5 rounded-xl border text-left transition-colors min-h-[64px] ${
              props.role === 'supplier'
                ? 'border-[#0B4F32] bg-[#F0F4F1] text-[#0D1F16]'
                : 'border-[#E2E8E4] bg-white text-[#475B50]'
            }`}
          >
            <div className="flex items-center gap-2 font-semibold text-sm">
              <Building2 className="w-4 h-4 text-[#0B4F32]" />
              <span>{t('roleSupplier')}</span>
            </div>
            <p className="text-xs text-[#5E7166] mt-1">{t('roleSupplierDesc')}</p>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-[#0D1F16] mb-1.5">
            {props.role === 'supplier' ? t('contactNameLabel') : t('fullNameLabel')}
          </label>
          <input
            type="text"
            required
            value={props.name}
            onChange={(e) => props.setName(e.target.value)}
            className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm focus:outline-none focus:border-[#0B4F32]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-[#0D1F16] mb-1.5">{t('phoneLabel')}</label>
          <input
            type="tel"
            required
            value={props.phone}
            onChange={(e) => props.setPhone(e.target.value)}
            placeholder="+966 5X XXX XXXX"
            className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular focus:outline-none focus:border-[#0B4F32]"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-[#0D1F16] mb-1.5">{t('cityLabel')}</label>
        <select
          value={props.city}
          onChange={(e) => props.setCity(e.target.value)}
          className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] bg-white text-sm focus:outline-none focus:border-[#0B4F32]"
        >
          {SAUDI_CITIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {props.role === 'supplier' ? (
        <div className="space-y-4 pt-2 border-t border-[#EEF2EF]">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#0D1F16] mb-1.5">
                {t('companyNameLabel')}
              </label>
              <input
                type="text"
                required
                value={props.companyName}
                onChange={(e) => props.setCompanyName(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm focus:outline-none focus:border-[#0B4F32]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0D1F16] mb-1.5">
                {t('crNumberLabel')}
              </label>
              <input
                type="text"
                required
                minLength={4}
                value={props.crNumber}
                onChange={(e) => props.setCrNumber(e.target.value)}
                placeholder="1010XXXXXX"
                className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular focus:outline-none focus:border-[#0B4F32]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#0D1F16] mb-1.5">
                {t('qiwaIdLabel')}
              </label>
              <input
                type="text"
                value={props.qiwaId}
                onChange={(e) => props.setQiwaId(e.target.value)}
                placeholder="Optional"
                className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular focus:outline-none focus:border-[#0B4F32]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#0D1F16] mb-1.5">
                {t('gosiRefLabel')}
              </label>
              <input
                type="text"
                value={props.gosiReference}
                onChange={(e) => props.setGosiReference(e.target.value)}
                placeholder="Optional"
                className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular focus:outline-none focus:border-[#0B4F32]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#0D1F16] mb-1.5">
              {t('officeAddressLabel')} (Optional)
            </label>
            <input
              type="text"
              maxLength={300}
              value={props.officeAddress}
              onChange={(e) => props.setOfficeAddress(e.target.value)}
              placeholder={t('officeAddressPlaceholder')}
              className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm focus:outline-none focus:border-[#0B4F32]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#0D1F16] mb-1.5">
              {t('officeMapLinkLabel')} (Optional)
            </label>
            <input
              type="url"
              maxLength={600}
              value={props.officeMapLink}
              onChange={(e) => props.setOfficeMapLink(e.target.value)}
              placeholder={t('officeMapLinkPlaceholder')}
              className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular focus:outline-none focus:border-[#0B4F32]"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#0D1F16] mb-1.5">{t('bioLabel')}</label>
            <textarea
              rows={2}
              value={props.bio}
              onChange={(e) => props.setBio(e.target.value)}
              className="w-full p-3 rounded-xl border border-[#C5D4CB] text-sm focus:outline-none focus:border-[#0B4F32]"
            />
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-[#0D1F16] mb-1.5">{t('tradeLabel')}</label>
            <select
              value={props.trade}
              onChange={(e) => props.setTrade(e.target.value)}
              className="w-full h-11 px-3 rounded-xl border border-[#C5D4CB] bg-white text-sm focus:outline-none focus:border-[#0B4F32]"
            >
              {TRADE_CATEGORIES.map((tc) => (
                <option key={tc} value={tc}>
                  {tc}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-[#0D1F16] mb-1.5">{t('expLabel')}</label>
            <input
              type="number"
              min={0}
              max={50}
              value={props.yearsExperience}
              onChange={(e) => props.setYearsExperience(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl border border-[#C5D4CB] text-sm font-mono-tabular focus:outline-none focus:border-[#0B4F32]"
            />
          </div>
          <label className="sm:col-span-2 flex items-center gap-2.5 text-sm text-[#0D1F16] min-h-[44px] cursor-pointer">
            <input
              type="checkbox"
              checked={props.iqamaTransferable}
              onChange={(e) => props.setIqamaTransferable(e.target.checked)}
              className="w-4 h-4 accent-[#0B4F32]"
            />
            <span>{t('iqamaLabel')}</span>
          </label>
        </div>
      )}
    </>
  );
}
