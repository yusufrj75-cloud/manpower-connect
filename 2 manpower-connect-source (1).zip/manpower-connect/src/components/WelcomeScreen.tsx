import { ArrowRight, CheckCircle2, Search, ShieldCheck, Users } from 'lucide-react';
import { ASSETS } from '../assetsMap';
import { DEMO_JOBS } from '../demoData';
import { useI18n } from '../i18n';
import type { JobPost, PublicUser, ScreenName } from '../types';
import { formatNumber } from '../utils';
import { JobCard } from './JobCard';
import { ResilientImage } from './ResilientImage';

interface WelcomeScreenProps {
  user: PublicUser | null;
  liveJobs: JobPost[];
  approvedSuppliersCount: number;
  onNavigate: (screen: ScreenName) => void;
  onSelectJob: (jobId: string) => void;
  onSelectSupplier: (supplierId: string) => void;
  onViewCircular?: (job: JobPost) => void;
}

export function WelcomeScreen({
  user,
  liveJobs,
  approvedSuppliersCount,
  onNavigate,
  onSelectJob,
  onSelectSupplier,
  onViewCircular,
}: WelcomeScreenProps) {
  const { t } = useI18n();

  const hasLiveJobs = liveJobs.length > 0;
  const previewJobs = hasLiveJobs ? liveJobs.slice(0, 3) : DEMO_JOBS.slice(0, 3);
  const totalLivePositions = liveJobs.reduce((sum, j) => sum + (j.headcount || 1), 0);

  return (
    <div className="pb-20 md:pb-12">
      {/* Hero Section */}
      <section className="bg-white border-b border-[#E2E8E4]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 lg:py-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            {/* Left Copy Column */}
            <div className="lg:col-span-6 flex flex-col justify-between gap-6">
              <div>
                <p className="text-xs font-semibold tracking-wider text-[#0B4F32] mb-3">
                  {t('heroKicker')}
                </p>
                <h1 className="font-display text-3xl sm:text-4xl lg:text-[2.65rem] font-bold text-[#0D1F16] leading-[1.15] tracking-tight text-balance">
                  {t('heroTitle')}
                </h1>
                <p className="mt-4 text-base text-[#475B50] leading-relaxed max-w-xl">
                  {t('heroDesc')}
                </p>

                <div className="mt-7 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onNavigate('feed')}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 min-h-[48px] text-sm font-semibold text-white bg-[#0B4F32] hover:bg-[#073823] rounded-xl transition-colors whitespace-nowrap"
                  >
                    <span>{t('ctaBrowse')}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  {user ? (
                    <button
                      type="button"
                      onClick={() =>
                        onNavigate(
                          user.role === 'admin'
                            ? 'admin'
                            : user.role === 'supplier'
                            ? 'create-job'
                            : 'search'
                        )
                      }
                      className="inline-flex items-center justify-center gap-2 px-5 py-3.5 min-h-[48px] text-sm font-semibold text-[#0B4F32] bg-[#F0F4F1] hover:bg-[#E2ECE6] rounded-xl transition-colors whitespace-nowrap"
                    >
                      {user.role === 'admin'
                        ? t('ctaAdminConsole')
                        : user.role === 'supplier'
                        ? t('ctaPublishDemand')
                        : t('ctaSearchTrade')}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onNavigate('login')}
                      className="inline-flex items-center justify-center gap-2 px-5 py-3.5 min-h-[48px] text-sm font-semibold text-[#0D1F16] bg-white border border-[#C5D4CB] hover:border-[#0B4F32] rounded-xl transition-colors whitespace-nowrap"
                    >
                      {t('ctaSignInRegister')}
                    </button>
                  )}
                </div>
              </div>

              <div className="pt-6 border-t border-[#EEF2EF] grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="flex items-start gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-[#0B4F32] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-[#0D1F16]">{t('trustAdminTitle')}</p>
                    <p className="text-xs text-[#5E7166] mt-0.5">{t('trustAdminDesc')}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-[#0B4F32] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-[#0D1F16]">{t('trustDirectTitle')}</p>
                    <p className="text-xs text-[#5E7166] mt-0.5">{t('trustDirectDesc')}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Visual Column */}
            <div className="lg:col-span-6">
              <div className="relative h-64 sm:h-80 lg:h-full min-h-[280px] rounded-2xl overflow-hidden border border-[#E2E8E4]">
                <ResilientImage
                  src={ASSETS.heroSkyline}
                  alt="Engineers reviewing project blueprints overlooking Riyadh skyline"
                  className="w-full h-full object-cover"
                  fallbackTitle="Riyadh Infrastructure & Workforce Operations"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#073823]/80 via-[#073823]/20 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <p className="text-xs font-medium text-white/80">
                    Riyadh · Jubail · Jeddah · Dammam · NEOM
                  </p>
                  <p className="font-display text-base sm:text-lg font-semibold mt-0.5">
                    MANPOWER CONNECT · Saudi Arabia
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 4-Column Quantitative Strip */}
          <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#F6F8F7] border border-[#E2E8E4] rounded-xl p-4">
              <span className="text-xs text-[#5E7166]">{t('statOpenPositions')}</span>
              <p className="font-mono-tabular text-2xl font-bold text-[#0B4F32] mt-1">
                {formatNumber(totalLivePositions)}
              </p>
            </div>
            <div className="bg-[#F6F8F7] border border-[#E2E8E4] rounded-xl p-4">
              <span className="text-xs text-[#5E7166]">{t('statActiveJobs')}</span>
              <p className="font-mono-tabular text-2xl font-bold text-[#0D1F16] mt-1">
                {formatNumber(liveJobs.length)}
              </p>
            </div>
            <div className="bg-[#F6F8F7] border border-[#E2E8E4] rounded-xl p-4">
              <span className="text-xs text-[#5E7166]">{t('statApprovedSuppliers')}</span>
              <p className="font-mono-tabular text-2xl font-bold text-[#0D1F16] mt-1">
                {formatNumber(approvedSuppliersCount)}
              </p>
            </div>
            <div className="bg-[#F6F8F7] border border-[#E2E8E4] rounded-xl p-4">
              <span className="text-xs text-[#5E7166]">{t('statCitiesCovered')}</span>
              <p className="font-mono-tabular text-2xl font-bold text-[#0D1F16] mt-1">9</p>
            </div>
          </div>
        </div>
      </section>

      {/* Two Role Pathways */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white border border-[#E2E8E4] rounded-2xl p-6 flex flex-col justify-between gap-4">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#F0F4F1] text-[#0B4F32] flex items-center justify-center mb-4">
                <Users className="w-5 h-5" />
              </div>
              <h2 className="font-display text-xl font-bold text-[#0D1F16]">{t('forWorkersTitle')}</h2>
              <p className="mt-2 text-sm text-[#475B50] leading-relaxed">{t('forWorkersDesc')}</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('search')}
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#0B4F32] hover:text-[#073823] min-h-[44px]"
            >
              <Search className="w-4 h-4" />
              <span>{t('forWorkersCta')}</span>
            </button>
          </div>

          <div className="bg-[#0B4F32] text-white rounded-2xl p-6 flex flex-col justify-between gap-4">
            <div>
              <div className="w-10 h-10 rounded-xl bg-white/10 text-white flex items-center justify-center mb-4">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h2 className="font-display text-xl font-bold">{t('forSuppliersTitle')}</h2>
              <p className="mt-2 text-sm text-white/85 leading-relaxed">{t('forSuppliersDesc')}</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate(user?.role === 'supplier' ? 'create-job' : 'login')}
              className="inline-flex items-center gap-2 text-sm font-semibold text-white hover:text-white/80 min-h-[44px]"
            >
              <span>
                {user?.role === 'supplier' ? t('forSuppliersCtaCreate') : t('forSuppliersCtaAuth')}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Preview Demands (Clearly distinguishes Live Firestore vs Sample Demo) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-10">
        <div className="flex items-center justify-between gap-4 mb-5">
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-[#0D1F16]">
              {hasLiveJobs ? t('latestVerifiedTitle') : t('sourceDemoTab')}
            </h2>
            <p className="text-sm text-[#5E7166]">
              {hasLiveJobs ? t('latestVerifiedSub') : t('samplePreviewNotice')}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('feed')}
            className="text-sm font-semibold text-[#0B4F32] hover:underline whitespace-nowrap shrink-0 min-h-[44px] flex items-center"
          >
            {t('viewAllDemands')}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {previewJobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              onSelectJob={onSelectJob}
              onSelectSupplier={onSelectSupplier}
              onViewCircular={onViewCircular}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
