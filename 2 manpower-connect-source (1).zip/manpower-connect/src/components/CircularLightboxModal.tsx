import { useEffect } from 'react';
import { Building2, ExternalLink, X } from 'lucide-react';
import { useI18n } from '../i18n';
import type { JobPost } from '../types';
import { formatRelativeDate } from '../utils';

interface CircularLightboxModalProps {
  job: JobPost | null;
  onClose: () => void;
  onSelectSupplier?: (supplierId: string) => void;
}

export function CircularLightboxModal({
  job,
  onClose,
  onSelectSupplier,
}: CircularLightboxModalProps) {
  const { t } = useI18n();

  useEffect(() => {
    if (!job) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [job, onClose]);

  if (!job || !job.circularImageUrl) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${job.supplierName} ${t('circularBadgeLabel')}`}
      className="fixed inset-0 z-50 bg-black/90 flex flex-col"
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between gap-3 px-4 py-3 bg-[#073823] text-white border-b border-white/10 shrink-0">
        <div className="min-w-0">
          <p className="text-sm font-semibold truncate">{job.supplierName}</p>
          <p className="text-xs text-white/75 truncate">
            {job.supplierCity} · {formatRelativeDate(job.createdAt)}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {onSelectSupplier ? (
            <button
              type="button"
              onClick={() => {
                const sid = job.supplierId;
                onClose();
                onSelectSupplier(sid);
              }}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold transition-colors"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>{t('screenSupplierProfile')}</span>
            </button>
          ) : null}

          <a
            href={job.circularImageUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-white/15 hover:bg-white/25 text-white transition-colors"
            title="Open image in new tab"
            aria-label="Open image in new tab"
          >
            <ExternalLink className="w-4 h-4" />
          </a>

          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 h-11 min-w-[44px] rounded-xl bg-white text-[#0D1F16] hover:bg-[#F0F4F1] text-xs font-bold transition-colors"
            aria-label={t('closeFullSizeBtn')}
          >
            <X className="w-4 h-4" />
            <span>{t('closeFullSizeBtn')}</span>
          </button>
        </div>
      </div>

      {/* Scrollable / Pinch-friendly Full-Size Image Container */}
      <div
        onClick={onClose}
        className="flex-1 overflow-auto p-3 sm:p-6 flex items-center justify-center"
      >
        <img
          src={job.circularImageUrl}
          alt={`${job.supplierName} job circular`}
          onClick={(e) => e.stopPropagation()}
          className="max-w-full max-h-full w-auto h-auto object-contain rounded-lg shadow-2xl bg-white"
        />
      </div>

      {/* Bottom Mobile Action Bar */}
      {onSelectSupplier ? (
        <div className="sm:hidden p-3 bg-[#073823] border-t border-white/10 shrink-0">
          <button
            type="button"
            onClick={() => {
              const sid = job.supplierId;
              onClose();
              onSelectSupplier(sid);
            }}
            className="w-full h-11 rounded-xl bg-white text-[#0B4F32] text-xs font-bold flex items-center justify-center gap-2"
          >
            <Building2 className="w-4 h-4" />
            <span>{t('screenSupplierProfile')}</span>
          </button>
        </div>
      ) : null}
    </div>
  );
}
