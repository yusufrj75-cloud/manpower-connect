export type Language = 'en' | 'bn';

export type UserRole = 'worker' | 'supplier' | 'admin';

export type SupplierApprovalStatus = 'pending' | 'approved' | 'rejected';

export type JobApprovalStatus = 'pending' | 'approved' | 'rejected';

export type ScreenName =
  | 'welcome'
  | 'login'
  | 'feed'
  | 'search'
  | 'job-details'
  | 'supplier-profile'
  | 'create-job'
  | 'admin';

export interface PublicUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  phone: string;
  city: string;
  emailVerified?: boolean;
  isDemo?: boolean;
  // Worker fields
  trade?: string;
  yearsExperience?: number;
  iqamaTransferable?: boolean;
  iqamaReference?: string;
  // Supplier fields
  supplierDocId?: string;
  companyName?: string;
  businessPhone?: string;
  whatsappNumber?: string;
  officeAddress?: string;
  officeMapLink?: string;
  crNumber?: string;
  qiwaId?: string;
  gosiReference?: string;
  crDocumentLabel?: string;
  approvalStatus?: SupplierApprovalStatus;
  adminNote?: string;
  bio?: string;
  specialties?: string[];
  nitaqatBand?: string;
  yearsActive?: number;
  createdAt: string;
}

export type JobStatus = 'active' | 'paused' | 'closed';

export type JobPostType = 'circular_image' | 'structured';

export interface JobPost {
  id: string;
  supplierId: string;
  ownerUid?: string;
  supplierName: string;
  supplierCity: string;
  supplierCrNumber?: string;
  businessPhone?: string;
  whatsappNumber?: string;
  supplierApprovalStatus: SupplierApprovalStatus;
  approvalStatus: JobApprovalStatus;
  adminNote?: string;
  postType?: JobPostType;
  circularImageUrl?: string;
  title?: string;
  category?: string;
  city?: string;
  siteLocation?: string;
  headcount?: number;
  salaryMin?: number;
  salaryMax?: number;
  contractType?: string;
  durationMonths?: number;
  shiftHours?: string;
  accommodationIncluded?: boolean;
  transportIncluded?: boolean;
  mealsIncluded?: boolean;
  iqamaTransferableRequired?: boolean;
  certifications?: string[];
  description?: string;
  status: JobStatus;
  applicationsCount: number;
  createdAt: string;
  updatedAt?: string;
  isDemo?: boolean;
}

export type ApplicationStatus = 'submitted' | 'shortlisted' | 'accepted' | 'declined';

export interface JobApplication {
  id: string;
  jobId: string;
  jobTitle: string;
  jobCity: string;
  supplierId: string;
  supplierOwnerUid?: string;
  supplierName: string;
  workerId: string;
  workerName: string;
  workerPhone: string;
  workerTrade: string;
  workerCity: string;
  iqamaTransferable: boolean;
  note: string;
  status: ApplicationStatus;
  createdAt: string;
  isDemo?: boolean;
}

export interface SearchFilters {
  q: string;
  city: string;
  category: string;
  contractType: string;
  minSalary: number;
  accommodationOnly: boolean;
  transportOnly: boolean;
  sortBy: 'newest' | 'salary_desc' | 'headcount_desc';
}
