export const ASSETS = {
  heroSkyline: '/src/assets/images/hero_riyadh_skyline_1794772442256.jpg',
  industrialSite: '/src/assets/images/industrial_site_operations_1794772442777.jpg',
  corporateHq: '/src/assets/images/saudi_corporate_hq_1794772442872.jpg',
  supervisorPortrait: '/src/assets/images/supervisor_portrait_1794772443855.jpg',
} as const;
