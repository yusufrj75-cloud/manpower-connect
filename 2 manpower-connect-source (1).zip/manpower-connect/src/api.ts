import type {
  ApplicationStatus,
  JobApplication,
  JobPost,
  JobStatus,
  PublicUser,
  SearchFilters,
  SupplierApprovalStatus,
} from './types';

const TOKEN_KEY = 'manpower_connect_token';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    // ignore storage errors
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  getStats: () =>
    request<{
      activeJobsCount: number;
      approvedSuppliersCount: number;
      totalPositions: number;
      registeredWorkersCount: number;
    }>('/api/marketplace/stats'),

  login: (email: string, password: string) =>
    request<{ token: string; user: PublicUser }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  register: (payload: {
    email: string;
    password: string;
    name: string;
    role: 'worker' | 'supplier';
    phone: string;
    city: string;
    trade?: string;
    yearsExperience?: number;
    iqamaTransferable?: boolean;
    companyName?: string;
    crNumber?: string;
    bio?: string;
    specialties?: string[];
  }) =>
    request<{ token: string; user: PublicUser }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  me: () => request<{ user: PublicUser }>('/api/auth/me'),

  listJobs: (filters?: Partial<SearchFilters> & { supplierId?: string }) => {
    const params = new URLSearchParams();
    if (filters?.q) params.set('q', filters.q);
    if (filters?.city && filters.city !== 'All') params.set('city', filters.city);
    if (filters?.category && filters.category !== 'All') params.set('category', filters.category);
    if (filters?.contractType && filters.contractType !== 'All') params.set('contractType', filters.contractType);
    if (filters?.minSalary && filters.minSalary > 0) params.set('minSalary', String(filters.minSalary));
    if (filters?.accommodationOnly) params.set('accommodation', 'true');
    if (filters?.transportOnly) params.set('transport', 'true');
    if (filters?.supplierId) params.set('supplierId', filters.supplierId);
    if (filters?.sortBy) params.set('sortBy', filters.sortBy);
    const qs = params.toString();
    return request<{ jobs: JobPost[] }>(`/api/jobs${qs ? `?${qs}` : ''}`);
  },

  getJob: (id: string) =>
    request<{ job: JobPost; supplier: PublicUser | null; hasApplied: boolean }>(`/api/jobs/${id}`),

  createJob: (payload: {
    title: string;
    category: string;
    city: string;
    siteLocation: string;
    headcount: number;
    salaryMin: number;
    salaryMax: number;
    contractType: string;
    durationMonths: number;
    shiftHours: string;
    accommodationIncluded: boolean;
    transportIncluded: boolean;
    mealsIncluded: boolean;
    iqamaTransferableRequired: boolean;
    certifications: string[];
    description: string;
  }) =>
    request<{ job: JobPost }>('/api/jobs', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateJobStatus: (id: string, status: JobStatus) =>
    request<{ job: JobPost }>(`/api/jobs/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  deleteJob: (id: string) =>
    request<{ deleted: boolean }>(`/api/jobs/${id}`, {
      method: 'DELETE',
    }),

  applyToJob: (jobId: string, payload: { note: string; phone?: string; iqamaTransferable?: boolean }) =>
    request<{ application: JobApplication }>(`/api/jobs/${jobId}/apply`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getMyApplications: () => request<{ applications: JobApplication[] }>('/api/applications/me'),

  updateApplicationStatus: (appId: string, status: ApplicationStatus) =>
    request<{ application: JobApplication }>(`/api/applications/${appId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  listApprovedSuppliers: () => request<{ suppliers: PublicUser[] }>('/api/suppliers'),

  getSupplierProfile: (id: string) =>
    request<{ supplier: PublicUser; jobs: JobPost[] }>(`/api/suppliers/${id}`),

  updateMySupplierProfile: (payload: {
    companyName?: string;
    phone?: string;
    city?: string;
    bio?: string;
    specialties?: string[];
    crNumber?: string;
  }) =>
    request<{ user: PublicUser }>('/api/suppliers/me', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getAdminOverview: () =>
    request<{
      suppliers: PublicUser[];
      jobs: JobPost[];
      metrics: {
        pendingSuppliers: number;
        approvedSuppliers: number;
        rejectedSuppliers: number;
        activeJobs: number;
        totalWorkersRequested: number;
        registeredWorkers: number;
      };
    }>('/api/admin/overview'),

  updateSupplierApproval: (id: string, approvalStatus: SupplierApprovalStatus, adminNote?: string) =>
    request<{ supplier: PublicUser }>(`/api/admin/suppliers/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ approvalStatus, adminNote }),
    }),

  adminUpdateJobStatus: (id: string, status: JobStatus) =>
    request<{ job: JobPost }>(`/api/admin/jobs/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),
};
