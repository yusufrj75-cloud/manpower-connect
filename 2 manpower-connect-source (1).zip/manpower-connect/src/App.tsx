import { useCallback, useEffect, useState } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import type { User as FirebaseUser } from 'firebase/auth';
import { AdminDashboardScreen } from './components/AdminDashboardScreen';
import { CircularLightboxModal } from './components/CircularLightboxModal';
import { CreateJobScreen } from './components/CreateJobScreen';
import { HomeFeedScreen } from './components/HomeFeedScreen';
import { JobDetailsScreen } from './components/JobDetailsScreen';
import { LoginScreen } from './components/LoginScreen';
import { NavShell } from './components/NavShell';
import { SearchFiltersScreen } from './components/SearchFiltersScreen';
import { SupplierProfileScreen } from './components/SupplierProfileScreen';
import { WelcomeScreen } from './components/WelcomeScreen';
import { auth } from './firebase';
import { LanguageContext, TRANSLATIONS } from './i18n';
import type { TranslationKey } from './i18n';
import {
  fetchUserSessionProfile,
  listApprovedLiveJobs,
  listApprovedLiveSuppliers,
  listLiveApplications,
  listMySupplierJobs,
} from './services/firestoreMarketplace';
import type { JobApplication, JobPost, Language, PublicUser, ScreenName, SearchFilters } from './types';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [screen, setScreen] = useState<ScreenName>('welcome');
  const [prevScreen, setPrevScreen] = useState<ScreenName>('feed');
  const [user, setUser] = useState<PublicUser | null>(null);
  const [pendingFirebaseUser, setPendingFirebaseUser] = useState<FirebaseUser | null>(null);

  const [liveJobs, setLiveJobs] = useState<JobPost[]>([]);
  const [mySupplierJobs, setMySupplierJobs] = useState<JobPost[]>([]);
  const [approvedSuppliersCount, setApprovedSuppliersCount] = useState(0);
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [loadingJobs, setLoadingJobs] = useState(true);

  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [editingJob, setEditingJob] = useState<JobPost | null>(null);
  const [lightboxJob, setLightboxJob] = useState<JobPost | null>(null);
  const [selectedSupplierId, setSelectedSupplierId] = useState<string | null>(null);
  const [searchSeed, setSearchSeed] = useState<Partial<SearchFilters> | undefined>(undefined);

  const t = useCallback((key: TranslationKey) => TRANSLATIONS[lang][key], [lang]);

  const loadMarketplaceData = useCallback(async (activeUser: PublicUser | null) => {
    setLoadingJobs(true);
    try {
      const [jobsData, suppliersData] = await Promise.all([
        listApprovedLiveJobs(),
        listApprovedLiveSuppliers(),
      ]);
      setLiveJobs(jobsData);
      setApprovedSuppliersCount(suppliersData.length);

      if (activeUser?.role === 'supplier') {
        const ownJobs = await listMySupplierJobs(activeUser.id);
        setMySupplierJobs(ownJobs);
      } else {
        setMySupplierJobs([]);
      }
    } catch {
      // keep resilient state
    } finally {
      setLoadingJobs(false);
    }
  }, []);

  const loadApplications = useCallback(async (activeUser: PublicUser | null) => {
    if (!activeUser || (activeUser.role !== 'worker' && activeUser.role !== 'supplier')) {
      setApplications([]);
      return;
    }
    try {
      const apps = await listLiveApplications(activeUser);
      setApplications(apps);
    } catch {
      setApplications([]);
    }
  }, []);

  // Firebase Authentication Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (!fbUser) {
        setUser(null);
        setPendingFirebaseUser(null);
        setApplications([]);
        loadMarketplaceData(null);
        return;
      }

      if (!fbUser.emailVerified) {
        setUser(null);
        setPendingFirebaseUser(fbUser);
        loadMarketplaceData(null);
        return;
      }

      try {
        const profile = await fetchUserSessionProfile(fbUser);
        if (profile) {
          setPendingFirebaseUser(null);
          setUser(profile);
          loadMarketplaceData(profile);
          loadApplications(profile);
        } else {
          // Authenticated via Google for the first time without role onboarding yet
          setUser(null);
          setPendingFirebaseUser(fbUser);
          setScreen('login');
          loadMarketplaceData(null);
        }
      } catch {
        setUser(null);
        loadMarketplaceData(null);
      }
    });

    return () => unsubscribe();
  }, [loadMarketplaceData, loadApplications]);

  function navigateTo(next: ScreenName) {
    if (next !== 'create-job') {
      setEditingJob(null);
    }
    if (next !== screen) {
      setPrevScreen(screen);
      setScreen(next);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  function handleSelectJob(jobId: string) {
    setSelectedJobId(jobId);
    navigateTo('job-details');
  }

  function handleEditJob(job: JobPost) {
    setEditingJob(job);
    setPrevScreen(screen);
    setScreen('create-job');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleSelectSupplier(supplierId: string) {
    setSelectedSupplierId(supplierId);
    navigateTo('supplier-profile');
  }

  function handleOpenMyProfile() {
    if (user?.role === 'supplier') {
      setSelectedSupplierId(user.supplierDocId || user.id);
    } else {
      setSelectedSupplierId(null);
    }
    navigateTo('supplier-profile');
  }

  function handleAuthSuccess(loggedUser: PublicUser) {
    setPendingFirebaseUser(null);
    setUser(loggedUser);
    loadMarketplaceData(loggedUser);
    loadApplications(loggedUser);
    if (loggedUser.role === 'admin') {
      navigateTo('admin');
    } else if (loggedUser.role === 'supplier') {
      setSelectedSupplierId(loggedUser.supplierDocId || loggedUser.id);
      navigateTo('feed');
    } else {
      navigateTo('feed');
    }
  }

  async function handleLogout() {
    await signOut(auth);
    setUser(null);
    setPendingFirebaseUser(null);
    setApplications([]);
    navigateTo('welcome');
  }

  async function handleJobSaved(_savedJobId: string) {
    setEditingJob(null);
    await loadMarketplaceData(user);
    navigateTo('feed');
  }

  function handleBack() {
    if (prevScreen && prevScreen !== screen) {
      setScreen(prevScreen);
    } else {
      setScreen('feed');
    }
  }

  async function refreshCurrentSession() {
    if (auth.currentUser) {
      const profile = await fetchUserSessionProfile(auth.currentUser);
      if (profile) setUser(profile);
      await loadMarketplaceData(profile);
    } else {
      await loadMarketplaceData(null);
    }
  }

  const appliedJobIds = new Set(applications.map((a) => a.jobId));

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      <div
        className="min-h-screen flex flex-col bg-[#F6F8F7] text-[#0D1F16]"
        style={
          lang === 'bn'
            ? { fontFamily: "'Noto Sans Bengali', 'DM Sans', sans-serif" }
            : undefined
        }
      >
        <NavShell
          currentScreen={screen}
          user={user}
          onNavigate={navigateTo}
          onOpenMyProfile={handleOpenMyProfile}
          onBack={handleBack}
          onLogout={handleLogout}
        />

        <main className="flex-1">
          {screen === 'welcome' ? (
            <WelcomeScreen
              user={user}
              liveJobs={liveJobs}
              approvedSuppliersCount={approvedSuppliersCount}
              onNavigate={navigateTo}
              onSelectJob={handleSelectJob}
              onSelectSupplier={handleSelectSupplier}
              onViewCircular={(job) => setLightboxJob(job)}
            />
          ) : null}

          {screen === 'login' ? (
            <LoginScreen
              pendingFirebaseUser={pendingFirebaseUser}
              onSuccess={handleAuthSuccess}
              onCancel={handleBack}
            />
          ) : null}

          {screen === 'feed' ? (
            <HomeFeedScreen
              user={user}
              liveJobs={liveJobs}
              mySupplierJobs={mySupplierJobs}
              applications={applications}
              loading={loadingJobs}
              onSelectJob={handleSelectJob}
              onViewCircular={(job) => setLightboxJob(job)}
              onEditJob={handleEditJob}
              onSelectSupplier={handleSelectSupplier}
              onNavigate={navigateTo}
              onOpenSearchWithCategory={(category) => {
                setSearchSeed({ category });
                navigateTo('search');
              }}
              onDataChanged={() => loadMarketplaceData(user)}
            />
          ) : null}

          {screen === 'search' ? (
            <SearchFiltersScreen
              initialFilters={searchSeed}
              liveJobs={liveJobs}
              loadingLive={loadingJobs}
              appliedJobIds={appliedJobIds}
              onSelectJob={handleSelectJob}
              onSelectSupplier={handleSelectSupplier}
              onViewCircular={(job) => setLightboxJob(job)}
            />
          ) : null}

          {screen === 'job-details' && selectedJobId ? (
            <JobDetailsScreen
              jobId={selectedJobId}
              user={user}
              onBack={handleBack}
              onEditJob={handleEditJob}
              onViewCircular={(job) => setLightboxJob(job)}
              onSelectSupplier={handleSelectSupplier}
              onNavigate={navigateTo}
              onApplicationSubmitted={() => {
                loadApplications(user);
                loadMarketplaceData(user);
              }}
              onJobChanged={() => loadMarketplaceData(user)}
            />
          ) : null}

          {screen === 'supplier-profile' ? (
            <SupplierProfileScreen
              supplierId={selectedSupplierId}
              user={user}
              applications={applications}
              onSelectSupplier={handleSelectSupplier}
              onSelectJob={handleSelectJob}
              onViewCircular={(job) => setLightboxJob(job)}
              onEditJob={handleEditJob}
              onNavigate={navigateTo}
              onProfileUpdated={refreshCurrentSession}
              onApplicationUpdated={() => loadApplications(user)}
              onBack={handleBack}
            />
          ) : null}

          {screen === 'create-job' ? (
            <CreateJobScreen
              key={editingJob?.id || 'create-new'}
              user={user}
              editingJob={editingJob}
              onJobSaved={handleJobSaved}
              onCancelEdit={() => {
                setEditingJob(null);
                handleBack();
              }}
              onNavigate={navigateTo}
              onOpenSupplierProfile={handleSelectSupplier}
            />
          ) : null}

          {screen === 'admin' ? (
            <AdminDashboardScreen
              user={user}
              onSelectJob={handleSelectJob}
              onSelectSupplier={handleSelectSupplier}
              onDataUpdated={() => loadMarketplaceData(user)}
              onNavigate={navigateTo}
            />
          ) : null}
        </main>

        <footer className="hidden md:block bg-white border-t border-[#E2E8E4] py-6">
          <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#5E7166]">
            <span>MANPOWER CONNECT · Kingdom of Saudi Arabia</span>
            <div className="flex items-center gap-6">
              <button type="button" onClick={() => navigateTo('feed')} className="hover:text-[#0B4F32]">
                {t('navFeed')}
              </button>
              <button type="button" onClick={() => navigateTo('search')} className="hover:text-[#0B4F32]">
                {t('navSearch')}
              </button>
              <button type="button" onClick={() => navigateTo('create-job')} className="hover:text-[#0B4F32]">
                {t('navPost')}
              </button>
              <button type="button" onClick={() => navigateTo('admin')} className="hover:text-[#0B4F32]">
                {t('navAdmin')}
              </button>
            </div>
          </div>
        </footer>
        <CircularLightboxModal
          job={lightboxJob}
          onClose={() => setLightboxJob(null)}
          onSelectSupplier={handleSelectSupplier}
        />
      </div>
    </LanguageContext.Provider>
  );
}
