export function formatSarRange(min: number, max: number): string {
  const fmt = new Intl.NumberFormat('en-SA');
  if (min === max) return `SAR ${fmt.format(min)}`;
  return `SAR ${fmt.format(min)} – ${fmt.format(max)}`;
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat('en-SA').format(n);
}

export function formatRelativeDate(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const minutes = Math.max(1, Math.floor(diffMs / 60000));
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(iso).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function normalizePhoneDigits(rawPhone: string): string {
  const digits = rawPhone.replace(/[^\d+]/g, '');
  if (!digits) return '';
  if (digits.startsWith('+')) return digits.slice(1);
  if (digits.startsWith('00')) return digits.slice(2);
  if (digits.startsWith('05')) return `966${digits.slice(1)}`;
  return digits;
}

export function buildTelHref(rawPhone?: string): string | null {
  if (!rawPhone) return null;
  const normalized = normalizePhoneDigits(rawPhone);
  if (!normalized) return null;
  return `tel:+${normalized}`;
}

export function buildWhatsAppHref(rawPhone?: string, prefillText?: string): string | null {
  if (!rawPhone) return null;
  const normalized = normalizePhoneDigits(rawPhone);
  if (!normalized) return null;
  const base = `https://wa.me/${normalized}`;
  if (!prefillText) return base;
  return `${base}?text=${encodeURIComponent(prefillText)}`;
}

export function sanitizeHttpUrl(rawUrl?: string): string | null {
  if (!rawUrl) return null;
  const trimmed = rawUrl.trim();
  if (!trimmed) return null;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}
