# Security Specification — MANPOWER CONNECT

## 1. Data Invariants
1. **No Self-Approval / Privilege Escalation**: Users creating `users/{uid}` cannot assign `role: 'admin'`. Suppliers creating `suppliers/{supplierId}` must start with `approvalStatus: 'pending'`. Only `isAdmin()` can change `approvalStatus` or `adminNote` on `suppliers` and `jobs`.
2. **Approved Supplier Gate for Jobs**: Creating a `jobs/{jobId}` document requires `exists` and `get()` verification that the parent `suppliers/{supplierId}` belongs to `request.auth.uid` AND has `approvalStatus == 'approved'`. New jobs always start with `approvalStatus: 'pending'`, `applicationsCount == 0`, and `ownerUid == request.auth.uid`.
3. **PII & Private Document Isolation**:
   - `users/{uid}/private/profile` (email, phone, Iqama status) is readable/writable strictly by `uid == request.auth.uid` or `isAdmin()`.
   - `suppliers/{supplierId}/private/documents` (CR number, Qiwa ID, GOSI reference) is readable/writable strictly by `ownerUid == request.auth.uid` or `isAdmin()`.
4. **Job Application Isolation**: `applications/{appId}` can only be created by a signed-in user with `workerId == request.auth.uid` against an approved, active job; `read`/`list` is restricted to `workerId == request.auth.uid`, `supplierOwnerUid == request.auth.uid`, or `isAdmin()`.
5. **Strict Key & Size Bounds**: Every `create` verifies `keys().hasAll(...)` and `keys().hasOnly(...)`; every `update` uses `affectedKeys().hasOnly(...)` inside a validation wrapper. All IDs match `^[a-zA-Z0-9_\\-]+$` and all timestamps use `request.time`.

## 2. Dirty Dozen Attack Vectors
1. Self-registering as `role: 'admin'` in `users/{uid}` -> DENIED.
2. Reading another user's `users/{otherUid}/private/profile` -> DENIED.
3. Reading another supplier's `suppliers/{otherId}/private/documents` -> DENIED.
4. Supplier creating a profile with `approvalStatus: 'approved'` directly -> DENIED.
5. Non-admin updating `suppliers/{id}` `approvalStatus` to `'approved'` -> DENIED.
6. Pending supplier creating a `jobs/{jobId}` document -> DENIED (`get(supplier).data.approvalStatus == 'approved'` fails).
7. Supplier creating a job with `approvalStatus: 'approved'` directly -> DENIED.
8. Non-owner editing or deleting someone else's job post -> DENIED.
9. Worker listing all applications across the platform (`applications` without owner/supplier filter) -> DENIED (`allow list` requires `workerId == uid || supplierOwnerUid == uid || isAdmin()`).
10. Injecting a ghost field (`isVerified: true`) in any `create` or `update` -> DENIED (`hasOnly` / `affectedKeys().hasOnly`).
11. Spoofing `ownerUid` or `workerId` to another UID -> DENIED.
12. Passing a 10KB junk string as document ID or unverified client timestamp -> DENIED (`isValidId`, `request.time`).
